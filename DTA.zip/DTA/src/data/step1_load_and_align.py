# coding: utf-8
"""
src/data/step1_load_and_align.py
Step1: 读取原始 CSV，多台机器分别对齐字段顺序，再合并输出。
输出:
•  interim_dir/preprocessed.json        # list[dict]，每条是 metrics+meta.*
•  interim_dir/feature_list.json        # {union_feature_list, per_snapshot_feature_list, meta_fields}

更新要点：
✅ 阶段1过滤：CSV读取后，任何字段为None/null则丢弃；
✅ 阶段2过滤：字段对齐补None后，再次检查空值样本并丢弃；
✅ 统计 dropped_null_rows 前后总数。
"""

from __future__ import annotations
import csv, json
from pathlib import Path
from typing import Dict, List, Any
from collections import defaultdict, OrderedDict as OD

META_FIELDS = [
    "meta.timestamp",
    "meta.snapshot_id",
    "meta.period_ms",
    "meta.data_type",
]


# --------- 工具函数 ---------
def _parse_timestamp_to_int_ms(raw_ts: Any) -> int:
    if raw_ts is None:
        return 0
    s = str(raw_ts).strip().replace(",", "")
    try:
        return int(float(s)) if "." in s else int(s)
    except ValueError:
        return 0

def _parse_period_ms(raw_p: Any) -> int:
    """
    支持:
    - "5000"
    - "5,000"
    - "5000.0"
    - 5000
    解析失败 -> 0
    """
    if raw_p is None:
        return 0
    s = str(raw_p).strip().replace(",", "")
    try:
        # 支持小数形式
        return int(float(s))
    except ValueError:
        return 0
    

def _safe_json_loads(s: Any) -> Dict[str, Any]:
    if s is None:
        return {}
    if isinstance(s, dict):
        return s
    s = str(s).strip()
    try:
        return json.loads(s)
    except Exception:
        return {}


def _build_row_dict(csv_row: Dict[str, Any]) -> Dict[str, Any]:
    """
    把 CSV 行变成扁平 dict：
    1) 展开 data(JSON字符串)
    2) 加 meta.*
    3) 解析 period_ms -> meta.period_ms (int)
    4) 解析 timestamp -> meta.timestamp (int)
    """
    metrics = _safe_json_loads(csv_row.get("data"))

    snapshot_id = csv_row.get("snapshot_id", csv_row.get("meta.snapshot_id", "unknown"))

    # period_ms 来源优先级：
    # 1. meta.period_ms 显式列
    # 2. period 列
    # 3. 可能存在的 BOM 头 '﻿period'
    raw_period = None
    if "meta.period_ms" in csv_row:
        raw_period = csv_row["meta.period_ms"]
    elif "period" in csv_row:
        raw_period = csv_row["period"]
    elif "\ufeffperiod" in csv_row:
        raw_period = csv_row["\ufeffperiod"]
    else:
        raw_period = csv_row.get("meta.period_ms", 0)

    period_ms_int = _parse_period_ms(raw_period)

    # data_type
    data_type_val = csv_row.get("data_type", csv_row.get("meta.data_type", "vm"))

    # timestamp
    ts_raw = csv_row.get("timestamp", csv_row.get("meta.timestamp"))
    ts_ms = _parse_timestamp_to_int_ms(ts_raw)

    merged = {}
    merged.update(metrics)

    merged["meta.timestamp"] = ts_ms
    merged["meta.snapshot_id"] = snapshot_id
    merged["meta.period_ms"] = period_ms_int
    merged["meta.data_type"] = data_type_val

    return merged


def _sorted_keys_for_machine(rows: List[Dict[str, Any]]) -> List[str]:
    all_keys = set()
    for r in rows:
        all_keys.update(r.keys())
    non_meta = sorted([k for k in all_keys if not k.startswith("meta.")])
    ordered = non_meta + [mk for mk in META_FIELDS if mk in all_keys]
    return ordered



def _align_rows_to_keys(rows: List[Dict[str, Any]], key_order: List[str]) -> List[Dict[str, Any]]:
    aligned = []
    for r in rows:
        new_r = OD()
        for k in key_order:
            new_r[k] = r.get(k, None)
        aligned.append(dict(new_r))
    return aligned


# --------- 主入口 ---------
def run_step1_load_and_align(step1_cfg: dict, data_cfg: dict) -> dict:
    raw_dir = Path(data_cfg["raw_dir"])
    interim_dir = Path(data_cfg["interim_dir"])
    interim_dir.mkdir(parents=True, exist_ok=True)

    files_list = data_cfg.get("files", [])
    if not isinstance(files_list, list):
        files_list = [files_list]

    machine_rows: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    # -------------------------------
    # 阶段 1：读取 + 第一轮空值过滤
    # -------------------------------
    dropped_stage1 = 0
    print(files_list)
    for fname in files_list:
        csv_path = raw_dir / fname
        if not csv_path.exists():
            print(f"[step1] warn: {csv_path} not found, skip")
            continue
        print(csv_path)
        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                row = {k.strip().lstrip("\ufeff"): v for k, v in row.items()}
            
                merged_row = _build_row_dict(row)
                # 第一轮空值检测
                if any(v is None for v in merged_row.values()):
                    dropped_stage1 += 1
                    continue
                sid = str(merged_row.get("meta.snapshot_id", "unknown"))
                machine_rows[sid].append(merged_row)

    # -------------------------------
    # 阶段 2：字段对齐 + 第二轮空值过滤
    # -------------------------------
    all_aligned_rows: List[Dict[str, Any]] = []
    union_feature_list: List[str] = []
    per_snapshot_feature_list: Dict[str, List[str]] = {}
    dropped_stage2 = 0

    for sid in sorted(machine_rows.keys()):
        rows_this = machine_rows[sid]
        if not rows_this:
            continue

        key_order = _sorted_keys_for_machine(rows_this)
        per_snapshot_feature_list[sid] = key_order

        aligned_rows = _align_rows_to_keys(rows_this, key_order)

        # 第二轮空值检测（对齐后）
        cleaned_rows = []
        for r in aligned_rows:
            if any(v is None for v in r.values()):
                dropped_stage2 += 1
                continue
            cleaned_rows.append(r)

        # 更新全局结构
        all_aligned_rows.extend(cleaned_rows)
        for k in key_order:
            if k not in union_feature_list:
                union_feature_list.append(k)

    total_dropped = dropped_stage1 + dropped_stage2

    # -------------------------------
    # 写出文件
    # -------------------------------
    preprocessed_path = interim_dir / "preprocessed.json"
    with open(preprocessed_path, "w", encoding="utf-8") as f_out:
        json.dump(all_aligned_rows, f_out, ensure_ascii=False, indent=2)

    featlist_path = interim_dir / "feature_list.json"
    feature_list_payload = {
        "union_feature_list": union_feature_list,
        "per_snapshot_feature_list": per_snapshot_feature_list,
        "meta_fields": META_FIELDS,
    }
    
    # -------------------------------
    # 写出文件（安全转换类型）
    # -------------------------------
    def _convert_to_native_types(obj):
        if isinstance(obj, dict):
            return {k: _convert_to_native_types(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [_convert_to_native_types(v) for v in obj]
        elif hasattr(obj, "item") and callable(obj.item):
            return obj.item()
        else:
            return obj

    with open(preprocessed_path, "w", encoding="utf-8") as f_out:
        json.dump(all_aligned_rows, f_out, ensure_ascii=False, indent=2)
    
    with open(featlist_path, "w", encoding="utf-8") as f_feat:
        json.dump(feature_list_payload, f_feat, ensure_ascii=False, indent=2)

    # -------------------------------
    # 汇总报告
    # -------------------------------
    report = {
        "machines": [
            {
                "snapshot_id": sid,
                "rows": len(machine_rows[sid]),
                "feature_count": len(per_snapshot_feature_list[sid]),
            }
            for sid in sorted(machine_rows.keys())
        ],
        "total_rows": len(all_aligned_rows),
        "dropped_stage1": dropped_stage1,
        "dropped_stage2": dropped_stage2,
        "dropped_total": total_dropped,
        "union_feature_count": len(union_feature_list),
        "meta_fields": META_FIELDS,
        "preprocessed_path": str(preprocessed_path),
        "feature_list_path": str(featlist_path),
    }

    print("[step1] done.")
    print(f"[step1] total_rows={report['total_rows']}")
    print(f"[step1] dropped_stage1={report['dropped_stage1']} dropped_stage2={report['dropped_stage2']} total={report['dropped_total']}")
    print(f"[step1] union_feature_count={report['union_feature_count']}")
    print(f"[step1] preprocessed.json -> {preprocessed_path}")
    print(f"[step1] feature_list.json -> {featlist_path}")

    return report