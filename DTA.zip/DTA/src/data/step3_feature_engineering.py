# src/data/step3_feature_engineering.py
# -*- coding: utf-8 -*-
"""
Step3: 周期特征 / 差分特征 / 滑动窗口统计特征
输入:  data/interim/preprocessed.json (list[dict], 已经经过 step1,step2)
输出:  覆盖写回 preprocessed.json + feature_list.json

这个步骤做三件事 (按配置可开/关)：
1. period_features: 从 meta.timestamp 解析 hour/day/weekday 等周期特征
2. diff_features:   针对指定字段做时序差分 (x_t - x_{t-lag}) / 保留原值不删
3. stat_features:   针对指定字段做滑动窗口统计 (mean/std/.../cvar/skew/kurt)

所有新增特征都会被插入在 meta.* 之前，meta.* 字段依然靠后。
"""

from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
import json
import math
import statistics
from datetime import datetime, timezone

from .utils import ensure_dir, dump_json


# -------------------------------------------------
# Helpers: numeric check
# -------------------------------------------------
def _is_num(x: Any) -> bool:
    if isinstance(x, (int, float)) and not (isinstance(x, float) and math.isnan(x)):
        return True
    return False


# -------------------------------------------------
# 1. 周期特征 (period_features)
# -------------------------------------------------
def _gen_periodic_features_for_row(
    row: Dict[str, Any],
    pf_cfg: Dict[str, Any],
) -> Dict[str, Any]:
    """
    从 timestamp 字段解析时间特征:
    - 默认使用 UTC 解析 (我们可以以后加 tz 配置)
    返回 {new_key: value}
    """
    out: Dict[str, Any] = {}

    if not pf_cfg.get("enabled", False):
       
        return out

    ts_field = pf_cfg.get("time_field", "meta.timestamp")
    if ts_field not in row:
        return out

    raw_ts = row.get(ts_field, None)
    if raw_ts is None:
        return out

    try:
        # 去掉千分位逗号，并兼容浮点数字符串（如 '1761190245000.0'）
        ts_clean = str(raw_ts).replace(",", "")
        ts_ms = int(float(ts_clean))  # float() 再 int()，兼容 float/int/str
    except Exception as e:
        print(f"[warn] failed to parse timestamp: {raw_ts} ({e})")
        return out

    # 转成 UTC datetime
    dt = datetime.fromtimestamp(ts_ms / 1000.0, tz=timezone.utc)

    # 配置项控制哪些粒度要生成
    if pf_cfg.get("use_year", False):
        out["time.year"] = dt.year
    if pf_cfg.get("use_month", False):
        out["time.month"] = dt.month
    if pf_cfg.get("use_day", False):
        out["time.day"] = dt.day
    if pf_cfg.get("use_weekday", False):
        # Python: Monday=0,...Sunday=6
        out["time.weekday"] = dt.weekday()
    if pf_cfg.get("use_hour", False):
        out["time.hour"] = dt.hour
    if pf_cfg.get("use_minute", False):
        out["time.minute"] = dt.minute
    
    return out


# -------------------------------------------------
# 2. 差分特征 (diff_features)
# -------------------------------------------------
def _compute_diff_features_for_snapshot(
    rows: List[Dict[str, Any]],
    df_cfg: Dict[str, Any],
    snapshot_id: Any,
) -> List[Dict[str, Any]]:
    """
    对同一 snapshot_id 的多行（按时间升序）计算差分特征。

    规则：
    - diff(t) = value(t) - value(t - lag)
    - 如果没有足够的历史（序列前 lag 个点）→ 0
    - 如果当前值或历史值缺失/非数值 → 0
    - 结果特征名: {field}_diff{lag}

    注意：
    - 我们不丢样本，保持和原 rows 一一对应
    - lag 目前是单个整数（不是列表）
    """
    if not df_cfg.get("enabled", False):
        # 没开diff的话，返回同长度的空dict列表
        return [ {} for _ in rows ]

    fields = df_cfg.get("fields", [])
    lag = int(df_cfg.get("lag", 1))

    # 把每个目标字段在这一台机器的时间序列拉出来
    history: Dict[str, List[Optional[float]]] = {}
    for f in fields:
        col_vals: List[Optional[float]] = []
        for r in rows:
            v = r.get(f, None)
            if _is_num(v):
                col_vals.append(float(v))
            else:
                col_vals.append(None)
        history[f] = col_vals

    out_chunk: List[Dict[str, Any]] = []
    for i in range(len(rows)):
        new_feats_i: Dict[str, Any] = {}
        for f in fields:
            vals = history[f]
            cur_v = vals[i]
            prev_idx = i - lag

            feat_name = f"{f}_diff{lag}"

            # 情况1：没有前 lag 步，默认0
            if prev_idx < 0:
                new_feats_i[feat_name] = 0.0
                continue

            prev_v = vals[prev_idx]

            # 情况2：任一端是缺失/非数值，也记0
            if cur_v is None or prev_v is None:
                new_feats_i[feat_name] = 0.0
                continue

            # 情况3：正常差分
            new_feats_i[feat_name] = cur_v - prev_v

        out_chunk.append(new_feats_i)

    return out_chunk


# -------------------------------------------------
# 3. 滑动窗口统计特征 (stat_features)
# -------------------------------------------------

def _safe_mean(xs: List[float]) -> float:
    return statistics.fmean(xs) if xs else 0.0

def _safe_std(xs: List[float]) -> float:
    if len(xs) > 1:
        # 总体标准差 (和 step2 一致风格)
        return statistics.pstdev(xs)
    return 0.0

def _safe_var(xs: List[float]) -> float:
    if len(xs) > 1:
        return statistics.pvariance(xs)
    return 0.0

def _safe_skew(xs: List[float]) -> float:
    # 偏度: E[(x-μ)^3] / std^3
    n = len(xs)
    if n < 2:
        return 0.0
    mu = _safe_mean(xs)
    sd = _safe_std(xs)
    if sd == 0:
        return 0.0
    num = sum((x - mu)**3 for x in xs) / n
    return num / (sd**3 + 1e-12)

def _safe_kurt(xs: List[float]) -> float:
    # 过度峰度: E[(x-μ)^4] / std^4 - 3
    n = len(xs)
    if n < 2:
        return 0.0
    mu = _safe_mean(xs)
    sd = _safe_std(xs)
    if sd == 0:
        return 0.0
    num = sum((x - mu)**4 for x in xs) / n
    return num / (sd**4 + 1e-12) - 3.0

def _safe_cvar_change_rate(xs: List[float]) -> float:
    """
    CVaR = 变化率 = 窗口内相邻点的平均相对变化幅度
    r_i = | (x_i - x_{i-1}) / (|x_{i-1}| + 1e-8) |
    返回 mean(|r_i|)
    """
    if len(xs) < 2:
        return 0.0
    diffs = []
    for i in range(1, len(xs)):
        prev = xs[i-1]
        curr = xs[i]
        denom = abs(prev) + 1e-8
        diffs.append(abs((curr - prev) / denom))
    if not diffs:
        return 0.0
    return statistics.fmean(diffs)

def _rolling_stats_for_field(
    series_vals: List[Optional[float]],
    window: int,
    want_stats: List[str],
    full_window_only: bool,
) -> List[Dict[str, Any]]:
    """
    给单个字段的时间序列 (同一snapshot已按时间排好)
    返回: 对应每个时刻的字典 {statname: value_for_that_time}
    这些结果还不带字段名前缀，后面再补，比如 cpu.used_mean_5
    """
    n = len(series_vals)
    results: List[Dict[str, Any]] = []
    for i in range(n):
        start_idx = max(0, i - window + 1)
        window_vals = [series_vals[j] for j in range(start_idx, i + 1)]
        # 过滤掉 None
        window_vals = [float(v) for v in window_vals if v is not None]

        # full_window_only: 窗口必须凑齐 window 个观测才计算，否则设 None
        if full_window_only and (i - start_idx + 1 < window):
            results.append({st: None for st in want_stats})
            continue

        # 计算各种统计
        stat_map: Dict[str, Any] = {}
        for st in want_stats:
            if not window_vals:
                stat_map[st] = None
                continue

            if st == "mean":
                stat_map[st] = _safe_mean(window_vals)
            elif st == "max":
                stat_map[st] = max(window_vals)
            elif st == "min":
                stat_map[st] = min(window_vals)
            elif st == "std":
                stat_map[st] = _safe_std(window_vals)
            elif st == "var":
                stat_map[st] = _safe_var(window_vals)
            elif st == "skew":
                stat_map[st] = _safe_skew(window_vals)
            elif st == "kurt":
                stat_map[st] = _safe_kurt(window_vals)
            elif st == "cvar":
                stat_map[st] = _safe_cvar_change_rate(window_vals)
            else:
                # 未知的统计名，返回 None
                stat_map[st] = None

        results.append(stat_map)

    return results


def _compute_stat_features_for_snapshot(
    rows: List[Dict[str, Any]],
    sf_cfg: Dict[str, Any],
    snapshot_id: Any,
) -> List[Dict[str, Any]]:
    """
    针对同一 snapshot_id（时间升序）的多行，给每行生成滚动特征。
    返回: 和 rows 对齐的 list[ dict(new_feat_name -> value) ]
    """
    if not sf_cfg.get("enabled", False):
        return [ {} for _ in rows ]

    fields = sf_cfg.get("fields", [])
    window = int(sf_cfg.get("window", 5))
    full_window_only = bool(sf_cfg.get("full_window_only", False))
    want_stats = sf_cfg.get("stats", ["mean", "max", "min", "std", "var", "cvar", "skew", "kurt"])

    # 提前把所有字段的列值（每行一个）取出来
    field_to_series: Dict[str, List[Optional[float]]] = {}
    for f in fields:
        vals_f: List[Optional[float]] = []
        for r in rows:
            v = r.get(f, None)
            if _is_num(v):
                vals_f.append(float(v))
            else:
                vals_f.append(None)
        field_to_series[f] = vals_f

    # 对每个字段单独滚动
    # stats_per_field[f] = list[ dict(stat->val) ] 与 rows 对齐
    stats_per_field: Dict[str, List[Dict[str, Any]]] = {}
    for f, series_vals in field_to_series.items():
        stats_per_field[f] = _rolling_stats_for_field(
            series_vals=series_vals,
            window=window,
            want_stats=want_stats,
            full_window_only=full_window_only,
        )

    # 拼装回到每一行
    out_rows: List[Dict[str, Any]] = []
    for i in range(len(rows)):
        feat_i: Dict[str, Any] = {}
        for f in fields:
            st_map_i = stats_per_field[f][i]  # {stat: val}
            for st_name, st_val in st_map_i.items():
                # 命名: field_stat_window
                # 例如: cpu.used_mean_5
                # 对于 cvar 我们不再拼q，因为现在是变化率定义
                feat_key = f"{f}_{st_name}_{window}"
                feat_i[feat_key] = st_val
        out_rows.append(feat_i)

    return out_rows


# -------------------------------------------------
# 4. 将新增特征合并回行，并保持字段顺序
# -------------------------------------------------

def _merge_new_feats_per_row(
    base_rows: List[Dict[str, Any]],
    periodic_chunk: List[Dict[str, Any]],
    diff_chunk: List[Dict[str, Any]],
    stat_chunk: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    把三类新特征合到原始行里，逐行 update。
    """
    merged: List[Dict[str, Any]] = []
    for i, r in enumerate(base_rows):
        nr = dict(r)
        if periodic_chunk:
            nr.update(periodic_chunk[i])
        if diff_chunk:
            nr.update(diff_chunk[i])
        if stat_chunk:
            nr.update(stat_chunk[i])
        merged.append(nr)
    return merged


def _order_and_update_feature_list(
    original_rows: List[Dict[str, Any]],
    enriched_rows: List[Dict[str, Any]],
    meta_prefix: str = "meta.",
) -> Tuple[List[Dict[str, Any]], List[str]]:
    """
    和 step2 的顺序策略类似，但要考虑第三批新特征：
    - 我们仍然把新特征插到 meta.* 之前
    - 被新增的 key 出现在 enriched_rows[0] 但不在 original_rows[0] 的视为 new
    - 被删除的 key（step2 已经可能 drop_raw）不会复活
    """
    if not enriched_rows:
        return enriched_rows, []

    before_keys = list(original_rows[0].keys())          # step2 后（也就是 step3 前）的列顺序
    after_keys = list(enriched_rows[0].keys())            # 增强后的实际列集（可能多了period/diff/stat）

    # 1. 保留那些依然存在的旧字段（避免带回已删列）
    filtered_before = [k for k in before_keys if k in after_keys]

    # 2. 找到第一个 meta.* 的位置
    def is_meta(k: str) -> bool:
        return k.startswith(meta_prefix)

    meta_positions = [i for i, k in enumerate(filtered_before) if is_meta(k)]
    if meta_positions:
        cut = meta_positions[0]
    else:
        cut = len(filtered_before)

    # 3. 新特征 = after_keys 里有，但 filtered_before 没有的
    new_keys = [k for k in after_keys if k not in filtered_before]

    # 4. final 顺序 = 旧字段(到meta前) + 新特征 + 剩余旧字段(含meta.*及以后)
    final_order = filtered_before[:cut] + new_keys + filtered_before[cut:]

    # 5. 对每行按 final_order 重排
    aligned_rows: List[Dict[str, Any]] = []
    for row in enriched_rows:
        aligned = {}
        for key in final_order:
            aligned[key] = row.get(key, None)
        aligned_rows.append(aligned)

    return aligned_rows, final_order


# -------------------------------------------------
# 5. 主入口
# -------------------------------------------------

def run_step3_feature_engineering(cfg_step3: Dict[str, Any], global_data_cfg: Dict[str, Any]):
    """
    1. 读取 data/interim/preprocessed.json
    2. 按 snapshot_id + timestamp 排序
    3. 生成: 周期特征, 差分特征, 滑动窗口统计特征
    4. 新特征插到 meta.* 之前
    5. 覆盖写回 preprocessed.json + feature_list.json
    """
    if not cfg_step3.get("enabled", False):
        print("[step3] disabled, skip.")
        return

    interim_dir = Path(global_data_cfg["interim_dir"])
    ensure_dir(interim_dir)

    preproc_path = interim_dir / "preprocessed.json"
    featlist_path = interim_dir / "feature_list.json"

    if not preproc_path.is_file():
        raise FileNotFoundError(
            f"[step3] 找不到 {preproc_path}，请先运行 step1 和 step2"
        )

    with open(preproc_path, "r", encoding="utf-8") as f:
        rows_all: List[Dict[str, Any]] = json.load(f)

    if not rows_all:
        print("[step3] preprocessed.json 是空的，跳过")
        return

    # 解析子配置
    pf_cfg = cfg_step3.get("period_features", {})
    df_cfg = cfg_step3.get("diff_features", {})
    sf_cfg = cfg_step3.get("stat_features", {})

    # 我们要按 snapshot_id 分组，再按 meta.timestamp 排序
    # 注意 timestamp 目前是字符串形式 "1,760,241,605,000" ，需要去逗号再转int
    def _norm_ts(ts_raw: Any) -> int:
        try:
            return int(str(ts_raw).replace(",", ""))
        except Exception:
            return 0

    # 分组
    groups: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows_all:
        sid = r.get("meta.snapshot_id", "unknown")
        groups.setdefault(sid, []).append(r)

    # 对每个 snapshot 单独处理
    enhanced_rows_all: List[Dict[str, Any]] = []
    for sid, grp_rows in groups.items():
        # 排序
        grp_rows_sorted = sorted(
            grp_rows,
            key=lambda rr: _norm_ts(rr.get("meta.timestamp", 0))
        )

        # 1) 周期特征 (逐行，跟时间有关，和序列无关，直接做)
        periodic_chunk = [
            _gen_periodic_features_for_row(rr, pf_cfg) for rr in grp_rows_sorted
        ]

        # 2) 差分特征 (需要序列)
        #    只有在 diff_features.enabled 才会生成；否则是全空字典
        diff_chunk = _compute_diff_features_for_snapshot(
            grp_rows_sorted, df_cfg, sid
        )

        # 3) 滑动窗口统计特征 (需要序列)
        stat_chunk = _compute_stat_features_for_snapshot(
            grp_rows_sorted, sf_cfg, sid
        )

        # 合并
        merged_grp_rows = _merge_new_feats_per_row(
            base_rows=grp_rows_sorted,
            periodic_chunk=periodic_chunk,
            diff_chunk=diff_chunk,
            stat_chunk=stat_chunk,
        )

        enhanced_rows_all.extend(merged_grp_rows)

    # 现在 enhanced_rows_all 是无序拼回的（各组append）
    # 我们希望整体输出还是按 (snapshot_id, timestamp) 全局排序，方便肉眼看
    enhanced_rows_all_sorted = sorted(
        enhanced_rows_all,
        key=lambda rr: (
            str(rr.get("meta.snapshot_id", "unknown")),
            _norm_ts(rr.get("meta.timestamp", 0))
        )
    )

    # 对齐字段顺序并生成feature_list
    aligned_rows, final_feature_list = _order_and_update_feature_list(
        original_rows=rows_all,
        enriched_rows=enhanced_rows_all_sorted,
        meta_prefix="meta.",
    )

    # 写回 preprocessed.json / feature_list.json
    dump_json(aligned_rows, preproc_path)
    dump_json(final_feature_list, featlist_path)

    print(f"[step3] rows updated: {len(aligned_rows)}")
    print(f"[step3] feature_list updated ({len(final_feature_list)} fields)")
    print("[step3] done ✅")