# coding: utf-8
"""
step2_aggregate.py

功能：
- 从 step1 的产物 (preprocessed.json, feature_list.json) 读取样本
- 根据 YAML 里的 step2_aggregate 配置，对“同类设备的同类 metric”做聚合统计
- 生成新的聚合特征列（带全新且稳定的前缀，比如 agg_cpu_xxx_mean）
- 可选地 drop 掉被聚合的原始明细列（如 cpus.1.user, disk.7.throughput, ifs.eth0.rx.bytes ...）
- 按统一的字段顺序重写每条样本，并更新 feature_list.json

输入：
step2_cfg (dict):
  {
    "enabled": true,
    "groups": [
       {
         "name": "cpu_cores",
         "pattern": "^cpus\\.(?P<core_id>[0-9]+)\\.(?P<metric>[A-Za-z0-9_]+)$",
         "output_prefix": "agg_cpu_{metric}_{stat}",
         "stats": ["mean","max","std","sum"],
         "drop_raw": true
       },
       ...
    ]
  }

data_cfg (dict):
  {
    "interim_dir": "data/interim",
    ...
  }

产物（覆盖式写回 interim_dir）：
- preprocessed.json (每条样本字段已更新成"聚合后字段 + meta字段")
- feature_list.json (union_feature_list / per_snapshot_feature_list / meta_fields)
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Any, Tuple, Set


# --------------------------------------------------
# 常量：meta 字段固定放到最后并原样保留
# --------------------------------------------------
META_FIELDS = [
    "meta.timestamp",
    "meta.snapshot_id",
    "meta.period_ms",
    "meta.data_type",
]


# --------------------------------------------------
# 工具：安全转 float
# --------------------------------------------------
def _safe_float(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# --------------------------------------------------
# 工具：根据正则 groupdict 组装 metric 名称（不带设备ID）
# 规则：
#   - 若存在 dir=rx/tx 这类方向信息，拼成 "rx_bytes" 之类
#   - 仅保留度量语义(metric)，不保留 core_id/dev_id/mount/iface
#   - 用于最终聚合列命名
# --------------------------------------------------
def _compose_metric_name(gd: Dict[str, str]) -> str:
    """
    ex:
      gd = {"core_id":"3","metric":"user"} -> "user"
      gd = {"iface":"eth0","dir":"rx","metric":"bytes"} -> "rx_bytes"
      gd = {"mount":"/dev/sda1","metric":"used"} -> "used"
    """
    base_metric = gd.get("metric", "")

    dir_part = gd.get("dir")
    if dir_part:
        if base_metric:
            return f"{dir_part}_{base_metric}"
        else:
            return dir_part

    return base_metric


# --------------------------------------------------
# 计算一组数值的多种统计
# stats_list 例如 ["mean","max","std","sum"]
# --------------------------------------------------
def _compute_stats(vals: List[float], stats_list: List[str]) -> Dict[str, float]:
    import math
    out = {}
    if not vals:
        return out
    n = len(vals)
    s = sum(vals)
    mean_v = s / n

    # 预先准备可重用的统计
    if "mean" in stats_list:
        out["mean"] = mean_v
    if "max" in stats_list:
        out["max"] = max(vals)
    if "min" in stats_list:
        out["min"] = min(vals)
    if "sum" in stats_list:
        out["sum"] = s
    if "std" in stats_list or "var" in stats_list or "cvar" in stats_list or "skew" in stats_list or "kurt" in stats_list:
        # 方差
        var_v = sum((x - mean_v) ** 2 for x in vals) / n
        std_v = math.sqrt(var_v)
    else:
        var_v = None
        std_v = None

    if "var" in stats_list:
        out["var"] = var_v if var_v is not None else 0.0
    if "std" in stats_list:
        out["std"] = std_v if std_v is not None else 0.0

    # cvar我们定义成 “相对变化率”: (max - min) / (|mean|+eps)
    if "cvar" in stats_list:
        mx = max(vals)
        mn = min(vals)
        denom = abs(mean_v) + 1e-6
        out["cvar"] = (mx - mn) / denom

    # 偏度/峰度 (样本偏度/峰度的简单估计版本)
    if "skew" in stats_list or "kurt" in stats_list:
        if std_v is None or std_v == 0:
            m3 = 0.0
            m4 = 0.0
        else:
            diffs = [(x - mean_v) for x in vals]
            m3 = sum(d ** 3 for d in diffs) / n
            m4 = sum(d ** 4 for d in diffs) / n
        if "skew" in stats_list:
            if std_v and std_v != 0:
                out["skew"] = m3 / (std_v ** 3 + 1e-12)
            else:
                out["skew"] = 0.0
        if "kurt" in stats_list:
            if std_v and std_v != 0:
                out["kurt"] = m4 / (std_v ** 4 + 1e-12)
            else:
                out["kurt"] = 0.0

    return out


# --------------------------------------------------
# 对单条样本做一次聚合
# work_sample 是当前样本的原始 dict (会被就地更新/删字段/加字段)
# group_cfg:
#   {
#     "name": ...,
#     "pattern": "...",
#     "output_prefix": "agg_cpu_{metric}_{stat}",
#     "stats": ["mean","max","std",...],
#     "drop_raw": true
#   }
# --------------------------------------------------
def _aggregate_one_sample_once(
    work_sample: Dict[str, Any],
    group_cfg: Dict[str, Any],
) -> None:
    pat = re.compile(group_cfg["pattern"])
    output_prefix = group_cfg["output_prefix"]
    stats_list = group_cfg.get("stats", ["mean", "max", "std"])
    drop_raw = bool(group_cfg.get("drop_raw", True))

    # 收集：metric_name -> [values...]
    metric_vals: Dict[str, List[float]] = {}
    matched_fields_group: List[str] = []

    for k, v in list(work_sample.items()):
        m = pat.match(k)
        if not m:
            continue

        gd = m.groupdict()
        metric_name_for_key = _compose_metric_name(gd)
        if not metric_name_for_key:
            continue

        fv = _safe_float(v)
        if fv is None:
            continue

        metric_vals.setdefault(metric_name_for_key, []).append(fv)
        matched_fields_group.append(k)

    # 生成聚合列
    for metric_name, vals in metric_vals.items():
        stats_res = _compute_stats(vals, stats_list)
        for stat_name, stat_val in stats_res.items():
            out_key = output_prefix.format(metric=metric_name, stat=stat_name)
            work_sample[out_key] = stat_val

    # 根据配置，删除原始匹配列(那些细粒度字段)
    if drop_raw:
        for k in matched_fields_group:
            if k in work_sample:
                del work_sample[k]


# --------------------------------------------------
# 针对一条样本依次应用所有 group_cfg
# --------------------------------------------------
def _apply_all_groups_to_sample(
    sample: Dict[str, Any],
    groups_cfg: List[Dict[str, Any]],
) -> Dict[str, Any]:
    # work_sample 我们复制一份，避免直接改传进来的 reference
    work_sample = dict(sample)

    # 逐个 group 做聚合
    for gc in groups_cfg:
        _aggregate_one_sample_once(work_sample, gc)

    return work_sample


# --------------------------------------------------
# 最终的字段顺序整理：
# - 非 meta 字段全部按字母序
# - 再拼接 META_FIELDS (保持原顺序)
# 返回: (new_sample, ordered_keys)
# --------------------------------------------------
def _reorder_sample_fields(sample: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    keys = list(sample.keys())

    # 把meta剥离
    meta_part = [m for m in META_FIELDS if m in keys]
    body_part = [k for k in keys if k not in meta_part]

    # 字母序排序非meta部分
    body_part_sorted = sorted(body_part)

    ordered = body_part_sorted + meta_part
    out_sample = {k: sample.get(k, None) for k in ordered}
    return out_sample, ordered


# --------------------------------------------------
# 主入口：run_step2_aggregate
# 读取 step1 产物 -> 做聚合 -> 写回
# --------------------------------------------------
def run_step2_aggregate(step2_cfg: Dict[str, Any], data_cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    step2_cfg: dict for step2_aggregate
    data_cfg:  global data cfg, must contain interim_dir
    返回一个简要info报告，可写到pipeline_report["step2"]
    """
    if not step2_cfg.get("enabled", False):
        print("[step2] disabled, skip")
        return {"enabled": False}

    interim_dir = Path(data_cfg["interim_dir"])
    interim_dir.mkdir(parents=True, exist_ok=True)

    preproc_path = interim_dir / "preprocessed.json"
    featlist_path = interim_dir / "feature_list.json"

    # 读取 step1 的数据
    with open(preproc_path, "r", encoding="utf-8") as f:
        samples: List[Dict[str, Any]] = json.load(f)

    with open(featlist_path, "r", encoding="utf-8") as f:
        feat_info = json.load(f)

    per_snapshot_feature_list = feat_info.get("per_snapshot_feature_list", {})
    meta_fields = feat_info.get("meta_fields", META_FIELDS)

    groups_cfg = step2_cfg.get("groups", [])

    # --------------------------------------------------
    # 对每条样本跑聚合
    # --------------------------------------------------
    new_samples: List[Dict[str, Any]] = []
    # 我们还需要重新统计每台机器(snapshot_id)的特征集合
    new_per_snapshot: Dict[str, Set[str]] = {}

    for s in samples:
        # 1) 做聚合
        agg_s = _apply_all_groups_to_sample(s, groups_cfg)

        # 2) 重排字段顺序（非meta按字母序 + meta尾部）
        reordered_s, ordered_keys = _reorder_sample_fields(agg_s)
        new_samples.append(reordered_s)

        # 3) 更新 per_snapshot_feature_list
        sid = str(reordered_s.get("meta.snapshot_id", "unknown"))
        if sid not in new_per_snapshot:
            new_per_snapshot[sid] = set()
        for k in ordered_keys:
            if k in META_FIELDS:
                continue
            new_per_snapshot[sid].add(k)

    # union_feature_list: 全部特征（不含meta）
    union_feature_set: Set[str] = set()
    for sid, fset in new_per_snapshot.items():
        union_feature_set |= fset

    # 统一排序（稳定输出）
    union_feature_list_sorted = sorted(list(union_feature_set))

    # 每台 snapshot 的特征排序
    new_per_snapshot_sorted: Dict[str, List[str]] = {}
    for sid, fset in new_per_snapshot.items():
        new_per_snapshot_sorted[sid] = sorted(list(fset)) + META_FIELDS

    # --------------------------------------------------
    # 写回新的 preprocessed.json
    # --------------------------------------------------
    with open(preproc_path, "w", encoding="utf-8") as f_out:
        json.dump(new_samples, f_out, ensure_ascii=False, indent=2)

    # --------------------------------------------------
    # 写回新的 feature_list.json
    # 保留 meta_fields
    # per_snapshot_feature_list 现在是每台机子的字段顺序(含meta)
    # union_feature_list 只放非meta字段
    # --------------------------------------------------
    new_featlist_payload = {
        "union_feature_list": union_feature_list_sorted + META_FIELDS,
        "per_snapshot_feature_list": new_per_snapshot_sorted,
        "meta_fields": meta_fields,
    }

    with open(featlist_path, "w", encoding="utf-8") as f_feat:
        json.dump(new_featlist_payload, f_feat, ensure_ascii=False, indent=2)

    # info 报告
    info_report = {
        "enabled": True,
        "num_samples_in": len(samples),
        "num_samples_out": len(new_samples),
        "num_union_features_no_meta": len(union_feature_list_sorted),
        "num_snapshots": len(new_per_snapshot_sorted),
    }

    print("[step2] done. agg features generated, raw dropped where configured.")
    print(f"[step2] samples: {len(samples)} -> {len(new_samples)}")
    print(f"[step2] union(feats no meta): {len(union_feature_list_sorted)}")

    return info_report