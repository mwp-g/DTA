# src/data/utils.py
# -*- coding: utf-8 -*-
"""
数据预处理阶段的基础工具函数:
- 读取原始文件 (csv / xlsx)
- 推断/抽取关键字段 (timestamp, snapshot_id, period_ms, data_type, data列)
- 展开 data 列里的小字典
- 统一字段全集 & 字段顺序
- 导出 json(list[dict]) 和 feature_list.json
"""

from __future__ import annotations
from pathlib import Path
from typing import Dict, List, Any, Tuple, Optional
import json
import pandas as pd
import math

def read_table_auto(path: Path) -> pd.DataFrame:
    """
    根据后缀自动读取 csv 或 excel。
    要求原始文件中至少包含:
      - timestamp (或等价字段)
      - snapshot_id (或等价字段)
      - data_type
      - data (一列是一个小字典的字符串 or 已经是对象)
    """
    suf = path.suffix.lower()
    if suf in [".csv", ".txt"]:
        df = pd.read_csv(path)
    elif suf in [".xls", ".xlsx"]:
        df = pd.read_excel(path)
    else:
        raise ValueError(f"不支持的原始文件类型: {path}")
    return df


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def parse_possible_json(val: Any) -> Dict[str, Any]:
    """
    原始 data 列有时候是类似 '{"cpu.used":0.1,...}' 的字符串，
    有时候已经是dict；也可能是 NaN。
    这里统一把它转成 dict[str, Any]。
    """
    if isinstance(val, dict):
        return val
    if isinstance(val, str):
        val = val.strip()
        if val == "" or val.lower() == "nan":
            return {}
        try:
            return json.loads(val)
        except Exception:
            # 如果是非法json，尽量宽容，返回空
            return {}
    if val is None:
        return {}
    if isinstance(val, float) and math.isnan(val):
        return {}
    return {}


def pick_first_existing(row: pd.Series, candidates: List[str], default_val: Any = None) -> Any:
    """
    在一行记录里，按候选字段名顺序寻找第一个存在且非空的值。
    找不到就返回 default_val。
    """
    for key in candidates:
        if key in row and pd.notna(row[key]):
            return row[key]
    return default_val


def normalize_row_dict(
    data_fields: Dict[str, Any],
    timestamp_val: Any,
    snapshot_id_val: Any,
    period_ms_val: Any,
    data_type_val: Any,
) -> Dict[str, Any]:
    """
    把这一行整理成一个输出字典：
      1) 所有 data_fields 展开成同一层
      2) 附加 meta 字段: meta.timestamp / meta.snapshot_id / meta.period_ms / meta.data_type
    """
    out = dict(data_fields)

    # 注意: timestamp_val 可能是类似 "1,760,241,605,000" 这种带逗号的字符串
    # 这里我们不强制转 int，保留原值即可
    # meta.*
    out["meta.data_type"] = data_type_val
    out["meta.timestamp"] = timestamp_val
    out["meta.snapshot_id"] = snapshot_id_val
    out["meta.period_ms"] = period_ms_val
    
    return out


def build_full_field_order(rows_as_dicts: List[Dict[str, Any]], sort_fields: bool) -> List[str]:
    """
    rows_as_dicts 是多行的原始输出dict，还没有统一字段顺序。
    我们要确定一个统一的字段顺序(feature_list)，后续每一行都按它来重排。

    目标:
      - 除meta.*之外的普通特征字段先
      - 可以按字典序排序提升可读性(如果 sort_fields=True)
      - 再把固定的一些元字段放到最后，顺序稳定

    返回: feature_list (list[str])
    """
    all_keys = set()
    for d in rows_as_dicts:
        all_keys.update(d.keys())

    # 仅将 meta.* 视为后置字段
    meta_like_prefixes = ("meta.",)

    normal_keys = []
    meta_keys = []

    for k in all_keys:
        if k.startswith(meta_like_prefixes):
            meta_keys.append(k)
        else:
            normal_keys.append(k)

    if sort_fields:
        normal_keys.sort()
        meta_keys.sort()

    feature_list = normal_keys + meta_keys
    return feature_list


def reorder_dict_by_feature_list(d: Dict[str, Any], feature_list: List[str]) -> Dict[str, Any]:
    """
    按 feature_list 的顺序重排字典的键，缺失的字段补 None
    """
    new_d = {}
    for k in feature_list:
        new_d[k] = d.get(k, None)
    return new_d


def dump_json(obj: Any, path: Path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    print(f"[step1] saved -> {path}")
    
    
def _convert_to_native_types(obj):
    if isinstance(obj, dict):
        return {k: _convert_to_native_types(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_convert_to_native_types(v) for v in obj]
    elif hasattr(obj, "item") and callable(obj.item):
        return obj.item()
    else:
        return obj