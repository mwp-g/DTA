# -- coding: utf-8 --
"""
Step4: 特征相关性分析 + 特征筛选 + 最终落盘
输入:
data/interim/preprocessed.json (来自 step3 的结果)

输出:
data/interim/corr_matrix.json
data/interim/corr_top_targets.json
data/interim/corr_heatmap.png
data/interim/corr_dropped_features.json
data/interim/preprocessed.json        <-- 覆盖: 仅保留最终特征列 + meta.*
data/interim/feature_list.json        <-- 覆盖: 更新特征列表 (包含 meta.*)

行为：
1.  将 preprocessed.json 读入 DataFrame
2.  清洗不可用列（全NaN、常数列、非数值等）并记录删除原因
3.  计算皮尔逊/斯皮尔曼相关性
4.  根据 min_threshold_abs (绝对值下限阈值) 进一步标记“低相关性特征”
    •  如果某特征对所有 target 的相关性绝对值都 < 该阈值，则标记为 low_correlation
    •  这些特征将从最终数据中移除（meta.* 字段不移除）
5.  根据 max_threshold_abs (绝对值上限阈值) 标记“高相关性特征”
    •  如果某特征与任意其它特征的相关性绝对值 >= 该阈值，则标记为 high_correlation
    •  同样会从最终数据中移除（meta.* 字段不移除、target 不移除）
6.  输出删除报告（统计只针对非 meta 特征）
7.  用保留列+全部 meta.* 列 重写 preprocessed.json 和 feature_list.json
"""

from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple
import json
import math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from src.utils.io import ensure_dir


# -------------------------------------------------
# 工具: 加载原始 rows
# -------------------------------------------------
def _load_rows(interim_dir: Path) -> List[Dict[str, Any]]:
    preproc_path = interim_dir / "preprocessed.json"
    if not preproc_path.is_file():
        raise FileNotFoundError(f"[step4] 找不到 {preproc_path}，请先运行 step1/2/3")
    with open(preproc_path, "r", encoding="utf-8") as f:
        rows: List[Dict[str, Any]] = json.load(f)
    return rows


# -------------------------------------------------
# 步骤A: DataFrame构建 + 清洗 + 删除原因跟踪
# -------------------------------------------------
def _rows_to_dataframe_and_collect_dropinfo(
    rows: List[Dict[str, Any]],
    drop_meta_non_target: bool,
    target_cols: List[str],
    interim_dir: Path,
) -> Tuple[pd.DataFrame, Dict[str, Dict[str, str]], List[str], List[str], List[str]]:
    """
    返回:
    df_clean: 清洗后的数值特征 DataFrame（还没做阈值筛除）
    drop_report: {col: {"reason": "..."}}
    raw_nonmeta_cols: 原始的非meta列（含目标列）
    meta_cols: 原始里的 meta.* 列
    df_cols_now: df_clean 当前保留下来的列（用于后续统计）

    说明：
    - 所有统计都只针对非 meta.* 特征
    - 但是 meta.* 列仍被记录并最终保留到输出数据中
    """

    df = pd.DataFrame(rows)
    raw_all_cols = list(df.columns)
    MISSING_TOKENS = {"null", "NULL", "NaN", "nan", "N/A", "n/a", "None", "none", ""}
    df[raw_all_cols] = df[raw_all_cols].replace(list(MISSING_TOKENS), np.nan)
    meta_cols = [c for c in raw_all_cols if c.startswith("meta.")]
    nonmeta_cols_all = [c for c in raw_all_cols if not c.startswith("meta.")]

    drop_report: Dict[str, Dict[str, str]] = {}


    # 1. 如果 drop_meta_non_target=True，移除除目标列以外的 meta.* 字段
    #    注意: 这个只影响用于相关性计算的 df，不影响最后输出的 preprocessed.json
    if drop_meta_non_target:
        keep_cols_tmp = []
        for c in df.columns:
            if c in target_cols:
                keep_cols_tmp.append(c)
            elif c.startswith("meta."):
                # meta 字段被排除在相关性分析外
                drop_report.setdefault(c, {})["reason"] = "meta_field_excluded"
            else:
                keep_cols_tmp.append(c)
        df = df[keep_cols_tmp]

    # 2. 强制转数值
    for c in df.columns:
        if not np.issubdtype(df[c].dtype, np.number):
            df[c] = pd.to_numeric(df[c], errors="coerce")

    # 3. 删除全NaN列
    nan_cols = df.columns[df.isna().any()].tolist()
    for c in nan_cols:
        drop_report.setdefault(c, {})["reason"] = "all_nan"
    df = df.drop(columns=nan_cols)

    # 4. 删除常数列
    nunique = df.nunique(dropna=True)
    const_cols = nunique[nunique <= 1].index.tolist()
    for c in const_cols:
        drop_report.setdefault(c, {})["reason"] = "constant_value"
    df = df.drop(columns=const_cols)

    # 5. 用列均值填NaN
    for c in df.columns:
        if df[c].isna().any():
            df[c] = df[c].fillna(df[c].mean())

    # 此时 df.columns 是“干净的数值特征”，但可能还包含 meta (如果 drop_meta_non_target=False 或 meta 是 target)
    df_cols_now = list(df.columns)

    # 统计用：只考虑非meta列
    df_nonmeta_cols_now = [c for c in df_cols_now if not c.startswith("meta.")]
    raw_nonmeta_cols = [c for c in nonmeta_cols_all]  # 拷贝一份原始的非meta列

    print(
        f"[step4] basic clean:"
        f" raw_nonmeta={len(raw_nonmeta_cols)},"
        f" after_clean_nonmeta={len(df_nonmeta_cols_now)},"
        f" meta={len(meta_cols)}"
    )

    return df, drop_report, raw_nonmeta_cols, meta_cols, df_cols_now


# -------------------------------------------------
# 步骤B: 计算相关性矩阵
# -------------------------------------------------
def _compute_correlation_matrix(df: pd.DataFrame, corr_method: str) -> pd.DataFrame:
    if df.shape[1] < 2:
        print("[step4][warn] usable columns < 2, correlation might be empty.")
    if corr_method not in ("pearson", "spearman", "kendall"):
        print(f"[step4][warn] unsupported corr_method={corr_method}, fallback to pearson")
        corr_method = "pearson"
    return df.corr(method=corr_method)


# -------------------------------------------------
# 步骤C: 针对目标提取相关性
# -------------------------------------------------
def _extract_target_corr_only(
    corr_df: pd.DataFrame,
    target_cols: List[str],
) -> Dict[str, Dict[str, float]]:
    """
    返回:
    {
      "cpu.used": {
        "memory.used": 0.82,
        "cpu.user": 0.79,
        ...
      },
      ...
    }
    """
    result: Dict[str, Dict[str, float]] = {}
    for tgt in target_cols:
        if tgt not in corr_df.index or tgt not in corr_df.columns:
            continue
        tgt_corrs: Dict[str, float] = {}
        row = corr_df.loc[tgt]   # Series
        for feat_name, score in row.items():
            if feat_name == tgt:
                continue
            if isinstance(score, (float, int)) and not (
                isinstance(score, float) and math.isnan(score)
            ):
                tgt_corrs[feat_name] = float(score)
            else:
                tgt_corrs[feat_name] = None

        ordered = dict(
            sorted(
                tgt_corrs.items(),
                key=lambda kv: (0 if kv[1] is None else -abs(kv[1]), kv[0])
            )
        )
        result[tgt] = ordered

    return result


def _mark_reason_once(drop_report: Dict[str, Dict[str, str]], col: str, reason: str) -> None:
    if col not in drop_report or "reason" not in drop_report[col]:
        drop_report.setdefault(col, {})["reason"] = reason
        
# -------------------------------------------------
# 步骤D1: 低相关特征筛除 (基于最小绝对值阈值)
# -------------------------------------------------
def _apply_min_corr_threshold(
    corr_top_targets: Dict[str, Dict[str, float]],
    target_cols: List[str],
    min_threshold_abs: float,
    drop_report: Dict[str, Dict[str, str]],
    low_rule: str = "ALL",
    low_pct: float = 1.0,
) -> Set[str]:
    low_drop: Set[str] = set()
    if not min_threshold_abs or min_threshold_abs <= 0 or not corr_top_targets:
        return low_drop

    # 所有出现在任一 target 相关列表里的特征（不含目标自身）
    feat_pool: Set[str] = set()
    for tgt in target_cols:
        feat_pool.update(corr_top_targets.get(tgt, {}).keys())
    feat_pool -= set(target_cols)

    thr = float(min_threshold_abs)
    low_rule = str(low_rule).upper()
    low_pct = float(low_pct)

    for feat in feat_pool:
        vals = []
        for tgt in target_cols:
            v = corr_top_targets.get(tgt, {}).get(feat, None)
            if v is None or (isinstance(v, float) and np.isnan(v)):
                continue
            vals.append(abs(float(v)))

        if not vals:
            # 对所有 target 都拿不到数 -> 不动
            continue

        # 统计有多少目标“低于阈值”
        cnt_low = sum(1 for a in vals if a < thr)
        tot = len(vals)

        decide = False
        if low_rule == "ALL":
            decide = (cnt_low == tot)
        elif low_rule == "ANY":
            decide = (cnt_low >= 1)
        elif low_rule == "PCT":
            decide = (cnt_low / tot >= low_pct)
        else:
            decide = (cnt_low == tot)  # fallback ALL

        if decide:
            low_drop.add(feat)
            _mark_reason_once(drop_report, feat, f"low_correlation(<{min_threshold_abs})")
    return low_drop


# -------------------------------------------------
# 步骤D2: 高相关特征筛除 (基于最大绝对值阈值，防共线性)
# -------------------------------------------------
def _apply_max_corr_threshold(
    corr_top_targets: Dict[str, Dict[str, float]],
    target_cols: List[str],
    max_threshold_abs: float,
    drop_report: Dict[str, Dict[str, str]],
    high_rule: str = "ANY",
    high_pct: float = 0.5,
) -> Set[str]:
    high_drop: Set[str] = set()
    if not max_threshold_abs or max_threshold_abs <= 0 or not corr_top_targets:
        return high_drop

    feat_pool: Set[str] = set()
    for tgt in target_cols:
        feat_pool.update(corr_top_targets.get(tgt, {}).keys())
    feat_pool -= set(target_cols)

    thr = float(max_threshold_abs)
    high_rule = str(high_rule).upper()
    high_pct = float(high_pct)

    for feat in feat_pool:
        vals = []
        for tgt in target_cols:
            v = corr_top_targets.get(tgt, {}).get(feat, None)
            if v is None or (isinstance(v, float) and np.isnan(v)):
                continue
            vals.append(abs(float(v)))

        if not vals:
            continue

        cnt_high = sum(1 for a in vals if a >= thr)
        tot = len(vals)

        decide = False
        if high_rule == "ANY":
            decide = (cnt_high >= 1)
        elif high_rule == "ALL":
            decide = (cnt_high == tot)
        elif high_rule == "PCT":
            decide = (cnt_high / tot >= high_pct)
        else:
            decide = (cnt_high >= 1)  # fallback ANY

        if decide:
            high_drop.add(feat)
            _mark_reason_once(drop_report, feat, f"high_correlation(>={max_threshold_abs})")
    return high_drop


# -------------------------------------------------
# 步骤E: 画热力图
# -------------------------------------------------
def _plot_heatmap(
    corr_df: pd.DataFrame,
    out_path: Path,
    target_cols: List[str],
    only_targets: bool,
):
    if corr_df.empty:
        print("[step4][warn] corr_df 为空，无法绘图")
        return

    if only_targets and target_cols:
        rows = [t for t in target_cols if t in corr_df.index]
        cols = list(corr_df.columns)
        plot_df = corr_df.loc[rows, cols]
    else:
        plot_df = corr_df

    plt.figure(
        figsize=(
            max(6, 0.4 * plot_df.shape[1]),
            max(4, 0.4 * plot_df.shape[0]),
        )
    )
    im = plt.imshow(
        plot_df.values,
        aspect="auto",
        cmap="coolwarm",
        vmin=-1,
        vmax=1,
    )
    plt.colorbar(im, fraction=0.046, pad=0.04)
    plt.xticks(range(plot_df.shape[1]), plot_df.columns, rotation=90, fontsize=6)
    plt.yticks(range(plot_df.shape[0]), plot_df.index, fontsize=6)
    plt.title("Feature Correlation")
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()
    print(f"[step4] heatmap saved -> {out_path}")
    

def _summarize_corr_for_feature(feat: str, target_cols, corr_top_targets):
        out = {}
        for tgt in target_cols:
            v = corr_top_targets.get(tgt, {}).get(feat, None)
            out[tgt] = None if v is None or (isinstance(v, float) and np.isnan(v)) else float(v)
        return out

# -------------------------------------------------
# 步骤F: 根据保留列更新 preprocessed.json & feature_list.json
# -------------------------------------------------
def _save_filtered_data_and_feature_list(
    rows: List[Dict[str, Any]],
    kept_feature_cols_nonmeta: List[str],
    meta_cols_all: List[str],
    interim_dir: Path,
    target_cols: List[str],
):
    """
    1. 最终保留哪些列？
       - kept_feature_cols_nonmeta (清洗/相关性后剩下的非meta列)
       - 所有 meta.* 列 (无论相关性)
    2. 按这个列集合重写 preprocessed.json
    3. 同时写 feature_list.json（列名列表，包含 meta.*）
    """

    # 我们保持你之前的策略：非 meta.* 按字母序 + meta.* 按原次序
    final_keep_list = sorted(set(kept_feature_cols_nonmeta)) + meta_cols_all
    
    # final_keep_list = [c for c  in final_keep_list if c not in target_cols]

    filtered_rows: List[Dict[str, Any]] = []
    for r in rows:
        new_r = {}
        for k in final_keep_list:
            if k in r:
                new_r[k] = r[k]
            else:
                # 缺的填 None，保持字段齐全
                new_r[k] = None
        filtered_rows.append(new_r)

    # 覆盖写回 preprocessed.json
    preproc_path = interim_dir / "preprocessed.json"
    with open(preproc_path, "w", encoding="utf-8") as f:
        json.dump(filtered_rows, f, ensure_ascii=False, indent=2)
    print(f"[step4] updated preprocessed.json with {len(final_keep_list)} cols -> {preproc_path}")

    # 同步写 feature_list.json
    featlist_path = interim_dir / "feature_list.json"
    with open(featlist_path, "w", encoding="utf-8") as f:
        json.dump(final_keep_list, f, ensure_ascii=False, indent=2)
    print(f"[step4] updated feature_list.json -> {featlist_path}")


# -------------------------------------------------
# 步骤G: 主入口
# -------------------------------------------------
def run_step4_correlation(cfg_step4: Dict[str, Any], global_cfg: Dict[str, Any]):
    """
    cfg_step4: data.yaml 中 pipeline.step4_correlation 配置块
    global_cfg: 整体 data.yaml
    """
    if not cfg_step4.get("enabled", False):
        print("[step4] disabled, skip.")
        return

    data_cfg = global_cfg.get("data", global_cfg)  # 兼容 "data" 小节
    interim_dir = Path(data_cfg["interim_dir"])
    ensure_dir(interim_dir)

    # ---- 读取配置
    target_cols = cfg_step4.get("target_cols", [])
    drop_meta = bool(cfg_step4.get("drop_meta", True))
    target_corr_only = bool(cfg_step4.get("target_corr_only", True))
    heatmap_only_targets = bool(cfg_step4.get("heatmap_only_targets", True))
    corr_method = cfg_step4.get("corr_method", "pearson")
    low_rule  = cfg_step4.get("low_rule",  "ALL")
    low_pct   = float(cfg_step4.get("low_pct", 1.0))
    high_rule = cfg_step4.get("high_rule", "ANY")
    high_pct  = float(cfg_step4.get("high_pct", 0.5))

    # 绝对值相关性下限；<=0 表示关闭筛选
    min_threshold_abs = cfg_step4.get("min_threshold_abs", None)
    if min_threshold_abs is not None:
        try:
            min_threshold_abs = float(min_threshold_abs)
        except Exception:
            print(f"[step4][warn] invalid min_threshold_abs={min_threshold_abs}, fallback disable.")
            min_threshold_abs = None

    # 绝对值相关性上限；>=1 或 <=0 表示关闭筛选
    max_threshold_abs = cfg_step4.get("max_threshold_abs", None)
    if max_threshold_abs is not None:
        try:
            max_threshold_abs = float(max_threshold_abs)
        except Exception:
            print(f"[step4][warn] invalid max_threshold_abs={max_threshold_abs}, fallback disable.")
            max_threshold_abs = None

    # ---- 载入 step3 输出
    rows = _load_rows(interim_dir)
    if not rows:
        print("[step4] no rows, skip.")
        return

    # ---- A. 构建 DataFrame + 基础清洗
    (
        df_clean,
        drop_report,
        raw_nonmeta_cols,
        meta_cols_all,
        df_cols_now,
    ) = _rows_to_dataframe_and_collect_dropinfo(
        rows=rows,
        drop_meta_non_target=drop_meta,
        target_cols=target_cols,
        interim_dir=interim_dir,
    )
    # df_cols_now: 当前clean后保留的列（可能包含一些meta列，取决于drop_meta）
    df_nonmeta_cols_now = [c for c in df_cols_now if not c.startswith("meta.")]

    # ---- B. 计算相关性矩阵
    corr_df = _compute_correlation_matrix(df_clean, corr_method)

    # 写 corr_matrix.json
    corr_matrix_path = interim_dir / "corr_matrix.json"
    with open(corr_matrix_path, "w", encoding="utf-8") as f:
        json.dump(corr_df.to_dict(orient="index"), f, ensure_ascii=False, indent=2)
    print(f"[step4] corr_matrix saved -> {corr_matrix_path}")

    # ---- C. 针对目标提取相关性
    corr_top_targets = _extract_target_corr_only(corr_df, target_cols)
    corr_top_path = interim_dir / "corr_top_targets.json"
    with open(corr_top_path, "w", encoding="utf-8") as f:
        json.dump(corr_top_targets, f, ensure_ascii=False, indent=2)
    print(f"[step4] corr_top_targets saved -> {corr_top_path}")

    low_corr_drop_set  = _apply_min_corr_threshold(
        corr_top_targets=corr_top_targets,
        target_cols=target_cols,
        min_threshold_abs=min_threshold_abs,
        drop_report=drop_report,
        low_rule=low_rule,
        low_pct=low_pct,
    )

    high_corr_drop_set = _apply_max_corr_threshold(
        corr_top_targets=corr_top_targets,
        target_cols=target_cols,
        max_threshold_abs=max_threshold_abs,
        drop_report=drop_report,
        high_rule=high_rule,
        high_pct=high_pct,
    )

    # 合并两种删除集合
    drop_set_total = set(low_corr_drop_set) | set(high_corr_drop_set)
    # 我们不希望 meta.* 字段因为相关性被删
    drop_set_total = {c for c in drop_set_total if not c.startswith("meta.")}

    # ---- 计算最终“留下的非meta特征列”
    keep_cols_after_corr_nonmeta: List[str] = []
    for c in df_nonmeta_cols_now:
        if c in target_cols:
            # 目标列永远保留
            keep_cols_after_corr_nonmeta.append(c)
            continue
        if c in drop_set_total:
            # 被筛掉（弱相关 or 高相关）
            continue
        keep_cols_after_corr_nonmeta.append(c)

    # ---- E. 输出最终删除报告 corr_dropped_features.json
    final_drop_report_path = interim_dir / "corr_dropped_features.json"

    final_kept_nonmeta_count = len(keep_cols_after_corr_nonmeta)
    meta_cols_count = len(meta_cols_all)
    final_total_cols = final_kept_nonmeta_count + meta_cols_count

    # 在生成 summary 前：
    per_feat_corr = {}
    for feat in sorted(set(list(drop_report.keys()))):
        per_feat_corr[feat] = _summarize_corr_for_feature(feat, target_cols, corr_top_targets)

    summary = {
        "corr_method": corr_method,

        # 原始非meta特征数量（来自 step1-3 输出）
        "raw_feature_count_excluding_meta": len(raw_nonmeta_cols),

        # meta列一共有多少
        "meta_feature_count": meta_cols_count,

        # 基础清洗后还剩多少非meta特征（去掉NaN列、常数列等）
        "after_basic_clean_count_excluding_meta": len(df_nonmeta_cols_now),

        # 最终保留的非meta特征数量（再扣掉低/高相关的）
        "final_kept_nonmeta_count": final_kept_nonmeta_count,

        # 最终实际落盘的meta列数量
        "final_kept_meta_count": meta_cols_count,

        # 最终落盘总列数（非meta保留列 + 全部meta.*）
        "final_total_feature_count_including_meta": final_total_cols,

        # 阈值信息
        "min_threshold_abs": min_threshold_abs,
        "max_threshold_abs": max_threshold_abs,
        "low_rule": low_rule,
        "low_pct": low_pct,
        "high_rule": high_rule,
        "high_pct": high_pct,
        
        "per_feature_corr_to_targets": per_feat_corr,

        # 每个被删列 -> reason
        "dropped_so_far_count": len(drop_report),
        "dropped_features": drop_report,

        # 专门列出因为低相关 / 高相关被删除的特征（非meta）
        "low_corr_dropped_features": sorted(list(low_corr_drop_set)),
        "high_corr_dropped_features": sorted(list(high_corr_drop_set)),
    }

    with open(final_drop_report_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(
        "[step4] final kept non-meta="
        f"{final_kept_nonmeta_count} / raw_nonmeta={len(raw_nonmeta_cols)}, "
        f"meta_kept={meta_cols_count}, "
        f"final_total(cols_for_output)={final_total_cols}"
    )
    print(f"[step4] final drop report saved -> {final_drop_report_path}")

    # ---- F. 画热力图
    heatmap_path = interim_dir / "corr_heatmap.png"
    _plot_heatmap(
        corr_df=corr_df,
        out_path=heatmap_path,
        target_cols=target_cols,
        only_targets=heatmap_only_targets,
    )

    # 控制台打印每个target的前5高相关
    if target_corr_only:
        for tgt in target_cols:
            if tgt in corr_top_targets:
                pairs = [
                    (feat, score)
                    for feat, score in corr_top_targets[tgt].items()
                    if score is not None
                ]
                pairs_sorted = sorted(
                    pairs,
                    key=lambda kv: abs(kv[1]),
                    reverse=True
                )[:5]
                # 之前你把打印注释掉了，我保持一致，不强行print pairs_sorted

    # ---- G. 用最终保留列，重写 preprocessed.json & feature_list.json
    _save_filtered_data_and_feature_list(
        rows=rows,
        kept_feature_cols_nonmeta=keep_cols_after_corr_nonmeta,  # (去掉低/高相关后)
        meta_cols_all=meta_cols_all,                             # meta.* 全保留
        interim_dir=interim_dir,
        target_cols=target_cols,
    )

    print("[step4] done ✅")