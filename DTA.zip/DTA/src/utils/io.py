# -*- coding: utf-8 -*-
"""
src/utils/io.py
通用 I/O：YAML/JSON/Parquet、目录创建等
- 兼容 Python < 3.10 的类型写法（Union）
"""

from pathlib import Path
from typing import Union, Any, Dict
import json
import pandas as pd
def ensure_dir(p: Union[str, Path]) -> Path:
    p = Path(p)
    p.mkdir(parents=True, exist_ok=True)
    return p

def read_yaml(p: Union[str, Path]) -> Dict[str, Any]:
    import yaml
    with open(p, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def write_json(obj: Any, p: Union[str, Path]) -> None:
    p = Path(p)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def read_parquet(p: Union[str, Path]) -> pd.DataFrame:
    p = Path(p)
    return pd.read_parquet(p)

def read_json(p: Union[str, Path]):
    p = Path(p)
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)