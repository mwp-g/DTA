# -- coding: utf-8 --
"""
Trainer: 负责深度模型训练、验证、日志、早停、保存best。

功能：
1. 从 processed_dir 读取 scaler.json / feature_spec.json
2. 每个 epoch 打印两套指标：
   - 标准化空间：train loss / val loss（模型真正优化的loss，比如MSE）
   - 反归一化真实空间：
        overall mse / mae / mape%
        每个 target × 每个预测步 step 的 mse / mae / mape%
3. early stopping 基于标准化空间的 val loss
4. 保存 best 权重到 save_best_path
5. 训练结束后，自动把 best 权重重新评估一遍 val，并打印“BEST @ epochX 的真实指标”
"""

from __future__ import annotations

import json
import numpy as np
from pathlib import Path
from typing import Any, Dict, List, Tuple

import torch
import torch.nn as nn
from src.models.loss_func import LOSS_REGISTRY


class Trainer:
    def __init__(self, wrapper, train_cfg: dict):
        """
        wrapper: ForecastWrapper (含 .model (nn.Module), .save_best_weights(path), .load_best_weights(path, device))
        train_cfg: dict
            需要包含:
                batch_size, epochs, lr, patience, log_interval
                loss, save_best_path
                processed_dir (str)
                target_names (List[str])
                horizon_steps (int)
        """
        self.wrapper = wrapper
        self.model = wrapper.model  # nn.Module
        self.device = torch.device(wrapper.device if hasattr(wrapper, "device") else "cpu")
        self.model.to(self.device)
        self.scaler = train_cfg["scaler"]
        self.processed_dir = Path(train_cfg["processed_dir"])
        self.target_names: List[str] = list(train_cfg.get("target_names", []))
        self.horizon_steps: int = int(train_cfg.get("horizon_steps", 1))
        # ---- 基础训练超参 ----
        self.batch_size = int(train_cfg.get("batch_size", 64))
        self.epochs = int(train_cfg.get("epochs", 50))
        self.patience = int(train_cfg.get("patience", 5))
        # 我们还是保留 log_interval 字段，但现在会每个 epoch 都打印
        self.log_interval = int(train_cfg.get("log_interval", 1))
        self.save_best_path = train_cfg.get("save_best_path", "models/best.pt")

        # ---- 优化器 / 损失函数 ----
        lr = float(train_cfg.get("lr", 1e-3))
        loss_name = train_cfg.get("loss", "mse").lower()

        if loss_name in ("mse", "mae", "smoothl1"):
            # 保持原生 Pytorch loss
            if loss_name == "mse":
                self.criterion = nn.MSELoss()
            elif loss_name == "mae":
                self.criterion = nn.L1Loss()
            else:
                self.criterion = nn.SmoothL1Loss()

        else:
            # 通过注册表实例化自定义 loss
            if loss_name not in LOSS_REGISTRY:
                raise ValueError(f"Unknown loss: {loss_name}")

            LossCls = LOSS_REGISTRY[loss_name]

            if loss_name == "per_target_symmetric_asym_mse_smooth":
                # —— 按 target 定制阈值（写死）——
                # 注意：这些阈值在“标准化空间”下生效（与你训练时 Y 的空间一致）
                per_target_cfg = {
                    # 示例（按你的 target_names 改）：
                    "cpu.used": {"low_th": 0.25, "high_th": 0.45, "low_scale": 2.0, "high_scale": 2.0, "k": 20.0},
                    "cpu.user": {"low_th": 0.2, "high_th": 0.45, "low_scale": 2.0, "high_scale": 2.0, "k": 20.0},
                }
                default_cfg = {"low_th": 0.2, "high_th": 0.5, "low_scale": 2.0, "high_scale": 2.0, "k": 20.0}
                self.criterion = LossCls(
                    target_names=self.target_names,         # 你在 Trainer 里已有
                    per_target=per_target_cfg,
                    default=default_cfg,
                    reduction="mean",
                )
            else:
                # 其它自定义 loss：只有 reduction 参数
                self.criterion = LossCls(reduction="mean")
        
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)


        # 载入缩放信息 + 规格信息
        if self.scaler:
            self.scale_cfg = self._load_scaler_cfg(self.processed_dir)
        self.spec = self._load_spec(self.processed_dir)

    # ==================================================================
    # 读取 scaler / spec
    # ==================================================================
    def _load_scaler_cfg(self, processed_dir: Path) -> Dict[str, Any]:
        """
        读取 step8_scale 生成的 scaler.json.
        你的当前结构示例：
        {
            "method": "zscore",
            "scale_y": true,
            "feature_range": null,
            "x_params": {"mean":[...],"std":[...]},
            "y_params": {"mean":[...],"std":[...]},
            "num_features":65,
            "num_targets":1,
            "input_steps":30,
            "horizon_steps":3,
            "feature_names":[...],
            "target_names":[...]
        }
        """
        scaler_path = processed_dir / "scaler.json"
        with open(scaler_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _load_spec(self, processed_dir: Path) -> Dict[str, Any]:
        """
        读取 feature_spec.json
        """
        spec_path = processed_dir / "feature_spec.json"
        with open(spec_path, "r", encoding="utf-8") as f:
            return json.load(f)

    # ==================================================================
    # 反归一化 Y (适配你scaler.json的 y_params结构)
    # ==================================================================
    def _inverse_y(self, Y_scaled: np.ndarray) -> np.ndarray:
        """
        把网络输出/标签从标准化空间还原到真实物理单位。
        适配当前 scaler.json:
            method: "zscore"
            scale_y: true
            y_params: { "mean": [...], "std": [...] }
        同时兼容 potential future: minmax / maxabs
        """
        cfg = self.scale_cfg
        method = str(cfg.get("method", "zscore")).lower()
        scale_y = bool(cfg.get("scale_y", True))

        if not scale_y:
            return Y_scaled.copy()

        Y_scaled = np.asarray(Y_scaled, dtype=np.float32)
        _, _, O = Y_scaled.shape

        if method == "zscore":
            y_params = cfg.get("y_params", {})
            mean_vec = np.array(y_params.get("mean", np.zeros(O)), dtype=np.float32).reshape(1, 1, O)
            std_vec  = np.array(y_params.get("std",  np.ones(O)),  dtype=np.float32).reshape(1, 1, O)
            return Y_scaled * std_vec + mean_vec

        elif method == "minmax":
            y_params = cfg.get("y_params", {})
            min_vec = np.array(y_params.get("min", np.zeros(O)), dtype=np.float32).reshape(1, 1, O)
            max_vec = np.array(y_params.get("max", np.ones(O)),  dtype=np.float32).reshape(1, 1, O)
            return Y_scaled * (max_vec - min_vec) + min_vec

        elif method == "maxabs":
            y_params = cfg.get("y_params", {})
            maxabs_vec = np.array(y_params.get("max_abs", np.ones(O)), dtype=np.float32).reshape(1, 1, O)
            return Y_scaled * maxabs_vec

        else:
            # 未实现/未知的method
            return Y_scaled.copy()

    # ==================================================================
    # 安全MAPE
    # ==================================================================
    def _safe_mape(self, y_true: np.ndarray, y_pred: np.ndarray, eps: float = 1e-6) -> float:
        """
        sMAPE (Symmetric Mean Absolute Percentage Error)
        = mean( 2 * |pred - true| / (|pred| + |true| + eps) ) * 100
        特点:
        - 相对于传统 MAPE 对小真值更稳健
        - 结果范围 [0, 200]
        """
        y_true = np.asarray(y_true, dtype=np.float32)
        y_pred = np.asarray(y_pred, dtype=np.float32)

        # 有效样本掩码，避免除以极小数造成NaN
        mask = (np.abs(y_true) + np.abs(y_pred)) > eps
        if not np.any(mask):
            return 0.0

        num = 2.0 * np.abs(y_pred[mask] - y_true[mask])
        denom = np.abs(y_pred[mask]) + np.abs(y_true[mask]) + eps
        smape = np.mean(num / denom) * 100.0
        return float(smape)

    # ==================================================================
    # 计算一次验证集指标（标准化loss + 真实空间metrics）
    # ==================================================================
    def _eval_on_val(
        self,
        X_val: np.ndarray,
        Y_val: np.ndarray,
    ) -> Tuple[float, Dict[str, float], List[str]]:
        """
        对当前 self.model 进行推理和评估。
        返回:
            val_loss_epoch (float) - 标准化空间的loss
            overall_metrics (dict: mse/mae/mape in real space)
            per_lines (List[str]) - 每个 target@step 的明细行
        """
        self.model.eval()
        with torch.no_grad():
            
            xb_val = torch.tensor(X_val, dtype=torch.float32, device=self.device)
            yb_val = torch.tensor(Y_val, dtype=torch.float32, device=self.device)

            y_pred_val = self.model(xb_val)  # [Nv,H,O] (scaled)
            val_loss_epoch = self.criterion(y_pred_val, yb_val).item()

            # === 反归一化 ===
            y_true_scaled = yb_val.detach().cpu().numpy()   # [Nv,H,O]
            y_pred_scaled = y_pred_val.detach().cpu().numpy()

            if self.scaler:
                y_true_real = self._inverse_y(y_true_scaled)    # [Nv,H,O]
                y_pred_real = self._inverse_y(y_pred_scaled)
            else:
                y_true_real = y_true_scaled
                y_pred_real = y_pred_scaled

            # overall
            overall_mse = float(np.mean((y_pred_real - y_true_real) ** 2))
            overall_mae = float(np.mean(np.abs(y_pred_real - y_true_real)))
            overall_mape = self._safe_mape(y_true_real, y_pred_real)

            overall_metrics = {
                "mse": overall_mse,
                "mae": overall_mae,
                "mape": overall_mape,
            }

            # 逐 target × step
            Nv, H, O = y_true_real.shape
            per_lines = []
            for o in range(O):
                tname = self.target_names[o] if o < len(self.target_names) else f"target[{o}]"
                for h in range(H):
                    yt = y_true_real[:, h, o]
                    yp = y_pred_real[:, h, o]
                    mse_h = float(np.mean((yp - yt) ** 2))
                    mae_h = float(np.mean(np.abs(yp - yt)))
                    mape_h = self._safe_mape(yt, yp)
                    per_lines.append(
                        f"    - {tname} @ step{h}: mse={mse_h:.6f} mae={mae_h:.6f} mape%={mape_h:.3f}"
                    )

        return val_loss_epoch, overall_metrics, per_lines

    # ==================================================================
    # 单个epoch的训练
    # ==================================================================
    def _run_epoch_train(self, X_train: np.ndarray, Y_train: np.ndarray) -> float:
        """
        训练一个 epoch，返回平均训练loss（标准化空间）。
        """
        self.model.train()
        losses = []

        bs = self.batch_size
        num_train = X_train.shape[0]
        perm = np.random.permutation(num_train)

        for start in range(0, num_train, bs):
            end = start + bs
            batch_idx = perm[start:end]

            xb = torch.tensor(X_train[batch_idx], dtype=torch.float32, device=self.device)  # [B,T,F]
            yb = torch.tensor(Y_train[batch_idx], dtype=torch.float32, device=self.device)  # [B,H,O]

            self.optimizer.zero_grad()
            y_pred = self.model(xb)  # [B,H,O] (scaled)
            loss = self.criterion(y_pred, yb)
            loss.backward()
            self.optimizer.step()

            losses.append(loss.item())

        return float(np.mean(losses))

    # ==================================================================
    # 主训练循环
    # ==================================================================
    def fit(
        self,
        X_train: np.ndarray, Y_train: np.ndarray,
        X_val:   np.ndarray, Y_val:   np.ndarray,
    ) -> Dict[str, Any]:
        """
        X_train: [N,T,F] (scaled)
        Y_train: [N,H,O] (scaled)
        X_val  : [M,T,F]
        Y_val  : [M,H,O]

        流程：
        - for epoch:
            * _run_epoch_train -> train_loss_epoch
            * _eval_on_val     -> val_loss_epoch + 真实空间指标
            * 打印详细日志
            * early stopping 用 val_loss_epoch
              如果更好：保存权重到 save_best_path
        - 训练结束:
            * wrapper.load_best_weights(...)
            * 再跑一遍 _eval_on_val 得到 best 的真实指标
            * 打印 BEST 的详细日志
        """
        best_val_loss = float("inf")
        best_epoch = -1
        no_improve = 0

        for epoch in range(1, self.epochs + 1):
            # 1. train
            train_loss_epoch = self._run_epoch_train(X_train, Y_train)

            # 2. val (当前权重)
            val_loss_epoch, overall_metrics, per_lines = self._eval_on_val(X_val, Y_val)

            # 3. 日志（每个epoch都打）
            print(
                f"[epoch {epoch:03d}] "
                f"train={train_loss_epoch:.6f}  val={val_loss_epoch:.6f}"
            )
            print(
                "  overall(real-space): "
                f"mse={overall_metrics['mse']:.6f} "
                f"mae={overall_metrics['mae']:.6f} "
                f"mape%={overall_metrics['mape']:.3f}"
            )
            for line in per_lines:
                print(line)

            # 4. early stopping 基于 标准化空间 的 val_loss_epoch
            if val_loss_epoch < best_val_loss:
                best_val_loss = val_loss_epoch
                best_epoch = epoch
                no_improve = 0
                # 保存best权重
                self.wrapper.save_best_weights(self.save_best_path)
            else:
                no_improve += 1
                if no_improve >= self.patience:
                    print(f"[early stop] best_val={best_val_loss:.6f} at epoch={best_epoch}")
                    break

        # =========================================================
        # 训练结束后，用BEST权重做一次完整评估
        # =========================================================
        self.wrapper.load_best_weights(self.save_best_path, device=str(self.device))

        best_val_loss_epoch, best_overall_metrics, best_per_lines = self._eval_on_val(X_val, Y_val)

        print(
            f"[train] Training finished. best_val={best_val_loss:.6f} @ epoch={best_epoch}"
        )
        print(
            f"[train] Best weights saved -> {self.save_best_path}"
        )
        print(
            "[train] ==== BEST MODEL (val, real-space) ===="
        )
        print(
            "  overall(real-space): "
            f"mse={best_overall_metrics['mse']:.6f} "
            f"mae={best_overall_metrics['mae']:.6f} "
            f"mape%={best_overall_metrics['mape']:.3f}"
        )
        for line in best_per_lines:
            print(line)

        # 返回的信息里也附带 best 的真实空间指标
        return {
            "best_val": best_val_loss,
            "best_epoch": best_epoch,
            "save_best_path": self.save_best_path,
            "best_val_loss_epoch": best_val_loss_epoch,  # 标准化空间loss(再次eval)
            "best_overall_metrics": best_overall_metrics,
        }