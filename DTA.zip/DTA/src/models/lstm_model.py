# coding: utf-8
"""
src/models/lstm_model.py

定义 LSTMModel: 输入 [B, T, F] -> 输出 [B, H, O]

思路:
- 先用 LSTM 编码整个时间序列
- 取最后一个时刻的隐藏状态 (或者使用 pooling, 这里默认最后时刻)
- 用线性层映射到 H*O
- reshape 成 [B, H, O]
"""

from __future__ import annotations
import torch
import torch.nn as nn
from typing import Optional


class LSTMModel(nn.Module):
    def __init__(
        self,
        input_size: int,      # F
        hidden_size: int,
        num_layers: int,
        horizon_steps: int,   # H
        output_size: int,     # O
        dropout: float = 0.0,
    ):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.horizon_steps = horizon_steps
        self.output_size = output_size

        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,  # [B,T,F]
            dropout=dropout if num_layers > 1 else 0.0,
        )

        # 最后一个隐藏态 -> 线性 -> H*O
        self.head = nn.Linear(hidden_size, horizon_steps * output_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [B,T,F]
        return: [B,H,O]
        """
        out, (hn, cn) = self.lstm(x)  # out:[B,T,hidden], hn:[num_layers,B,hidden]
        last_h = hn[-1]               # [B, hidden_size], 用最后一层最后时刻隐状态
        pred = self.head(last_h)      # [B, H*O]
        pred = pred.view(-1, self.horizon_steps, self.output_size)  # [B,H,O]
        return pred