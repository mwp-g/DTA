# coding: utf-8
"""
src/models/transformer_model.py

定义 TransformerModel: 输入 [B, T, F] -> 输出 [B, H, O]

实现思路:
- 线性投影 F -> d_model
- 加一份可学习的位置编码 (learned positional embedding)
- TransformerEncoder 堆叠
- 对时序做 pooling (这里用最后时刻的 token 表示全局状态，和 LSTM 对齐)
- 线性到 H*O -> reshape [B,H,O]

注意: PyTorch的TransformerEncoder期望输入是 [T,B,d_model]，所以要转置。
"""

from __future__ import annotations
import torch
import torch.nn as nn
from typing import Optional


class PositionalEncodingLearned(nn.Module):
    """
    简单可学习位置编码: 每个时间步有一个可学习向量。
    """
    def __init__(self, d_model: int, max_len: int):
        super().__init__()
        self.pos_emb = nn.Embedding(max_len, d_model)
        nn.init.normal_(self.pos_emb.weight, std=0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [B,T,d_model]
        return x + pos
        """
        B, T, D = x.size()
        pos_ids = torch.arange(T, device=x.device).unsqueeze(0).expand(B, T)  # [B,T]
        pos_vec = self.pos_emb(pos_ids)  # [B,T,D]
        return x + pos_vec


class TransformerModel(nn.Module):
    def __init__(
        self,
        input_size: int,         # F
        d_model: int,
        nhead: int,
        num_layers: int,
        dim_feedforward: int,
        horizon_steps: int,      # H
        output_size: int,        # O
        dropout: float = 0.1,
        max_len: int = 512,
    ):
        super().__init__()
        self.input_size = input_size
        self.d_model = d_model
        self.nhead = nhead
        self.num_layers = num_layers
        self.dim_feedforward = dim_feedforward
        self.horizon_steps = horizon_steps
        self.output_size = output_size
        self.max_len = max_len

        # F -> d_model
        self.input_proj = nn.Linear(input_size, d_model)

        # learned positional encoding
        self.pos_encoder = PositionalEncodingLearned(d_model, max_len=max_len)

        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=False,   # we will send [T,B,D]
            activation="relu",
        )
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=num_layers)

        # pooling采用最后时刻的表示
        self.head = nn.Linear(d_model, horizon_steps * output_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [B,T,F]
        return: [B,H,O]
        """
        B, T, F = x.shape
        h = self.input_proj(x)         # [B,T,d_model]
        h = self.pos_encoder(h)        # [B,T,d_model]

        # TransformerEncoder expects [T,B,d_model]
        h = h.transpose(0, 1)          # [T,B,d_model]
        enc = self.encoder(h)          # [T,B,d_model]
        enc_last = enc[-1]             # [B,d_model] 取最后一个时间步

        out = self.head(enc_last)      # [B, H*O]
        out = out.view(B, self.horizon_steps, self.output_size)  # [B,H,O]
        return out