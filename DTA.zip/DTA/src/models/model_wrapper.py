# coding: utf-8
"""
src/models/model_wrapper.py

ForecastWrapper:
- 持有实际的 nn.Module (LSTMModel / TransformerModel)
- 记录可选的元信息 (feature_names / target_names / scaler_path / extra_config)
- 提供:
    .to(device)
    .load_best_weights(path, device)
    .save_best_weights(path)
    .predict(X_numpy) -> numpy [B,H,O]

注意：这个类的实例会被 joblib.dump() 成训练产物 (ts_model.joblib)。
权重(best_xxx.pt)并不包含在 joblib 里，仍是单独文件。

我们让元信息都是可选字段，是否保存由 train.yaml 的 export 段控制。
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional
from pathlib import Path

import torch
import numpy as np


class ForecastWrapper:
    def __init__(
        self,
        model_type: str,                     # "lstm" | "transformer"
        model: torch.nn.Module,              # 已构建好的 PyTorch 模型 (结构, 未必加载best权重)
        input_steps: int,                    # T
        horizon_steps: int,                  # H
        device: str = "cpu",

        # 以下为可选元信息，根据 export.* 决定是否写入
        feature_names: Optional[List[str]] = None,
        target_names: Optional[List[str]] = None,
        scaler_path: Optional[str] = None,
        extra_config: Optional[Dict[str, Any]] = None,
    ):
        self.model_type = model_type
        self.model = model

        self.input_steps = int(input_steps)
        self.horizon_steps = int(horizon_steps)

        self.device = torch.device(device)
        self.model.to(self.device)
        self.model.eval()

        # 这些是可选信息，可能是空/None
        self.feature_names = feature_names if feature_names is not None else []
        self.target_names = target_names if target_names is not None else []
        self.scaler_path = scaler_path if scaler_path is not None else ""
        self.extra_config = extra_config if extra_config is not None else {}

    # -------------------------------------------------
    # 设备 & 权重 I/O
    # -------------------------------------------------
    def to(self, device: str):
        """
        将模型切到指定device ("cpu", "cuda:3", ...)
        """
        self.device = torch.device(device)
        self.model.to(self.device)
        self.model.eval()

    def load_best_weights(self, ckpt_path: str, device: Optional[str] = None):
        """
        从best_xxx.pt加载权重。支持在CPU环境加载GPU训练的权重。
        device: 若指定，会在加载前调用 self.to(device)，并用 map_location=device。
        """
        if device is not None:
            self.to(device)
            map_loc = self.device
        else:
            map_loc = self.device

        state_dict = torch.load(ckpt_path, map_location=map_loc)
        self.model.load_state_dict(state_dict)
        self.model.eval()

    def save_best_weights(self, ckpt_path: str):
        """
        保存当前模型权重。通常在训练时 val_loss 最优时调用。
        """
        ckpt_path = str(ckpt_path)
        torch.save(self.model.state_dict(), ckpt_path)

    # -------------------------------------------------
    # 推理接口
    # -------------------------------------------------
    @torch.no_grad()
    def predict(self, X_np: np.ndarray) -> np.ndarray:
        """
        X_np: numpy, shape [B,T,F], 已经是scaled空间
        return: numpy, shape [B,H,O], 仍是scaled空间
        （反归一化在 evaluate / infer 里做）
        """
        self.model.eval()
        x = torch.tensor(X_np, dtype=torch.float32, device=self.device)
        y_hat = self.model(x)  # [B,H,O] torch
        return y_hat.detach().cpu().numpy()