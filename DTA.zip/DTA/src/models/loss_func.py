# coding: utf-8
"""
loss_func.py
自定义损失函数集合，支持 Trainer 通过注册表名实例化。
"""
from typing import Dict, List, Optional
import torch
import torch.nn as nn


class SymmetricAsymmetricMSELoss(nn.Module):
    """
    双端非对称MSE损失函数（硬阈值版）：
    - 当真实值高于 high_th 且预测偏低 => 惩罚更大
    - 当真实值低于 low_th  且预测偏高 => 惩罚更大
    参数固定（不从yaml读取）：
      low_th=0.1, high_th=0.6, low_scale=2.0, high_scale=2.0
    """
    def __init__(self, reduction: str = "mean"):
        super().__init__()
        self.low_th = 0.1
        self.high_th = 0.6
        self.low_scale = 2.0
        self.high_scale = 2.0
        self.reduction = reduction

    def forward(self, y_pred: torch.Tensor, y_true: torch.Tensor) -> torch.Tensor:
        # y_pred/y_true: [B,H,O] 或 [B,*]
        diff = y_true - y_pred
        base_loss = diff ** 2
        weight = torch.ones_like(y_true)

        # 高端：真实高、预测低 -> 加权
        mask_high = (y_true > self.high_th) & (y_pred < y_true)
        if mask_high.any():
            weight[mask_high] = 1 + self.high_scale * (y_true[mask_high] - y_pred[mask_high])

        # 低端：真实低、预测高 -> 加权
        mask_low = (y_true < self.low_th) & (y_pred > y_true)
        if mask_low.any():
            weight[mask_low] = 1 + self.low_scale * (y_pred[mask_low] - y_true[mask_low])

        loss = weight * base_loss
        if self.reduction == "mean":
            return loss.mean()
        if self.reduction == "sum":
            return loss.sum()
        return loss


class SymmetricAsymmetricMSELossSmooth(nn.Module):
    """
    双端非对称MSE（sigmoid平滑版）
    - 用 sigmoid 平滑“进入高端/低端区域”的指示
    - 仅在误差方向上放大（避免无意义增益）
    固定参数（不从yaml读取）：
      low_th=0.2, high_th=0.8, k=20.0, low_scale=2.0, high_scale=2.0
    """
    def __init__(self, reduction: str = "mean"):
        super().__init__()
        self.low_th = 0.2
        self.high_th = 0.6
        self.k = 20.0
        self.low_scale = 2.0
        self.high_scale = 2.0
        self.reduction = reduction

    def forward(self, y_pred: torch.Tensor, y_true: torch.Tensor) -> torch.Tensor:
        diff = y_true - y_pred
        base = diff ** 2

        # 高端：真实值高且 y_pred 偏低 -> 放大
        enter_high = torch.sigmoid(self.k * (y_true - self.high_th))
        under_high = torch.relu(y_true - y_pred)
        high_weight = 1 + self.high_scale * (enter_high * under_high)

        # 低端：真实值低且 y_pred 偏高 -> 放大
        enter_low = torch.sigmoid(self.k * (self.low_th - y_true))
        over_low = torch.relu(y_pred - y_true)
        low_weight = 1 + self.low_scale * (enter_low * over_low)

        w = high_weight * low_weight
        loss = w * base

        if self.reduction == "mean":
            return loss.mean()
        if self.reduction == "sum":
            return loss.sum()
        return loss


class PerTargetSymAsymMSELossSmooth(nn.Module):
    """
    多 target 版本的双端非对称 MSE（sigmoid 平滑）
    - 为每个 target（O 维）指定不同的 low_th/high_th/low_scale/high_scale/k
    - 参数固定写在代码里（不读 yaml）
    - y_pred / y_true 形状：[B, H, O]
    """
    def __init__(
        self,
        target_names: List[str],
        per_target: Dict[str, Dict[str, float]],
        default: Optional[Dict[str, float]] = None,
        reduction: str = "mean",
    ):
        super().__init__()
        self.target_names = list(target_names)
        self.reduction = reduction

        if default is None:
            default = dict(low_th=0.2, high_th=0.8, low_scale=2.0, high_scale=2.0, k=20.0)

        low_th_list, high_th_list = [], []
        low_scale_list, high_scale_list, k_list = [], [], []
        for t in self.target_names:
            cfg = per_target.get(t, {})
            low_th_list.append(float(cfg.get("low_th",     default["low_th"])))
            high_th_list.append(float(cfg.get("high_th",   default["high_th"])))
            low_scale_list.append(float(cfg.get("low_scale", default["low_scale"])))
            high_scale_list.append(float(cfg.get("high_scale", default["high_scale"])))
            k_list.append(float(cfg.get("k",               default["k"])))

        # 注册为 buffer，随 .to(device) 自动迁移；形状 [1,1,O] 便于广播到 [B,H,O]
        self.register_buffer("low_th_vec",     torch.tensor(low_th_list,     dtype=torch.float32).view(1, 1, -1))
        self.register_buffer("high_th_vec",    torch.tensor(high_th_list,    dtype=torch.float32).view(1, 1, -1))
        self.register_buffer("low_scale_vec",  torch.tensor(low_scale_list,  dtype=torch.float32).view(1, 1, -1))
        self.register_buffer("high_scale_vec", torch.tensor(high_scale_list, dtype=torch.float32).view(1, 1, -1))
        self.register_buffer("k_vec",          torch.tensor(k_list,          dtype=torch.float32).view(1, 1, -1))

    def forward(self, y_pred: torch.Tensor, y_true: torch.Tensor) -> torch.Tensor:
        # 保障与输入同 dtype/同 device（即使上层忘了对 loss 调 .to(device) 也能工作）
        dev, dt = y_true.device, y_true.dtype
        low_th     = self.low_th_vec.to(device=dev, dtype=dt)
        high_th    = self.high_th_vec.to(device=dev, dtype=dt)
        low_scale  = self.low_scale_vec.to(device=dev, dtype=dt)
        high_scale = self.high_scale_vec.to(device=dev, dtype=dt)
        k          = self.k_vec.to(device=dev, dtype=dt)

        diff = y_true - y_pred
        base = diff ** 2

        # 高端：真实高且预测偏低 -> 放大（平滑进入高端区域）
        enter_high = torch.sigmoid(k * (y_true - high_th))
        under_high = torch.relu(y_true - y_pred)        # 只放大预测低于真实的方向
        high_weight = 1 + high_scale * (enter_high * under_high)

        # 低端：真实低且预测偏高 -> 放大（平滑进入低端区域）
        enter_low = torch.sigmoid(k * (low_th - y_true))
        over_low = torch.relu(y_pred - y_true)          # 只放大预测高于真实的方向
        low_weight = 1 + low_scale * (enter_low * over_low)

        w = high_weight * low_weight
        loss = w * base

        if self.reduction == "mean":
            return loss.mean()
        if self.reduction == "sum":
            return loss.sum()
        return loss


# —— 注册表：Trainer 里通过名字实例化 ——
LOSS_REGISTRY = {
    "symmetric_asym_mse": SymmetricAsymmetricMSELoss,
    "symmetric_asym_mse_smooth": SymmetricAsymmetricMSELossSmooth,
    # 多 target 版本（需要额外传 target_names/per_target）
    "per_target_symmetric_asym_mse_smooth": PerTargetSymAsymMSELossSmooth,
}