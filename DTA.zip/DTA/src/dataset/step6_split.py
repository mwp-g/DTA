# coding: utf-8
"""
src/dataset/step6_split.py

Step6: 数据集划分 (train / val / test / extra_test)

输入 (由 step6 产出，已经在 processed_dir 内):
- X_balanced.npy
- Y_balanced.npy
- index_balanced.json
  其中 index_balanced[i] 对应 X_balanced[i], Y_balanced[i]

index_balanced.json 每条样本应至少包含：
{
  "index": <int>,             # 原始全局索引（保持透传）
  "snapshot_id": "<machine>", # 机器码
  "segment_id": "<seg>",      # 时间段ID
  "start_ts": 1760123456000,  # 毫秒时间戳（int/float皆可）
  ... 其他字段随文件透传 ...
}

本步骤会：
1. 按 segment 切 fragment，给每行添加 "fragment_id"
   - 同一个 (snapshot_id, segment_id) 内按 start_ts 升序
   - 用 fragment.fragment_length_minutes 切时间片，每片给出 fragment_id
   - fragment_id 在同一 segment 内从0开始编号 (字符串)
2. 根据 split.mode 做划分:
   - "random"    : 打乱样本级别后按比例切 train/val/test
   - "temporal"  : 样本按 start_ts 排序后按比例切
   - "fragment"  : 以 fragment 为最小单位随机分配
3. 支持 holdout_snapshots:
   - 若 split.holdout_snapshots 列表非空：
     这些 snapshot_id 对应的全量样本不会进 train/val/test，
     而是组成额外集合 extra_test
   - 如果 holdout_snapshots 为空，则不生成 extra_test
4. 输出到 processed_dir:
   - X_train.npy / Y_train.npy
   - X_val.npy   / Y_val.npy
   - X_test.npy  / Y_test.npy
   - (可选) X_extra_test.npy / Y_extra_test.npy
   - index_train.json / index_val.json / index_test.json / (index_extra_test.json)
   - split_indices.json
     {
       "train": {
         "<snapshot_id>": {
           "<segment_id>": {
             "<fragment_id>": [idx0, idx1, ...]
           }
         }
       },
       "val": { ... },
       "test": { ... },
       "extra_test": { ... }    # 仅当有holdout_snapshots时才存在
     }

配置 (dataset.yaml 中的 split 段落示例):
split:
  enabled: true
  mode: "fragment"        # "random" | "temporal" | "fragment"
  train_ratio: 0.7
  val_ratio:   0.15
  test_ratio:  0.15
  random_seed: 42

  holdout_snapshots: []   # ["SNAP_A", "SNAP_B"] -> 这些整机数据将成为 extra_test

  fragment:
    fragment_length_minutes: 30    # 单个 fragment 的时间跨度(分钟)
    fragment_min_points: 1         # fragment最少多少点 (目前不会丢弃)

返回:
info(dict)，供 build_dataset.py 记录到 pipeline_report["step6"]
"""

from __future__ import annotations
from typing import List, Dict, Any, Tuple
from pathlib import Path
import json
import math
import random
import os
import numpy as np


# ---------------------------------------
# 基础IO
# ---------------------------------------

def _read_json(path: Path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _write_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def _ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


# ---------------------------------------
# fragment 切分相关
# ---------------------------------------

def _cut_fragments_for_segment(
    rows: List[Dict[str, Any]],
    fragment_length_minutes: float,
    fragment_min_points: int,
) -> List[Dict[str, Any]]:
    """
    输入: 同一 (snapshot_id, segment_id) 的 rows，必须已按 start_ts 升序
    输出: list[
      {
        "fragment_id": "0",
        "rows": [row0, row1, ...]  # row为引用, 会回写 fragment_id
      },
      ...
    ]

    逻辑:
    - 用 rows[0]["start_ts"] 当作当前fragment起点 t0
    - 后续样本如果 (start_ts - t0) <= fragment_length_minutes*60*1000 则仍在同一个fragment
      否则开新fragment
    - fragment_id 在该 segment 内从0开始递增
    - 我们目前不会因为 fragment_min_points 太小而丢弃fragment
    """
    if not rows:
        return []

    ms_per_frag = fragment_length_minutes * 60 * 1000.0

    frags: List[Dict[str, Any]] = []
    cur_rows: List[Dict[str, Any]] = []
    cur_t0 = rows[0]["start_ts"]
    frag_idx = 0

    for r in rows:
        ts = r["start_ts"]
        if (ts - cur_t0) <= ms_per_frag or len(cur_rows) == 0:
            # 同一fragment
            cur_rows.append(r)
        else:
            # 关闭上一个fragment
            frags.append({
                "fragment_id": str(frag_idx),
                "rows": cur_rows,
            })
            frag_idx += 1
            # 开新fragment
            cur_rows = [r]
            cur_t0 = ts

    # 收尾
    if cur_rows:
        frags.append({
            "fragment_id": str(frag_idx),
            "rows": cur_rows,
        })

    # 目前不做 fragment_min_points 过滤，全部保留
    return frags


def _attach_fragment_ids(
    index_items: List[Dict[str, Any]],
    fragment_cfg: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """
    给每条样本打上 "fragment_id" 字段。
    步骤:
    1. 按 (snapshot_id, segment_id) 分组
    2. 组内按 start_ts 排序
    3. 调用 _cut_fragments_for_segment 生成 fragment
    4. 回写 fragment_id
    """
    fragment_length_minutes = fragment_cfg.get("fragment_length_minutes", 30)
    fragment_min_points = fragment_cfg.get("fragment_min_points", 1)

    # (snapshot_id, segment_id) -> rows
    groups: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for item in index_items:
        key = (item["snapshot_id"], item["segment_id"])
        groups.setdefault(key, []).append(item)

    for (_snap, _seg), rows in groups.items():
        rows_sorted = sorted(rows, key=lambda r: r["start_ts"])
        frags = _cut_fragments_for_segment(
            rows_sorted,
            fragment_length_minutes=fragment_length_minutes,
            fragment_min_points=fragment_min_points,
        )
        # frags: [{"fragment_id": "0", "rows":[...]}]
        for frag in frags:
            fid = frag["fragment_id"]
            for r in frag["rows"]:
                r["fragment_id"] = fid

    return index_items


# ---------------------------------------
# 拆出holdout机器 (extra_test)
# ---------------------------------------

def _separate_holdout(
    items: List[Dict[str, Any]],
    holdout_snapshots: List[str],
):
    """
    把 items 分成:
    - remain: 非 holdout 机器
    - extra:  holdout 机器 (整机全量样本，后面叫 extra_test)
    """
    if not holdout_snapshots:
        return items, []

    holdout_set = set(holdout_snapshots)
    extra = [it for it in items if it["snapshot_id"] in holdout_set]
    remain = [it for it in items if it["snapshot_id"] not in holdout_set]
    return remain, extra


# ---------------------------------------
# 三种划分模式
# ---------------------------------------

def _split_random(
    items: List[Dict[str, Any]],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    seed: int,
):
    """
    随机打乱逐条样本划分
    """
    rnd = random.Random(seed)
    shuffled = items[:]
    rnd.shuffle(shuffled)

    n = len(shuffled)
    n_train = int(math.floor(n * train_ratio))
    n_val = int(math.floor(n * val_ratio))
    n_test = n - n_train - n_val

    train_set = shuffled[:n_train]
    val_set   = shuffled[n_train:n_train + n_val]
    test_set  = shuffled[n_train + n_val : n_train + n_val + n_test]

    return {
        "train": train_set,
        "val":   val_set,
        "test":  test_set,
    }


def _split_temporal(
    items: List[Dict[str, Any]],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
):
    """
    按 start_ts 升序后切比例
    """
    sorted_items = sorted(items, key=lambda r: r["start_ts"])
    n = len(sorted_items)
    n_train = int(math.floor(n * train_ratio))
    n_val = int(math.floor(n * val_ratio))
    n_test = n - n_train - n_val

    train_set = sorted_items[:n_train]
    val_set   = sorted_items[n_train:n_train + n_val]
    test_set  = sorted_items[n_train + n_val : n_train + n_val + n_test]

    return {
        "train": train_set,
        "val":   val_set,
        "test":  test_set,
    }


def _split_fragment_mode(
    items: List[Dict[str, Any]],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    seed: int,
):
    """
    fragment 模式:
    - 以 fragment 为最小单位划分，不打散同一个 fragment_id
    实现：
    1. (snapshot_id, segment_id, fragment_id) -> 收集 rows
    2. 把这些 fragment-level 块打乱并分配到 train/val/test
    3. 再把块展开成样本列表
    """
    frag_map: Dict[Tuple[str, str, str], List[Dict[str, Any]]] = {}
    for r in items:
        key = (r["snapshot_id"], r["segment_id"], r["fragment_id"])
        frag_map.setdefault(key, []).append(r)

    frag_list = []
    for key, rows in frag_map.items():
        frag_list.append({"key": key, "rows": rows})

    rnd = random.Random(seed)
    rnd.shuffle(frag_list)

    n = len(frag_list)
    n_train = int(math.floor(n * train_ratio))
    n_val = int(math.floor(n * val_ratio))
    n_test = n - n_train - n_val

    frag_train = frag_list[:n_train]
    frag_val   = frag_list[n_train:n_train + n_val]
    frag_test  = frag_list[n_train + n_val : n_train + n_val + n_test]

    def _collect_rows(parts):
        out = []
        for f in parts:
            out.extend(f["rows"])
        return out
    return {
        "train": _collect_rows(frag_train),
        "val":   _collect_rows(frag_val),
        "test":  _collect_rows(frag_test),
    }


# ---------------------------------------
# 写盘辅助
# ---------------------------------------

def _save_split_arrays(
    out_dir: Path,
    X_all: np.ndarray,
    Y_all: np.ndarray,
    index_items: List[Dict[str, Any]],
    split_dict: Dict[str, List[Dict[str, Any]]],
    has_extra_test: bool,
):
    """
    对每个 split (train/val/test/extra_test):
    通过 (snapshot_id, segment_id, index) → 在 index_all.json(此处传入的 index_items) 中
    定位到全局样本行号，再到 X_all/Y_all 中取样并保存。
    """

    # 1) 建立三元组 -> 全局行号 的映射（index_items 即 step5 的 index_all.json 内容）
    global_map = {
        (str(it.get("snapshot_id")), str(it.get("segment_id")), int(it.get("index"))): i
        for i, it in enumerate(index_items)
    }

    # 2) 根据 split 的 rows，用三元组查回全局行号，再切片
    def gather_xy(rows: List[Dict[str, Any]]):
        idxs = []
        miss = 0
        for r in rows:
            key = (str(r.get("snapshot_id")), str(r.get("segment_id")), int(r.get("index")))
            gid = global_map.get(key, None)
            if gid is None:
                miss += 1
                # 不中断：记录缺失，继续
            else:
                idxs.append(gid)

        if miss > 0:
            print(f"[step6][warn] {miss} rows not found in index_all by (snapshot,segment,index).")

        if not idxs:
            # 返回形状正确的空数组，避免后续保存时报错
            return (
                np.zeros((0,) + X_all.shape[1:], dtype=X_all.dtype),
                np.zeros((0,) + Y_all.shape[1:], dtype=Y_all.dtype),
            )

        # idxs = sorted(idxs)  # 稳定顺序（可选）
        return X_all[idxs], Y_all[idxs]

    # 3) 常规 split 写盘
    for split_name in ["train", "val", "test"]:
        rows = split_dict.get(split_name, [])
        if rows:
            Xp, Yp = gather_xy(rows)
            np.save(out_dir / f"X_{split_name}.npy", Xp)
            np.save(out_dir / f"Y_{split_name}.npy", Yp)

    if has_extra_test:
        rows = split_dict.get("extra_test", [])
        if rows:
            Xp, Yp = gather_xy(rows)
            np.save(out_dir / "X_extra_test.npy", Xp)
            np.save(out_dir / "Y_extra_test.npy", Yp)


def _save_split_indices_json(
    out_dir: Path,
    split_dict: Dict[str, List[Dict[str, Any]]],
    has_extra_test: bool,
):
    """
    index_{split}.json:
    直接把样本的元信息写出去，包括 fragment_id / segment_id / snapshot_id / index / start_ts 等
    """
    for split_name in ["train", "val", "test"]:
        rows = split_dict.get(split_name, [])
        if rows:
            _write_json(out_dir / f"index_{split_name}.json", rows)

    if has_extra_test:
        rows = split_dict.get("extra_test", [])
        if rows:
            _write_json(out_dir / "index_extra_test.json", rows)


def _nest_split_structure(
    split_dict: Dict[str, List[Dict[str, Any]]],
    has_extra_test: bool,
) -> Dict[str, Any]:
    """
    构造 split_indices.json 的嵌套结构:
    split -> snapshot_id -> segment_id -> fragment_id -> [index...]
    """
    def build_for_rows(rows: List[Dict[str, Any]]):
        out_level1: Dict[str, Dict[str, Dict[str, List[int]]]] = {}
        for r in rows:
            snap = r["snapshot_id"]
            seg  = r["segment_id"]
            fid  = r.get("fragment_id", "0")
            idx  = int(r["index"])

            out_level1.setdefault(snap, {})
            out_level1[snap].setdefault(seg, {})
            out_level1[snap][seg].setdefault(fid, [])
            out_level1[snap][seg][fid].append(idx)
        return out_level1

    result = {}
    for split_name in ["train", "val", "test"]:
        rows = split_dict.get(split_name, [])
        result[split_name] = build_for_rows(rows)

    if has_extra_test:
        rows = split_dict.get("extra_test", [])
        result["extra_test"] = build_for_rows(rows)

    return result


def _save_split_structure(
    out_dir: Path,
    split_dict: Dict[str, List[Dict[str, Any]]],
    has_extra_test: bool,
):
    nested = _nest_split_structure(split_dict, has_extra_test=has_extra_test)
    _write_json(out_dir / "split_indices.json", nested)


# ---------------------------------------
# 主入口：供 build_dataset.py 调用
# ---------------------------------------

def run_step6_split(ds_cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    只接收 ds_cfg (dataset.yaml 解析出来的整个字典)，
    与 build_dataset.py 保持兼容。

    该函数会：
    - 自动从 ds_cfg["data"]["processed_dir"] 读取 step6 产物
    - 生成 train/val/test/(extra_test)
    - 将所有结果写回 processed_dir
    - 返回一个info字典（方便 build_dataset.py 记录 pipeline_report["step6"]）
    """
    # --------------------------
    # 1. 解析配置
    # --------------------------
    data_sec = ds_cfg["output"]
    split_sec = ds_cfg["split"]

    processed_dir = Path(data_sec["processed_dir"])
    _ensure_dir(processed_dir)

    mode = split_sec.get("mode", "fragment")  # "random" | "temporal" | "fragment"
    train_ratio = float(split_sec.get("train_ratio", 0.7))
    val_ratio   = float(split_sec.get("val_ratio", 0.15))
    test_ratio  = float(split_sec.get("test_ratio", 0.15))
    seed        = int(split_sec.get("random_seed", 42))

    holdout_snapshots = split_sec.get("holdout_snapshots", [])

    fragment_cfg = split_sec.get("fragment", {
        "fragment_length_minutes": 30,
        "fragment_min_points": 1,
    })

    # --------------------------
    # 2. 加载 step5 的产物
    # --------------------------
    # if os.path.exists(processed_dir / "X_balanced.npy"):
    #     X_all = np.load(processed_dir / "X_balanced.npy")
    #     Y_all = np.load(processed_dir / "Y_balanced.npy")
    #     index_items: List[Dict[str, Any]] = _read_json(processed_dir / "index_balanced.json")
    #     org_items: List[Dict[str, Any]] = _read_json(processed_dir / "index_balanced.json")
    # else:
    X_all = np.load(processed_dir / "X_all.npy")
    Y_all = np.load(processed_dir / "Y_all.npy")
    index_items: List[Dict[str, Any]] = _read_json(processed_dir / "index_all.json")
    org_items: List[Dict[str, Any]] = _read_json(processed_dir / "index_all.json")

    # --------------------------
    # 3. 给样本打 fragment_id
    # --------------------------
    index_items = _attach_fragment_ids(index_items, fragment_cfg)

    # --------------------------
    # 4. 分离 holdout 机器 -> extra_test
    # --------------------------
    remain_items, extra_items = _separate_holdout(index_items, holdout_snapshots)

    has_extra_test = len(extra_items) > 0

    # --------------------------
    # 5. 对 remain_items 做划分 (train/val/test)
    # --------------------------
    if mode == "random":
        split_main = _split_random(
            remain_items, train_ratio, val_ratio, test_ratio, seed
        )
    elif mode == "temporal":
        split_main = _split_temporal(
            remain_items, train_ratio, val_ratio, test_ratio
        )
    elif mode == "fragment":
        split_main = _split_fragment_mode(
            remain_items, train_ratio, val_ratio, test_ratio, seed
        )
    else:
        raise ValueError(f"unsupported split.mode: {mode}")

    # --------------------------
    # 6. 将 extra_test 挂到 split_main
    # --------------------------
    if has_extra_test:
        split_main["extra_test"] = extra_items

    # --------------------------
    # 7. 保存 X_*.npy / Y_*.npy
    # --------------------------
    _save_split_arrays(
        processed_dir,
        X_all, Y_all, org_items,
        split_dict=split_main,
        has_extra_test=has_extra_test,
    )

    # --------------------------
    # 8. 保存 index_*.json
    # --------------------------
    _save_split_indices_json(
        processed_dir,
        split_dict=split_main,
        has_extra_test=has_extra_test,
    )

    # --------------------------
    # 9. 保存 split_indices.json (嵌套版)
    # --------------------------
    _save_split_structure(
        processed_dir,
        split_dict=split_main,
        has_extra_test=has_extra_test,
    )

    # --------------------------
    # 10. 产出一个info，给pipeline_report记录
    # --------------------------
    info = {
        "status": "ok",
        "mode": mode,
        "train_size": len(split_main.get("train", [])),
        "val_size": len(split_main.get("val", [])),
        "test_size": len(split_main.get("test", [])),
        "extra_test_size": len(split_main.get("extra_test", [])) if has_extra_test else 0,
        "has_extra_test": has_extra_test,
        "holdout_snapshots": holdout_snapshots,
    }

    print("[step6_split] done.")
    print(f"[step6_split] mode={mode} "
          f"train={info['train_size']} val={info['val_size']} "
          f"test={info['test_size']} extra_test={info['extra_test_size']}")
    
    # -----------------------------------------------------
    # 临时调试：保存 train/val/test 的前 N 条为 JSON
    # -----------------------------------------------------
    SAMPLE_COUNT = 50  # 取前N条

    try:
        sample_dir = processed_dir / "samples_split"
        sample_dir.mkdir(parents=True, exist_ok=True)

        def _to_native(obj):
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            if isinstance(obj, (np.float32, np.float64)):
                return float(obj)
            if isinstance(obj, (np.int32, np.int64)):
                return int(obj)
            if isinstance(obj, list):
                return [_to_native(x) for x in obj]
            if isinstance(obj, dict):
                return {k: _to_native(v) for k, v in obj.items()}
            return obj

        def _save_preview(split_name: str):
            x_path = processed_dir / f"X_{split_name}.npy"
            y_path = processed_dir / f"Y_{split_name}.npy"
            idx_path = processed_dir / f"index_{split_name}.json"
            if x_path.exists() and y_path.exists() and idx_path.exists():
                X = np.load(x_path)
                Y = np.load(y_path)
                with open(idx_path, "r", encoding="utf-8") as f:
                    idx_rows = json.load(f)

                n = min(SAMPLE_COUNT, X.shape[0])
                preview = {
                    "split": split_name,
                    "count": n,
                    "X_sample": _to_native(X[:n]),
                    "Y_sample": _to_native(Y[:n]),
                    "meta": idx_rows[:n],
                }

                out_path = sample_dir / f"{split_name}_preview.json"
                with open(out_path, "w", encoding="utf-8") as fo:
                    json.dump(preview, fo, ensure_ascii=False, indent=2)
                print(f"[step6] 已导出 {split_name} 前 {n} 条样本 -> {out_path.name}")

        for s in ["train", "val", "test"]:
            _save_preview(s)

    except Exception as e:
        print(f"[step6][warn] 生成样本JSON失败: {e}")

    return info