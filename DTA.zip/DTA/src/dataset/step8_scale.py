# coding: utf-8
"""
src/dataset/step8_scale.py

Step8: 归一化 / 标准化

目标:
1. 用 train 集拟合缩放器 (scaler)
2. 对 train / val / test 的 X / Y 做缩放
3. 保存缩放后的 *.npy 以及 scaler.json
4. 暴露 inverse_scale_Y 供评估/推理还原真实值

支持的归一化方法:
- "none":    不缩放
- "zscore":  Z-score标准化 (x-mean)/std
- "minmax":  线性缩放到[min,max]区间
- "robust":  (x-median)/IQR  抗极端值

注意:
- 统计量仅使用训练集
- 对每个feature列独立拟合(沿 [N * T] 展平)
- 对Y是否缩放受 scale_y 控制
- 所有统计/元信息写入 data/processed/scaler.json

依赖输入 (来自 step7_split 的输出):
- X_train.npy / Y_train.npy / X_val.npy / Y_val.npy / X_test.npy / Y_test.npy
- feature_spec.json (from step5)

输出:
- X_train_scaled.npy / Y_train_scaled.npy / ...
- scaler.json (包含method/params/feature_names/target_names等)

将由 scripts/build_dataset.py 调用:
    from src.dataset.step8_scale import run_step8_scale
"""

from __future__ import annotations
from pathlib import Path
from typing import Dict, Any, Tuple, Optional, List
import numpy as np
import json
import os

from src.utils.io import ensure_dir, read_json


# ---------------------------
# helpers: 计算统计量
# ---------------------------

def _safe_std(x: np.ndarray) -> np.ndarray:
    std = np.std(x, axis=0, ddof=0)
    std[std < 1e-12] = 1.0
    return std

def _safe_iqr(x: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    返回 median, iqr.
    iqr小于1e-12的列归一化时用1.0
    """
    q25 = np.percentile(x, 25, axis=0)
    q50 = np.percentile(x, 50, axis=0)
    q75 = np.percentile(x, 75, axis=0)
    iqr = q75 - q25
    iqr[iqr < 1e-12] = 1.0
    return q50, iqr

def _safe_minmax(x: np.ndarray, feature_range: Tuple[float, float]):
    data_min = np.min(x, axis=0)
    data_max = np.max(x, axis=0)
    # 避免 max=min
    same_mask = (data_max - data_min) < 1e-12
    data_max[same_mask] = data_min[same_mask] + 1.0  # 人为拉开，防除0
    return data_min, data_max, feature_range


# ---------------------------
# 构建 / 拟合 scaler
# ---------------------------

def fit_scaler(
    X_train: np.ndarray,  # [N, T, F]
    Y_train: np.ndarray,  # [N, H, O]
    method: str,
    scale_y: bool,
    minmax_range: Tuple[float, float] = (0.0, 1.0),
) -> Dict[str, Any]:
    """
    拟合缩放器，只用训练集。
    返回 scaler_dict (纯python嵌套dict，可直接json.dump)
    """

    allowed = {"none", "zscore", "minmax", "robust"}
    if method not in allowed:
        raise ValueError(f"[step8] unknown scaling method={method}, allowed={allowed}")

    N, T, F = X_train.shape
    _, H, O = Y_train.shape

    # 将 X 聚合成二维 [N*T, F]，每列就是一个特征的所有观测
    X_flat = X_train.reshape(N * T, F)

    scaler_dict: Dict[str, Any] = {
        "method": method,
        "scale_y": bool(scale_y),
        "feature_range": list(minmax_range) if method == "minmax" else None,
        "x_params": {},
        "y_params": {},
    }

    # ---- X parameters
    if method == "none":
        # 不需要统计
        pass

    elif method == "zscore":
        mean_x = np.mean(X_flat, axis=0)
        std_x  = _safe_std(X_flat)
        scaler_dict["x_params"]["mean"] = mean_x.tolist()
        scaler_dict["x_params"]["std"]  = std_x.tolist()

    elif method == "minmax":
        data_min_x, data_max_x, frange = _safe_minmax(X_flat, minmax_range)
        scaler_dict["x_params"]["min"] = data_min_x.tolist()
        scaler_dict["x_params"]["max"] = data_max_x.tolist()
        scaler_dict["feature_range"]   = list(frange)

    elif method == "robust":
        median_x, iqr_x = _safe_iqr(X_flat)
        scaler_dict["x_params"]["median"] = median_x.tolist()
        scaler_dict["x_params"]["iqr"]    = iqr_x.tolist()

    # ---- Y parameters
    if scale_y:
        Y_flat = Y_train.reshape(Y_train.shape[0] * Y_train.shape[1], Y_train.shape[2])  # [N*H, O]

        if method == "none":
            pass

        elif method == "zscore":
            mean_y = np.mean(Y_flat, axis=0)
            std_y  = _safe_std(Y_flat)
            scaler_dict["y_params"]["mean"] = mean_y.tolist()
            scaler_dict["y_params"]["std"]  = std_y.tolist()

        elif method == "minmax":
            data_min_y, data_max_y, frange = _safe_minmax(Y_flat, minmax_range)
            scaler_dict["y_params"]["min"] = data_min_y.tolist()
            scaler_dict["y_params"]["max"] = data_max_y.tolist()
            scaler_dict["feature_range"]   = list(frange)

        elif method == "robust":
            median_y, iqr_y = _safe_iqr(Y_flat)
            scaler_dict["y_params"]["median"] = median_y.tolist()
            scaler_dict["y_params"]["iqr"]    = iqr_y.tolist()
    else:
        scaler_dict["y_params"] = None

    # 额外加点元信息 (占位，后面 run_step8_scale 再补 feature/target 名字等)
    scaler_dict["num_features"] = F
    scaler_dict["num_targets"]  = O
    scaler_dict["input_steps"]  = T
    scaler_dict["horizon_steps"]= H

    return scaler_dict


# ---------------------------
# 应用缩放 transform
# ---------------------------

def _apply_zscore(arr: np.ndarray, mean_vec: np.ndarray, std_vec: np.ndarray):
    # arr: [N, T, F] or [N, H, O]
    return (arr - mean_vec.reshape(1,1,-1)) / std_vec.reshape(1,1,-1)

def _apply_minmax(arr: np.ndarray, min_vec: np.ndarray, max_vec: np.ndarray, frange: Tuple[float, float]):
    a, b = frange
    scale = (b - a) / (max_vec - min_vec)
    return a + (arr - min_vec.reshape(1,1,-1)) * scale.reshape(1,1,-1)

def _apply_robust(arr: np.ndarray, median_vec: np.ndarray, iqr_vec: np.ndarray):
    return (arr - median_vec.reshape(1,1,-1)) / iqr_vec.reshape(1,1,-1)

def apply_scaler_X(X: np.ndarray, scaler: Dict[str, Any]) -> np.ndarray:
    """
    X: [N, T, F]
    根据 scaler 返回缩放后的 X_scaled
    """
    method = scaler["method"]
    xp = scaler["x_params"] or {}

    if method == "none":
        return X.copy()

    elif method == "zscore":
        mean_x = np.array(xp["mean"], dtype=np.float64)
        std_x  = np.array(xp["std"],  dtype=np.float64)
        return _apply_zscore(X, mean_x, std_x)

    elif method == "minmax":
        min_x = np.array(xp["min"], dtype=np.float64)
        max_x = np.array(xp["max"], dtype=np.float64)
        frange = tuple(scaler["feature_range"])
        return _apply_minmax(X, min_x, max_x, frange)

    elif method == "robust":
        med_x = np.array(xp["median"], dtype=np.float64)
        iqr_x = np.array(xp["iqr"],    dtype=np.float64)
        return _apply_robust(X, med_x, iqr_x)

    else:
        raise ValueError(f"[step8] unsupported method in apply_scaler_X: {method}")


def apply_scaler_Y(Y: np.ndarray, scaler: Dict[str, Any]) -> np.ndarray:
    """
    Y: [N, H, O]
    若 scaler['scale_y'] 为 False, 则原样返回
    """
    if not scaler["scale_y"]:
        return Y.copy()

    method = scaler["method"]
    yp = scaler["y_params"]
    if yp is None:
        return Y.copy()

    if method == "none":
        return Y.copy()

    elif method == "zscore":
        mean_y = np.array(yp["mean"], dtype=np.float64)
        std_y  = np.array(yp["std"],  dtype=np.float64)
        return _apply_zscore(Y, mean_y, std_y)

    elif method == "minmax":
        min_y = np.array(yp["min"], dtype=np.float64)
        max_y = np.array(yp["max"], dtype=np.float64)
        frange = tuple(scaler["feature_range"])
        return _apply_minmax(Y, min_y, max_y, frange)

    elif method == "robust":
        med_y = np.array(yp["median"], dtype=np.float64)
        iqr_y = np.array(yp["iqr"],    dtype=np.float64)
        return _apply_robust(Y, med_y, iqr_y)

    else:
        raise ValueError(f"[step8] unsupported method in apply_scaler_Y: {method}")


# ---------------------------
# 反归一化 inverse (主要给评估/推理还原 Y)
# ---------------------------

def inverse_scale_Y(Y_scaled: np.ndarray, scaler: Dict[str, Any]) -> np.ndarray:
    """
    把模型预测的 Y_scaled (N,H,O) 还原回物理量。
    若 scale_y=False 或 method="none" 则原样返回。
    """
    if not scaler["scale_y"]:
        return Y_scaled.copy()
    method = scaler["method"]
    yp = scaler["y_params"]
    if yp is None:
        return Y_scaled.copy()

    Y_scaled = Y_scaled.copy()

    if method == "none":
        return Y_scaled

    elif method == "zscore":
        mean_y = np.array(yp["mean"], dtype=np.float64)
        std_y  = np.array(yp["std"],  dtype=np.float64)
        return Y_scaled * std_y.reshape(1,1,-1) + mean_y.reshape(1,1,-1)

    elif method == "minmax":
        min_y = np.array(yp["min"], dtype=np.float64)
        max_y = np.array(yp["max"], dtype=np.float64)
        a, b  = scaler["feature_range"]
        # 逆变换:
        # x = min + (x' - a)*(max-min)/(b-a)
        scale = (max_y - min_y) / (b - a)
        return min_y.reshape(1,1,-1) + (Y_scaled - a) * scale.reshape(1,1,-1)

    elif method == "robust":
        med_y = np.array(yp["median"], dtype=np.float64)
        iqr_y = np.array(yp["iqr"],    dtype=np.float64)
        return Y_scaled * iqr_y.reshape(1,1,-1) + med_y.reshape(1,1,-1)

    else:
        raise ValueError(f"[step8] unsupported method in inverse_scale_Y: {method}")


# ---------------------------
# step8 主流程
# ---------------------------

def run_step8_scale(dataset_cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    主入口:
    - 读取 step7 输出的数据
    - 拟合scaler (仅 train)
    - 应用scaler到 train/val/test
    - 保存 *_scaled.npy 和 scaler.json

    返回简单的summary
    """

    scaling_cfg = dataset_cfg.get("scaling", {})
    if not scaling_cfg.get("enabled", True):
        print("[step8] scaling.disabled -> skip")
        return {}

    method = scaling_cfg.get("method", "zscore")
    scale_y = bool(scaling_cfg.get("scale_y", True))
    minmax_range = tuple(scaling_cfg.get("minmax_range", [0.0, 1.0]))

    out_cfg = dataset_cfg["output"]
    processed_dir = Path(out_cfg["processed_dir"])
    ensure_dir(processed_dir)
    
    # 1. load step7 outputs
    # X_all = np.load(processed_dir / "X_all.npy")
    # Y_all = np.load(processed_dir / "Y_all.npy")
    
    if os.path.exists(processed_dir / "X_train_balanced.npy"):
        print("get balanced train data")
        X_train = np.load(processed_dir / "X_train_balanced.npy")
        Y_train = np.load(processed_dir / "Y_train_balanced.npy")
    else:
        X_train = np.load(processed_dir / "X_train.npy")
        Y_train = np.load(processed_dir / "Y_train.npy")
    
    if os.path.exists(processed_dir / "X_val_balanced.npy"):
        print("get balanced val data")
        X_val = np.load(processed_dir / "X_val_balanced.npy")
        Y_val = np.load(processed_dir / "Y_val_balanced.npy")
    else:
        X_val = np.load(processed_dir / "X_val.npy")
        Y_val = np.load(processed_dir / "Y_val.npy")
        
    X_test  = np.load(processed_dir / "X_test.npy")
    Y_test  = np.load(processed_dir / "Y_test.npy")

    # feature_spec.json 里我们应该已有:
    #  - feature_cols
    #  - target_cols
    #  - input_steps
    #  - horizon_steps
    spec_path = processed_dir / "feature_spec.json"
    with open(spec_path, "r", encoding="utf-8") as f:
        spec = json.load(f)

    feature_names = spec.get("feature_cols", [])
    target_names  = spec.get("target_cols", [])
    input_steps   = spec.get("input_steps", X_train.shape[1])
    horizon_steps = spec.get("horizon_steps", Y_train.shape[1])

    # 2. 拟合scaler (train only)
    scaler = fit_scaler(
        X_train=X_train,
        Y_train=Y_train,
        method=method,
        scale_y=scale_y,
        minmax_range=minmax_range,
    )

    # 补充元信息，写进scaler
    scaler["feature_names"]  = feature_names
    scaler["target_names"]   = target_names
    scaler["input_steps"]    = input_steps
    scaler["horizon_steps"]  = horizon_steps

    # 3. 对 train/val/test 应用缩放
    X_train_s = apply_scaler_X(X_train, scaler)
    X_val_s   = apply_scaler_X(X_val, scaler)
    X_test_s  = apply_scaler_X(X_test, scaler)

    Y_train_s = apply_scaler_Y(Y_train, scaler)
    Y_val_s   = apply_scaler_Y(Y_val, scaler)
    Y_test_s  = apply_scaler_Y(Y_test, scaler)

    # 4. 保存缩放后的结果
    np.save(processed_dir / "X_train_scaled.npy", X_train_s)
    np.save(processed_dir / "Y_train_scaled.npy", Y_train_s)
    np.save(processed_dir / "X_val_scaled.npy",   X_val_s)
    np.save(processed_dir / "Y_val_scaled.npy",   Y_val_s)
    np.save(processed_dir / "X_test_scaled.npy",  X_test_s)
    np.save(processed_dir / "Y_test_scaled.npy",  Y_test_s)

    # 5. 保存scaler.json
    scaler_path = processed_dir / "scaler.json"
    with open(scaler_path, "w", encoding="utf-8") as f:
        json.dump(scaler, f, ensure_ascii=False, indent=2)

    print("[step8] scaling done.")
    print(f"[step8] method={method}, scale_y={scale_y}")
    print(f"[step8] saved scaler -> {scaler_path}")
    print(f"[step8] saved scaled arrays -> *_scaled.npy in {processed_dir}")

    summary = {
        "method": method,
        "scale_y": scale_y,
        "processed_dir": str(processed_dir),
        "shapes": {
            "X_train_scaled": list(X_train_s.shape),
            "Y_train_scaled": list(Y_train_s.shape),
            "X_val_scaled":   list(X_val_s.shape),
            "Y_val_scaled":   list(Y_val_s.shape),
            "X_test_scaled":  list(X_test_s.shape),
            "Y_test_scaled":  list(Y_test_s.shape),
        }
    }
    return summary