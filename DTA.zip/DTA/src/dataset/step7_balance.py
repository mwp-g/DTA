# coding: utf-8
"""
src/dataset/step7_balance.py
step7: 采样均衡 / 降重复（多 target 适配，支持简洁 per_target_bins 配置 + 可控全局去重）

输入 (来自 split 后的 processed_dir):
•  X_{train|val|test}.npy        [N, T, F]
•  Y_{train|val|test}.npy        [N, H, O]
•  index_{train|val|test}.json   list[dict]
•  feature_spec.json             包含 target_cols, horizon_steps 等信息

配置关键点 (dataset_cfg["balance_sampling"]):
- enabled: bool
- enable_deduplicate: bool                 # 新增：是否执行全局 dedup
- deduplicate: {...}                       # 去重参数（若 enable_deduplicate 为 True）
- per_target_bins:                         # 按 target 顺序依次做分桶均衡（简洁写法）
  - target: "<target_name>"
    agg_of_future: "max" | "mean"
    bins: [ ... ]                          # 左闭右开，最后一箱含右端
    max_per_bucket: 8000
- per_segment_cap: int|null                # 全部 pipeline 完成后再做一次全局限额
- save_intermediate: true/false

兼容旧配置：
- method: ["by_target_bins"]
- by_target_bins: { target_for_balance, agg_of_future, bins, max_per_bin }
"""

from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Tuple
import json
import numpy as np
import math
import hashlib
from collections import defaultdict

from src.utils.io import ensure_dir


# =========================
# 加载 split 输出
# =========================
def _load_split_outputs(processed_dir: Path, set_name: str, feature_spec_name: str):
    if set_name == "train":
        X_all = np.load(processed_dir / "X_train.npy")
        Y_all = np.load(processed_dir / "Y_train.npy")
        with open(processed_dir / "index_train.json", "r", encoding="utf-8") as f:
            index_all = json.load(f)
    elif set_name == "val":
        X_all = np.load(processed_dir / "X_val.npy")
        Y_all = np.load(processed_dir / "Y_val.npy")
        with open(processed_dir / "index_val.json", "r", encoding="utf-8") as f:
            index_all = json.load(f)
    elif set_name == "test":
        X_all = np.load(processed_dir / "X_test.npy")
        Y_all = np.load(processed_dir / "Y_test.npy")
        with open(processed_dir / "index_test.json", "r", encoding="utf-8") as f:
            index_all = json.load(f)
    else:
        raise ValueError(f"unknown set_name: {set_name}")

    with open(processed_dir / feature_spec_name, "r", encoding="utf-8") as f:
        spec = json.load(f)

    return X_all, Y_all, index_all, spec


# =========================
# deduplicate（可选全局）
# =========================
def _round_and_hash_window(x_win: np.ndarray, round_decimals: int) -> str:
    x_r = np.round(x_win, decimals=round_decimals).reshape(-1)
    h = hashlib.sha1(x_r.tobytes()).hexdigest()
    return h


def _apply_deduplicate(
    X: np.ndarray,
    Y: np.ndarray,
    meta_list: List[Dict[str, Any]],
    cfg_dedup: Dict[str, Any],
    report: Dict[str, Any],
) -> Tuple[np.ndarray, np.ndarray, List[Dict[str, Any]], List[int]]:
    round_decimals = int(cfg_dedup.get("round_decimals", 4))
    max_keep_per_hash = int(cfg_dedup.get("max_keep_per_hash", 50))

    N = X.shape[0]
    hash_buckets: Dict[str, List[int]] = defaultdict(list)
    for i in range(N):
        h = _round_and_hash_window(X[i], round_decimals)
        hash_buckets[h].append(i)

    kept_idx: List[int] = []
    for _, idxs in hash_buckets.items():
        kept_idx.extend(idxs[:max_keep_per_hash])
    kept_idx = sorted(kept_idx)

    X_new = X[kept_idx]
    Y_new = Y[kept_idx]
    meta_new = [meta_list[i] for i in kept_idx]

    dcounts = [len(v) for v in hash_buckets.values()]
    report["deduplicate"] = {
        "enabled": True,
        "round_decimals": round_decimals,
        "max_keep_per_hash": max_keep_per_hash,
        "before": int(N),
        "after": int(len(kept_idx)),
        "num_unique_hash": int(len(hash_buckets)),
        "max_duplicate_count": int(max(dcounts)) if dcounts else 0,
        "mean_duplicate_count": float(np.mean(dcounts)) if dcounts else 0.0,
        "median_duplicate_count": float(np.median(dcounts)) if dcounts else 0.0,
    }
    return X_new, Y_new, meta_new, kept_idx


# =========================
# 目标特征工具
# =========================
def _get_target_column_index(spec: Dict[str, Any], target_name: str) -> int:
    tcols = spec.get("target_cols", [])
    if target_name not in tcols:
        raise ValueError(
            f"[step7] target_for_balance={target_name} 不在 feature_spec.target_cols={tcols}"
        )
    return tcols.index(target_name)


def _score_window_from_future(Y_win: np.ndarray, target_col_idx: int, agg_of_future: str) -> float:
    series = Y_win[:, target_col_idx]  # [H]
    if agg_of_future == "max":
        return float(np.max(series))
    elif agg_of_future == "mean":
        return float(np.mean(series))
    else:
        raise ValueError(f"unsupported agg_of_future={agg_of_future}")


# =========================
# 分箱 & 直方图
# =========================
def _bin_indices_by_edges(scores: np.ndarray, edges: List[float]) -> Dict[int, List[int]]:
    """
    通用分箱（edges 即 bins），规则：
    [edges[k], edges[k+1]) 最后一箱含 >= edges[-2]
    """
    binmap: Dict[int, List[int]] = defaultdict(list)
    for i, s in enumerate(scores):
        placed = False
        for k in range(len(edges) - 1):
            left = edges[k]
            right = edges[k + 1]
            if k < len(edges) - 2:
                if (s >= left) and (s < right):
                    binmap[k].append(i)
                    placed = True
                    break
            else:
                if s >= left:
                    binmap[k].append(i)
                    placed = True
                    break
        if not placed:
            binmap[-1].append(i)  # 低于 edges[0]
    return binmap


def _histogram_counts(scores: np.ndarray, edges: List[float]) -> Dict[str, int]:
    counts = {str(i): 0 for i in range(len(edges) - 1)}
    counts["-1"] = 0
    for s in scores:
        placed = False
        for k in range(len(edges) - 1):
            left = edges[k]
            right = edges[k + 1]
            if k < len(edges) - 2:
                if (s >= left) and (s < right):
                    counts[str(k)] += 1
                    placed = True
                    break
            else:
                if s >= left:
                    counts[str(k)] += 1
                    placed = True
                    break
        if not placed:
            counts["-1"] += 1
    # key 升序
    return dict(sorted(counts.items(), key=lambda kv: int(kv[0]) if kv[0] != "-1" else -1))


# =========================
# 均衡方法：按 bins
# =========================
def _apply_by_target_bins_simple(
    X: np.ndarray,
    Y: np.ndarray,
    meta_list: List[Dict[str, Any]],
    spec: Dict[str, Any],
    target_name: str,
    params: Dict[str, Any],
    report: Dict[str, Any],
    step_name: str,
) -> Tuple[np.ndarray, np.ndarray, List[Dict[str, Any]], List[int]]:
    agg_of_future = params.get("agg_of_future", "max")
    bins: List[float] = params["bins"]
    max_per_bucket = int(params.get("max_per_bucket", 5000))

    t_idx = _get_target_column_index(spec, target_name)

    N = Y.shape[0]
    scores = np.zeros((N,), dtype=float)
    for i in range(N):
        scores[i] = _score_window_from_future(Y[i], t_idx, agg_of_future)

    hist_before = _histogram_counts(scores, bins)
    binmap = _bin_indices_by_edges(scores, bins)

    kept_idx: List[int] = []
    per_bin_kept = {}
    for bink, idxs in binmap.items():
        trimmed = idxs[:max_per_bucket]
        kept_idx.extend(trimmed)
        brange = (
            bins[bink],
            (bins[bink + 1] if (bink >= 0 and (bink + 1) < len(bins)) else math.inf),
        ) if bink != -1 else ("-inf", bins[0] if bins else None)
        per_bin_kept[str(bink)] = {
            "bin_range": brange,
            "count_before": len(idxs),
            "count_after": len(trimmed),
        }

    kept_idx = sorted(kept_idx)
    Xn = X[kept_idx]
    Yn = Y[kept_idx]
    metan = [meta_list[i] for i in kept_idx]

    hist_after = _histogram_counts(scores[kept_idx] if kept_idx else np.zeros((0,), dtype=float), bins)

    report[step_name] = {
        "op": "by_target_bins",
        "target": target_name,
        "agg_of_future": agg_of_future,
        "bins": bins,
        "max_per_bucket": max_per_bucket,
        "before": int(N),
        "after": int(len(kept_idx)),
        "per_bin_detail": dict(sorted(per_bin_kept.items())),
        "hist_before": hist_before,
        "hist_after": hist_after,
    }
    return Xn, Yn, metan, kept_idx


# =========================
# per-segment 限额（全局）
# =========================
def _apply_per_segment_cap(
    X: np.ndarray,
    Y: np.ndarray,
    meta_list: List[Dict[str, Any]],
    cap: int,
    report: Dict[str, Any],
) -> Tuple[np.ndarray, np.ndarray, List[Dict[str, Any]], List[int]]:
    group: Dict[Tuple[str, int], List[int]] = defaultdict(list)
    for i, m in enumerate(meta_list):
        key = (str(m.get("snapshot_id", "NONE")), int(m.get("segment_id", -1)))
        group[key].append(i)

    kept_idx: List[int] = []
    per_group = {}
    for k, idxs in group.items():
        trimmed = idxs[:cap]
        kept_idx.extend(trimmed)
        per_group[str(k)] = {"before": len(idxs), "after": len(trimmed)}

    kept_idx = sorted(kept_idx)
    Xn = X[kept_idx]
    Yn = Y[kept_idx]
    metan = [meta_list[i] for i in kept_idx]

    report["per_segment_cap"] = {
        "cap": int(cap),
        "before": int(len(meta_list)),
        "after": int(len(kept_idx)),
        "groups": per_group,
    }
    return Xn, Yn, metan, kept_idx


# =========================
# 保存
# =========================
def _save_step7_outputs(
    processed_dir: Path,
    set_name: str,
    Xb: np.ndarray,
    Yb: np.ndarray,
    metab: List[Dict[str, Any]],
    report: Dict[str, Any],
):
    ensure_dir(processed_dir)
    np.save(processed_dir / f"X_{set_name}_balanced.npy", Xb)
    np.save(processed_dir / f"Y_{set_name}_balanced.npy", Yb)

    with open(processed_dir / f"index_{set_name}_balanced.json", "w", encoding="utf-8") as f:
        json.dump(metab, f, ensure_ascii=False, indent=2)

    with open(processed_dir / f"balance_{set_name}_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)


# =========================
# 最终分布汇总（报告所用）
# =========================
def _final_distribution_summary(Y: np.ndarray, spec: Dict[str, Any], per_target_bins_cfg: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    按 per_target_bins 里出现过的 target，用其 bins 在“最终工作集”统计直方图。
    """
    tcols = spec.get("target_cols", [])
    H = Y.shape[1]

    summary: Dict[str, Any] = {}
    for pipe in per_target_bins_cfg or []:
        tgt = pipe.get("target")
        if not tgt or tgt not in tcols:
            continue
        edges = pipe.get("bins", None)
        agg = pipe.get("agg_of_future", "max")
        if not edges:
            continue
        o = tcols.index(tgt)
        scores = np.max(Y[:, :, o], axis=1) if (agg == "max" and H > 0) else (np.mean(Y[:, :, o], axis=1) if H > 0 else np.array([], dtype=float))
        hist = _histogram_counts(scores, edges)
        summary[tgt] = {
            "edges": edges,
            "agg_of_future": agg,
            "hist": hist,
        }
    # 按 key 升序
    return dict(sorted(summary.items(), key=lambda kv: kv[0]))


# =========================
# 主入口
# =========================
def run_step7_balance(dataset_cfg: Dict[str, Any], set_name: str) -> Dict[str, Any]:
    cfg_bs = dataset_cfg.get("balance_sampling", {})
    if not cfg_bs.get("enabled", True):
        print("[step7] balance_sampling.disabled -> skip")
        return {}

    cfg_out = dataset_cfg["output"]
    processed_dir = Path(cfg_out["processed_dir"])
    spec_name = cfg_out.get("feature_spec_name", "feature_spec.json")

    # 载入 split 后的数据
    X_all, Y_all, index_all, spec = _load_split_outputs(processed_dir, set_name, spec_name)

    # 初始化工作集
    X_work = X_all
    Y_work = Y_all
    meta_work = index_all

    report: Dict[str, Any] = {
        "before_total": int(X_all.shape[0]),
        "steps": [],
    }

    # ----------（可选）全局 deduplicate（由 enable_deduplicate 控制） ----------
    if bool(cfg_bs.get("enable_deduplicate", False)):
        dedup_params = cfg_bs.get("deduplicate", {"round_decimals": 4, "max_keep_per_hash": 50})
        X_work, Y_work, meta_work, _ = _apply_deduplicate(
            X_work, Y_work, meta_work, dedup_params, report
        )
        report["steps"].append({"name": "deduplicate", "after": int(X_work.shape[0])})
    else:
        report["deduplicate"] = {"enabled": False, "before": int(X_work.shape[0]), "after": int(X_work.shape[0])}

    # ---------- per_target_bins（简洁配置） ----------
    per_target_bins_cfg: List[Dict[str, Any]] = cfg_bs.get("per_target_bins", [])

    if per_target_bins_cfg:
        for idx, cfg in enumerate(per_target_bins_cfg):
            tgt = cfg["target"]
            step_name = f"per_target_bins[{idx}].{tgt}"
            X_work, Y_work, meta_work, _ = _apply_by_target_bins_simple(
                X_work, Y_work, meta_work, spec, tgt, cfg, report, step_name
            )
            report["steps"].append({"name": step_name, "after": int(X_work.shape[0])})
    else:
        # 兼容老配置：method + by_target_bins（单 target）
        methods: List[str] = cfg_bs.get("method", [])
        if "by_target_bins" in methods:
            legacy = cfg_bs.get("by_target_bins", {})
            tgt = legacy["target_for_balance"]
            step_name = f"legacy.by_target_bins.{tgt}"
            X_work, Y_work, meta_work, _ = _apply_by_target_bins_simple(
                X_work, Y_work, meta_work, spec, tgt,
                {
                    "agg_of_future": legacy.get("agg_of_future", "max"),
                    "bins": legacy["bins"],
                    "max_per_bucket": legacy.get("max_per_bin", 5000),
                },
                report, step_name
            )
            report["steps"].append({"name": step_name, "after": int(X_work.shape[0])})

    # ----------（可选）全局 per_segment_cap ----------
    per_seg_cap = cfg_bs.get("per_segment_cap", None)
    if per_seg_cap is not None:
        cap_int = int(per_seg_cap)
        X_work, Y_work, meta_work, _ = _apply_per_segment_cap(
            X_work, Y_work, meta_work, cap_int, report
        )
        report["steps"].append({"name": "per_segment_cap", "after": int(X_work.shape[0])})
    else:
        report["per_segment_cap"] = {"skipped": True, "before": int(X_work.shape[0]), "after": int(X_work.shape[0])}

    report["after_total"] = int(X_work.shape[0])

    # ---------- 最终分布汇总 ----------
    report["final_distribution"] = _final_distribution_summary(Y_work, spec, cfg_bs.get("per_target_bins", []))

    # 保存
    if cfg_bs.get("save_intermediate", True):
        _save_step7_outputs(
            processed_dir=processed_dir,
            set_name=set_name,
            Xb=X_work,
            Yb=Y_work,
            metab=meta_work,
            report=report,
        )

    info = {
        f"X_{set_name}_balanced_path": str(processed_dir / f"X_{set_name}_balanced.npy"),
        f"Y_{set_name}_balanced_path": str(processed_dir / f"Y_{set_name}_balanced.npy"),
        f"index_{set_name}_balanced_path": str(processed_dir / f"index_{set_name}_balanced.json"),
        "report_path": str(processed_dir / f"balance_{set_name}_report.json"),
        "num_samples": int(X_work.shape[0]),
        f"X_{set_name}_shape": list(X_work.shape),
        f"Y_{set_name}_shape": list(Y_work.shape),
    }

    print(f"[step7] done. samples={info['num_samples']}, "
          f"X_{set_name}_balanced.shape={info[f'X_{set_name}_shape']}, "
          f"Y_{set_name}_balanced.shape={info[f'Y_{set_name}_shape']}")
    return info