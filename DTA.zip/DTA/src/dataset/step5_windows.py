# coding: utf-8
"""
src/dataset/step5_windows.py

Step5: 构建时序滑窗样本全集

输入:
- data/interim/preprocessed.json  (step4 之后的最终预处理行级数据)
  该文件是一个 list[dict]，每条是一个时刻的观测，包含 meta. 字段

配置 (dataset_cfg["build_windows"]):
- enabled (bool)
- input_steps (int)            # T
- horizon_steps (int)          # H
- stride (int)
- time_col (str)               # eg "meta.timestamp"
- snapshot_col (str)           # eg "meta.snapshot_id"
- target_cols (list[str])      # eg ["cpu.used"]
- feature_cols (list[str])     # 若非空 -> 明确使用这些特征列
                               # 若为空 -> 默认使用所有非 meta. 的列
- max_gap_multiplier (int)     # 时间中断阈值 = (period_ms * max_gap_multiplier)

输出 (写到 processed_dir):
- X_all.npy: shape [N, T, F]
- Y_all.npy: shape [N, H, O]
- index_all.json: [{snapshot_id, segment_id, start_ts, end_ts, ...}, ...]
- feature_spec.json: 训练/后续步骤需要的元信息
"""

from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any, Tuple
import json
import numpy as np
import pandas as pd

from src.utils.io import ensure_dir, read_yaml


# ------------------------------------------------
# 基础小工具
# ------------------------------------------------

def _to_int_ts(v):
    """把 '1761190245000.0' / '1,761,190,245,000' / float / int -> int(ms)"""
    if pd.isna(v):
        return None
    s = str(v).replace(",", "")
    if "." in s:
        s = s.split(".", 1)[0]
    try:
        return int(s)
    except Exception:
        return None


def _load_preprocessed(interim_dir: Path) -> pd.DataFrame:
    """
    读取 step4 产出的 preprocessed.json (list[dict]) -> DataFrame
    """
    pre_path = interim_dir / "preprocessed.json"
    with open(pre_path, "r", encoding="utf-8") as f:
        rows = json.load(f)
    df = pd.DataFrame(rows).reset_index(drop=True)
    return df


def _extract_period_ms(df: pd.DataFrame) -> int:
    """
    从 meta.period_ms 估计采样周期，取众数。兜底 5000ms。
    """
    period_col = "meta.period_ms"
    if period_col in df.columns:
        vals = (
            pd.to_numeric(df[period_col], errors="coerce")
            .dropna()
            .astype(int)
            .values
        )
        if len(vals) > 0:
            counts = pd.Series(vals).value_counts()
            return int(counts.index[0])
    return 5000

def load_json(p: Path):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)
    
def _pick_feature_cols(
    df: pd.DataFrame,
    cfg_bw: Dict[str, Any],
    dataset_cfg: Dict[str, Any],
) -> List[str]:
    """
    决定 X 的特征列顺序:
    - 如果 cfg_bw["feature_cols"] 存在且非空，严格用它
    - 否则，默认用所有非 meta.* 的列 (target_cols 也会包含进来，只要不是 meta.)
    """
    configured = cfg_bw.get("feature_cols", "")
    if configured != "":
        feature_cols = load_json(f"{dataset_cfg['output']['interim_dir']}/{configured}")
        all_cols = [k for k in feature_cols if not k.startswith("meta.")]
        print(f"read feature_list:{len(all_cols)}")
        return all_cols

    all_cols = list(df.columns)
    auto_cols = [c for c in all_cols if not c.startswith("meta.")]
    return auto_cols


def _split_into_segments(
    mdf: pd.DataFrame,
    time_col: str,
    base_period_ms: int,
    max_gap_multiplier: int,
) -> List[pd.DataFrame]:
    """
    将某台机器的时间序列按断档切成若干相对连续段。
    若相邻样本的 timestamp gap > base_period_ms * max_gap_multiplier 则视为新段。
    """
    if len(mdf) == 0:
        return []

    max_gap_ms = base_period_ms * max_gap_multiplier

    clean_ts = [_to_int_ts(v) for v in mdf[time_col].tolist()]
    clean_ts = np.array(clean_ts, dtype="float64")

    segments = []
    start_idx = 0
    for i in range(1, len(clean_ts)):
        gap_bad = (
            np.isnan(clean_ts[i]) or
            np.isnan(clean_ts[i - 1]) or
            (clean_ts[i] - clean_ts[i - 1]) > max_gap_ms
        )
        if gap_bad:
            segments.append((start_idx, i))
            start_idx = i
    segments.append((start_idx, len(clean_ts)))

    out = []
    for (a, b) in segments:
        seg_df = mdf.iloc[a:b].copy()
        if len(seg_df) > 0:
            out.append(seg_df.reset_index(drop=True))
    return out


def _make_windows_from_segment(
    seg_df: pd.DataFrame,
    feature_cols: List[str],
    target_cols: List[str],
    time_col: str,
    snapshot_id: str,
    segment_id: int,
    input_steps: int,
    horizon_steps: int,
    stride: int,
) -> Tuple[List[np.ndarray], List[np.ndarray], List[Dict[str, Any]]]:
    """
    在一个连续 segment 内做滑窗:
      X_win: [input_steps, len(feature_cols)]
      Y_win: [horizon_steps, len(target_cols)]
    返回列表 (X_list, Y_list, meta_list)
    """
    seg_df = seg_df.sort_values(by=time_col).reset_index(drop=True)
    ts_ms_arr = [_to_int_ts(v) for v in seg_df[time_col].tolist()]

    N = len(seg_df)
    need_len = input_steps + horizon_steps

    X_list, Y_list, meta_list = [], [], []

    for start in range(0, N - need_len + 1, stride):
        in_slice = seg_df.iloc[start : start + input_steps]
        out_slice = seg_df.iloc[start + input_steps : start + input_steps + horizon_steps]

        X_win = in_slice[feature_cols].to_numpy(dtype=float)
        Y_win = out_slice[target_cols].to_numpy(dtype=float)

        start_ts = ts_ms_arr[start] if start < len(ts_ms_arr) else None
        end_ts = ts_ms_arr[start + input_steps - 1] if (start + input_steps - 1) < len(ts_ms_arr) else None

        meta_list.append({
            "snapshot_id": str(snapshot_id),
            "segment_id": segment_id,
            "index": start,
            "start_ts": start_ts,
            "end_ts": end_ts,
        })
        X_list.append(X_win)
        Y_list.append(Y_win)

    return X_list, Y_list, meta_list


def _build_feature_spec_dict(
    df: pd.DataFrame,
    cfg_bw: Dict[str, Any],
    feature_cols: List[str],
    target_cols: List[str],
    snap_col: str,
    time_col: str,
    X_all: np.ndarray,
    Y_all: np.ndarray,
    base_period_ms: int,
    processed_dir: Path,
    spec_name: str,
) -> Dict[str, Any]:
    """
    汇总用于后续训练/评估的规格信息（特征维度、步长等）。
    """
    # 全局时间范围
    ts_all = [_to_int_ts(v) for v in df[time_col].tolist()]
    ts_all = [t for t in ts_all if t is not None]

    snapshot_ids_unique = sorted(df[snap_col].astype(str).unique().tolist())

    spec = {
        "feature_spec_name": spec_name,
        "input_steps": int(cfg_bw["input_steps"]),
        "horizon_steps": int(cfg_bw["horizon_steps"]),
        "stride": int(cfg_bw["stride"]),
        "feature_cols": feature_cols,
        "target_cols": target_cols,
        "snapshot_col": snap_col,
        "time_col": time_col,
        "snapshot_ids": snapshot_ids_unique,
        "X_shape": X_all.shape,
        "Y_shape": Y_all.shape,
        "num_samples": int(X_all.shape[0]),
        "num_features": int(X_all.shape[2]) if X_all.ndim == 3 else 0,
        "num_targets": int(Y_all.shape[2]) if Y_all.ndim == 3 else 0,
        "sample_period_ms": base_period_ms,
        "max_gap_multiplier": int(cfg_bw.get("max_gap_multiplier", 10)),
        "time_range": {
            "min": int(min(ts_all)) if ts_all else None,
            "max": int(max(ts_all)) if ts_all else None,
        },
    }

    # 写文件
    with open(processed_dir / spec_name, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, indent=2)

    return spec


def _save_step5_outputs(
    processed_dir: Path,
    X_all: np.ndarray,
    Y_all: np.ndarray,
    index_all: List[Dict[str, Any]],
):
    """
    将大数组和meta索引信息落盘到 processed_dir
    """
    ensure_dir(processed_dir)

    np.save(processed_dir / "X_all.npy", X_all)
    np.save(processed_dir / "Y_all.npy", Y_all)

    with open(processed_dir / "index_all.json", "w", encoding="utf-8") as f:
        json.dump(index_all, f, ensure_ascii=False, indent=2)
    
    # -----------------------------------------------------
    # 临时调试：保存某台机器的前 n 条样本为 JSON
    # -----------------------------------------------------
    SAMPLE_SNAPSHOT_ID = ""   # ← 指定目标机器ID
    SAMPLE_COUNT = 50                    # ← 前 N 条

    try:
        # 过滤出指定 snapshot_id
        sample_indices = [
            i for i, m in enumerate(index_all)
            if str(m.get("snapshot_id")) == SAMPLE_SNAPSHOT_ID
        ][8300:8305]

        if sample_indices:
            X_sample = X_all[sample_indices]
            Y_sample = Y_all[sample_indices]
            meta_sample = [index_all[i] for i in sample_indices]

            def _to_native(obj):
                if isinstance(obj, np.ndarray):
                    return obj.tolist()
                if isinstance(obj, (np.float32, np.float64)):
                    return float(obj)
                if isinstance(obj, (np.int32, np.int64)):
                    return int(obj)
                if isinstance(obj, list):
                    return [_to_native(x) for x in obj]
                if isinstance(obj, dict):
                    return {k: _to_native(v) for k, v in obj.items()}
                return obj

            sample_dir = processed_dir / "samples"
            ensure_dir(sample_dir)

            with open(sample_dir / f"X_sample.json", "w", encoding="utf-8") as fx:
                json.dump({"X_sample": _to_native(X_sample)}, fx, ensure_ascii=False, indent=2)

            with open(sample_dir / f"Y_sample.json", "w", encoding="utf-8") as fy:
                json.dump({"Y_sample": _to_native(Y_sample)}, fy, ensure_ascii=False, indent=2)

            with open(sample_dir / f"meta_sample.json", "w", encoding="utf-8") as fm:
                json.dump(meta_sample, fm, ensure_ascii=False, indent=2)

            print(f"[step5] 已保存 {SAMPLE_SNAPSHOT_ID} 的前 {len(sample_indices)} 条样本 JSON -> samples/")
        else:
            print(f"[step5][note] 未找到 snapshot_id={SAMPLE_SNAPSHOT_ID} 的样本")
    except Exception as e:
        print(f"[step5][warn] 保存样本JSON失败: {e}")
        
    
    



# ------------------------------------------------
# 主导出接口（给 scripts/build_dataset.py 调用）
# ------------------------------------------------

def run_step5_build_windows(dataset_cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    执行 step5 (构建滑窗样本全集)，并返回关键信息字典。

    参数:
    - dataset_cfg: dataset.yaml 里 "dataset" 这一层的 dict，
      其中我们会用到:
        dataset_cfg["build_windows"]
        dataset_cfg["output"]

    返回:
    {
      "X_all_path": ".../data/processed/X_all.npy",
      "Y_all_path": ".../data/processed/Y_all.npy",
      "index_all_path": ".../data/processed/index_all.json",
      "feature_spec_path": ".../data/processed/feature_spec.json",
      "num_samples": int,
      "X_shape": [N, T, F],
      "Y_shape": [N, H, O],
    }
    """
    cfg_bw = dataset_cfg["build_windows"]
    if not cfg_bw.get("enabled", True):
        print("[step5] build_windows.disabled -> skip")
        return {}

    cfg_out = dataset_cfg["output"]

    interim_dir = Path(cfg_out["interim_dir"])       # 读取 step4 结果
    processed_dir = Path(cfg_out["processed_dir"])   # 从 step5 开始写入这里
    spec_name = cfg_out.get("feature_spec_name", "feature_spec.json")

    time_col = cfg_bw["time_col"]
    snap_col = cfg_bw["snapshot_col"]
    target_cols = cfg_bw["target_cols"]
    include_targets = cfg_bw["include_targets"]

    input_steps = int(cfg_bw["input_steps"])
    horizon_steps = int(cfg_bw["horizon_steps"])
    stride = int(cfg_bw["stride"])
    max_gap_multiplier = int(cfg_bw.get("max_gap_multiplier", 10))

    # 1. 载入 step4 的时序点
    df = _load_preprocessed(interim_dir)

    if time_col not in df.columns:
        raise ValueError(f"[step5] time_col {time_col} not found in columns")
    if snap_col not in df.columns:
        raise ValueError(f"[step5] snapshot_col {snap_col} not found in columns")

    # 2. 决定输入特征列顺序
    feature_cols = _pick_feature_cols(df, cfg_bw, dataset_cfg)
    
    if not include_targets:
        feature_cols = [col for col in feature_cols if col not in target_cols]

    # 3. 估采样周期
    base_period_ms = _extract_period_ms(df)

    # 4. 按机器分组 -> 排序 -> 切segment -> 滑窗
    all_X_windows: List[np.ndarray] = []
    all_Y_windows: List[np.ndarray] = []
    all_meta: List[Dict[str, Any]] = []

    grouped = df.groupby(snap_col)
    for snapshot_id, g in grouped:
        g_sorted = g.sort_values(by=time_col).reset_index(drop=True)

        # 切 segments（基于时间断档）
        seg_list = _split_into_segments(
            mdf=g_sorted,
            time_col=time_col,
            base_period_ms=base_period_ms,
            max_gap_multiplier=max_gap_multiplier,
        )

        for seg_id, seg_df in enumerate(seg_list):
            X_list, Y_list, meta_list = _make_windows_from_segment(
                seg_df=seg_df,
                feature_cols=feature_cols,
                target_cols=target_cols,
                time_col=time_col,
                snapshot_id=snapshot_id,
                segment_id=seg_id,
                input_steps=input_steps,
                horizon_steps=horizon_steps,
                stride=stride,
            )

            all_X_windows.extend(X_list)
            all_Y_windows.extend(Y_list)
            all_meta.extend(meta_list)

    # 5. 堆叠
    if len(all_X_windows) == 0:
        print("[step5][warn] no windows generated.")
        X_all = np.zeros((0, input_steps, len(feature_cols)), dtype=float)
        Y_all = np.zeros((0, horizon_steps, len(target_cols)), dtype=float)
    else:
        X_all = np.stack(all_X_windows, axis=0)  # [N, T, F]
        Y_all = np.stack(all_Y_windows, axis=0)  # [N, H, O]

    # 6. 保存 (X_all, Y_all, index_all)
    _save_step5_outputs(
        processed_dir=processed_dir,
        X_all=X_all,
        Y_all=Y_all,
        index_all=all_meta,
    )

    # 7. 生成并保存 feature_spec.json
    spec_dict = _build_feature_spec_dict(
        df=df,
        cfg_bw=cfg_bw,
        feature_cols=feature_cols,
        target_cols=target_cols,
        snap_col=snap_col,
        time_col=time_col,
        X_all=X_all,
        Y_all=Y_all,
        base_period_ms=base_period_ms,
        processed_dir=processed_dir,
        spec_name=spec_name,
    )

    info = {
        "X_all_path": str(processed_dir / "X_all.npy"),
        "Y_all_path": str(processed_dir / "Y_all.npy"),
        "index_all_path": str(processed_dir / "index_all.json"),
        "feature_spec_path": str(processed_dir / spec_name),
        "num_samples": int(X_all.shape[0]),
        "X_shape": list(X_all.shape),
        "Y_shape": list(Y_all.shape),
        "feature_spec": spec_dict,
    }

    print(f"[step5] done. samples={info['num_samples']}, "
          f"X_all.shape={info['X_shape']}, Y_all.shape={info['Y_shape']}")
    return info