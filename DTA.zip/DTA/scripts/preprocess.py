# scripts/preprocess.py
# -*- coding: utf-8 -*-
"""
统一调度 step1 -> step2 -> step3 -> step4
"""

from pathlib import Path
import sys
import argparse
sys.path.append(str(Path(__file__).resolve().parents[1]))
from src.utils.io import read_yaml
from src.data.step1_load_and_align import run_step1_load_and_align
from src.data.step2_aggregate import run_step2_aggregate
from src.data.step3_feature_engineering import run_step3_feature_engineering
from src.data.step4_correlation import run_step4_correlation


def main(data_cfg_path: Path):
    data_cfg = read_yaml(data_cfg_path)
    pipeline_cfg = data_cfg.get("pipeline", {})

    print(f"[preprocess] loaded config: {data_cfg_path}")

    # step1
    step1_cfg = pipeline_cfg.get("step1_load_and_align", {})
    if step1_cfg.get("enabled", False):
        print("[preprocess] running step1_load_and_align ...")
        run_step1_load_and_align(step1_cfg, data_cfg)
    else:
        print("[preprocess] step1 disabled, skip.")

    # step2
    step2_cfg = pipeline_cfg.get("step2_aggregate", {})
    if step2_cfg.get("enabled", False):
        print("[preprocess] running step2_aggregate ...")
        run_step2_aggregate(step2_cfg, data_cfg)
    else:
        print("[preprocess] step2 disabled, skip.")

    # step3
    step3_cfg = pipeline_cfg.get("step3_feature_engineering", {})
    if step3_cfg.get("enabled", False):
        print("[preprocess] running step3_feature_engineering ...")
        run_step3_feature_engineering(step3_cfg, data_cfg)
    else:
        print("[preprocess] step3 disabled, skip.")

    # step4
    step4_cfg = pipeline_cfg.get("step4_correlation", {})
    if step4_cfg.get("enabled", False):
        print("[preprocess] running step4_correlation ...")
        run_step4_correlation(step4_cfg, data_cfg)
    else:
        print("[preprocess] step4 disabled, skip.")

    print("[preprocess] ✅ all done.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Data preprocessing pipeline")
    parser.add_argument(
        "--data",
        type=str,
        default="configs/data.yaml",
        help="Path to the data configuration YAML file"
    )
    args = parser.parse_args()
    main(Path(args.data))