# coding: utf-8
"""
debug_model_behavior_auto.py
自动诊断“预测值几乎恒定/退化”的常见原因，并输出结构化报告。

输出（默认都放到 model/ 下）：
- model/debug_report.json           # 总结 + 结论 + 建议
- model/layer_stats.json            # （若能hook到）各层输出均值/方差
- model/pred_true_pairs.json        # 前若干样本 y_true vs y_pred 对照（按 target×horizon 组织）
- model/preds_summary.json          # 预测与真实的分布统计（均值/方差/分位等）
"""

from __future__ import annotations
import os, json, math
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import torch
import torch.nn as nn

# ============= 可调配置 =============
PROCESSED_DIR = Path("data/processed")
MODEL_DIR     = Path("model")
TRAIN_YAML    = Path("configs/train.yaml")
REPORT_DIR    = MODEL_DIR

N_SAMPLES     = 256     # 取前 N 条用于调试
CONST_THR_X   = 1e-8    # 输入特征“近似常数”的阈值（std）
CONST_THR_Y   = 1e-8    # 目标“近似常数”的阈值（std）
CONST_THR_P   = 1e-6    # 预测“近似常数”的阈值（std）
QUANTILES     = [0.0, 0.01, 0.1, 0.25, 0.5, 0.75, 0.9, 0.99, 1.0]
DEVICE        = "cuda:0" if torch.cuda.is_available() else "cpu"
# =====================================

def _read_text(p: Path) -> str | None:
    try:
        with open(p, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return None

def _read_json(p: Path) -> Any | None:
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _write_json(p: Path, obj: Any):
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def _detect_model_name_from_yaml(yaml_text: str | None) -> str | None:
    if not yaml_text:
        return None
    for line in yaml_text.splitlines():
        s = line.strip()
        # 只取第一处 name: "xxx"
        if s.startswith("name:"):
            val = s.split(":", 1)[1].strip()
            return val.replace('"', '').replace("'", "")
    return None

def _try_import_python_model(model_name: str, feature_spec: Dict[str, Any], train_yaml_text: str | None):
    """
    尝试构建“原生可hook”的 PyTorch 模型并加载 best_*.pt。
    返回 (model, used_path, note)；失败则 (None, None, reason)
    """
    try:
        # 准备超参
        input_size  = int(len(feature_spec["feature_cols"]))
        horizon     = int(feature_spec["horizon_steps"])
        output_size = int(len(feature_spec["target_cols"]))

        # 解析各自的块
        # 简单粗暴解析（不依赖yaml库，足够应付当前train.yaml结构）
        def _get_block(block_name: str) -> Dict[str, Any]:
            if not train_yaml_text:
                return {}
            lines = train_yaml_text.splitlines()
            blk: Dict[str, Any] = {}
            active = False
            for ln in lines:
                if ln.strip().startswith(block_name + ":"):
                    active = True
                    continue
                if active:
                    if ln.strip().startswith(("#", "export:", "train_loop:", "data:", "model:", "lstm:", "transformer:")) and not ln.strip().startswith(block_name + ":"):
                        # 碰到其它块开头，结束
                        if ln.strip().startswith(block_name + ":"):
                            continue
                        if ln.strip().endswith(":"):
                            break
                    # 收集 key: val
                    if ":" in ln:
                        k, v = ln.split(":", 1)
                        blk[k.strip()] = v.strip().replace('"', '').replace("'", "")
            return blk

        if model_name.lower() == "lstm":
            block = _get_block("lstm")
            from src.models.lstm_model import LSTMModel  # 需要你的项目已有该模块
            model = LSTMModel(
                input_size=input_size,
                hidden_size=int(block.get("hidden_size", 128)),
                num_layers=int(block.get("num_layers", 2)),
                dropout=float(block.get("dropout", 0.1)),
                horizon_steps=horizon,
                output_size=output_size,
            )
            ckpt = MODEL_DIR / "best_lstm.pt"

        elif model_name.lower() == "transformer":
            block = _get_block("transformer")
            from src.models.transformer_model import TransformerModel
            model = TransformerModel(
                input_size=input_size,
                d_model=int(block.get("d_model", 128)),
                nhead=int(block.get("nhead", 4)),
                num_layers=int(block.get("num_layers", 2)),
                dim_feedforward=int(block.get("dim_feedforward", 256)),
                dropout=float(block.get("dropout", 0.1)),
                horizon_steps=horizon,
                output_size=output_size,
                max_len=int(feature_spec["input_steps"]),
            )
            ckpt = MODEL_DIR / "best_transformer.pt"
        else:
            return None, None, f"unsupported model name: {model_name}"

        if not ckpt.exists():
            return None, None, f"checkpoint not found: {ckpt}"

        # 加载权重（兼容直接保存module或state_dict两种）
        try:
            obj = torch.load(ckpt, map_location="cpu")
            if isinstance(obj, dict) and not isinstance(obj, nn.Module):
                # 可能是 state_dict
                state_dict = obj.get("state_dict", obj)
                model.load_state_dict(state_dict, strict=False)
            elif isinstance(obj, nn.Module):
                model = obj
            else:
                # 兜底：尝试当成 state_dict
                model.load_state_dict(obj, strict=False)
        except Exception as e:
            return None, None, f"failed to load weight from {ckpt}: {e}"

        model.eval()
        return model, str(ckpt), "python_model_loaded"
    except Exception as e:
        return None, None, f"import/build error: {e}"

def _try_load_torchscript():
    ts_path = MODEL_DIR / "deploy_model.ts"
    if not ts_path.exists():
        return None, None, "deploy_model.ts not found"
    try:
        model = torch.jit.load(str(ts_path), map_location="cpu")
        model.eval()
        return model, str(ts_path), "torchscript_loaded"
    except Exception as e:
        return None, None, f"torchscript load error: {e}"

def _collect_basic_stats(arr: np.ndarray) -> Dict[str, Any]:
    flat = arr.reshape(-1) if arr.size > 0 else arr
    q = np.quantile(flat, QUANTILES).tolist() if flat.size > 0 else []
    return {
        "shape": list(arr.shape),
        "mean": float(np.mean(flat)) if flat.size > 0 else None,
        "std": float(np.std(flat)) if flat.size > 0 else None,
        "min": float(np.min(flat)) if flat.size > 0 else None,
        "max": float(np.max(flat)) if flat.size > 0 else None,
        "quantiles": {str(k): float(v) for k, v in zip(QUANTILES, q)} if q else {},
        "has_nan": bool(np.isnan(flat).any()) if flat.size > 0 else False,
        "has_inf": bool(np.isinf(flat).any()) if flat.size > 0 else False,
    }

def _per_feature_std(arr3: np.ndarray) -> np.ndarray:
    # [N, T, F] -> per-feature std over N*T
    if arr3.ndim != 3 or arr3.shape[0] == 0:
        return np.array([])
    return np.std(arr3, axis=(0,1))

def _attach_hooks(model: nn.Module):
    layer_outputs: Dict[str, np.ndarray] = {}
    try:
        for name, module in model.named_modules():
            if isinstance(module, (nn.Linear, nn.LSTM, nn.LayerNorm, nn.BatchNorm1d, nn.TransformerEncoderLayer)):
                def _hook(m, inp, outp, name=name):
                    if isinstance(outp, tuple):
                        outp = outp[0]
                    try:
                        layer_outputs[name] = outp.detach().cpu().numpy()
                    except Exception:
                        pass
                module.register_forward_hook(_hook)
        return layer_outputs, True
    except Exception:
        return {}, False

def _make_pairs_per_target_horizon(y_true: np.ndarray, y_pred: np.ndarray, target_names: List[str]) -> Dict[str, Any]:
    """
    y_true/pred: [N, H, O]
    组织成 {target: {step_k: [{"true":..,"pred":..}, ...]}}
    仅保存前若干条（<=N_SAMPLES）
    """
    N, H, O = y_pred.shape
    limit = min(N, N_SAMPLES)
    out: Dict[str, Any] = {}
    for o in range(O):
        tname = target_names[o] if o < len(target_names) else f"target_{o}"
        out[tname] = {}
        for h in range(H):
            pairs = []
            for i in range(limit):
                pairs.append({
                    "true": float(y_true[i, h, o]),
                    "pred": float(y_pred[i, h, o]),
                })
            out[tname][f"step_{h}"] = pairs
    return out

def main():
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    report: Dict[str, Any] = {"status": "ok", "notes": []}

    # -------- 读取配置/规格 --------
    train_yaml_text = _read_text(TRAIN_YAML)
    model_name = _detect_model_name_from_yaml(train_yaml_text)
    if not model_name:
        report["status"] = "warn"
        report["notes"].append("cannot detect model name from configs/train.yaml; fallback to torchscript only")
    feature_spec = _read_json(PROCESSED_DIR / "feature_spec.json")
    if not feature_spec:
        report["status"] = "error"
        report["error"]  = "feature_spec.json missing"
        _write_json(REPORT_DIR / "debug_report.json", report)
        print("[debug] feature_spec.json missing -> abort")
        return

    # -------- 加载数据（优先 test，没有就用 val） --------
    def _np_load_fallback(name: str) -> np.ndarray | None:
        p = PROCESSED_DIR / name
        return np.load(p) if p.exists() else None

    X = _np_load_fallback("X_test.npy") 
    Y = _np_load_fallback("Y_test.npy") 
    if X is None or Y is None:
        report["status"] = "error"
        report["error"]  = "no X_test/Y_test (or val) found"
        _write_json(REPORT_DIR / "debug_report.json", report)
        print("[debug] no test/val arrays -> abort")
        return

    N = X.shape[0]
    n_use = min(N, max(1, N_SAMPLES))
    Xs = X[:n_use]
    Ys = Y[:n_use]
    report["data_shapes"] = {
        "X": list(X.shape),
        "Y": list(Y.shape),
        "X_used": list(Xs.shape),
        "Y_used": list(Ys.shape),
    }

    # -------- 数据基本检查 --------
    stats = {
        "X_basic": _collect_basic_stats(Xs),
        "Y_basic": _collect_basic_stats(Ys),
        "X_feat_std": [],
        "Y_target_std": [],
        "flags": {},
    }
    x_feat_std = _per_feature_std(Xs)  # [F]
    stats["X_feat_std"] = x_feat_std.tolist()
    stats["flags"]["x_has_near_const_features"] = bool((x_feat_std < CONST_THR_X).any()) if x_feat_std.size > 0 else None
    stats["flags"]["x_has_nan_or_inf"] = bool(np.isnan(Xs).any() or np.isinf(Xs).any())

    # 针对目标的方差（按 O 维汇总）
    if Ys.ndim == 3 and Ys.shape[0] > 0:
        # over N*H
        y_tgt_std = np.std(Ys, axis=(0,1))
        stats["Y_target_std"] = y_tgt_std.tolist()
        stats["flags"]["y_has_near_const_targets"] = bool((y_tgt_std < CONST_THR_Y).any()) if y_tgt_std.size > 0 else None
        stats["flags"]["y_has_nan_or_inf"] = bool(np.isnan(Ys).any() or np.isinf(Ys).any())

    _write_json(REPORT_DIR / "preds_summary.json", stats)

    # -------- 加载模型（优先原生 PyTorch 可hook） --------
    layer_stats: Dict[str, Any] = {}
    model = None
    load_path = None
    load_note = None

    if model_name:
        model, load_path, load_note = _try_import_python_model(model_name, feature_spec, train_yaml_text)
    if model is None:
        model, load_path, load_note = _try_load_torchscript()

    report["model_load"] = {
        "path": load_path,
        "mode": load_note,
    }

    if model is None:
        report["status"] = "error"
        report["error"]  = f"cannot load model ({load_note})"
        _write_json(REPORT_DIR / "debug_report.json", report)
        print(f"[debug] load model failed: {load_note} -> abort")
        return

    # -------- 前向 + hooks --------
    # 仅当是原生 PyTorch 模型时才能hook到
    can_hook = isinstance(model, nn.Module) and not isinstance(model, torch.jit.ScriptModule)
    if can_hook:
        hooked_outputs, ok = _attach_hooks(model)
    else:
        hooked_outputs, ok = ({}, False)

    # 设备
    model.to("cpu")
    x_t = torch.tensor(Xs, dtype=torch.float32, device="cpu")

    with torch.no_grad():
        y_pred_t = model(x_t)
    if isinstance(y_pred_t, (tuple, list)):
        y_pred_t = y_pred_t[0]
    y_pred = y_pred_t.detach().cpu().numpy()

    # 预测统计
    pred_stats = _collect_basic_stats(y_pred)
    report["prediction_stats"] = pred_stats
    report["flags"] = {
        "pred_is_near_constant": (pred_stats["std"] is not None and pred_stats["std"] < CONST_THR_P),
        "used_torchscript": (load_note == "torchscript_loaded"),
        "used_python_model": (load_note == "python_model_loaded"),
    }

    # 各层（若有）
    if ok and len(hooked_outputs) > 0:
        for k, arr in hooked_outputs.items():
            layer_stats[k] = {
                "shape": list(arr.shape),
                "mean": float(np.mean(arr)),
                "std": float(np.std(arr)),
                "min": float(np.min(arr)),
                "max": float(np.max(arr)),
            }
        _write_json(REPORT_DIR / "layer_stats.json", layer_stats)
    else:
        _write_json(REPORT_DIR / "layer_stats.json", {"note": "no layer hooks (using TorchScript or no eligible modules)"} )

    # -------- 真实vs预测配对（按 target × horizon） --------
    target_names = feature_spec.get("target_cols", [])
    if y_pred.ndim != 3:
        # 某些模型可能输出 [N, O]，兜底 reshape 为 [N, 1, O]
        if y_pred.ndim == 2:
            y_pred = y_pred[:, None, :]
        else:
            # 实在不匹配就退出对照表，但主报告仍可用
            _write_json(REPORT_DIR / "pred_true_pairs.json", {"error": f"unexpected pred shape {list(y_pred_t.shape)}"})
        # 同步 Ys
        if Ys.ndim == 2:
            Ys = Ys[:, None, :]

    if Ys.ndim == 3 and y_pred.ndim == 3 and Ys.shape[1] == y_pred.shape[1] and Ys.shape[2] == y_pred.shape[2]:
        pairs = _make_pairs_per_target_horizon(Ys, y_pred, target_names)
        _write_json(REPORT_DIR / "pred_true_pairs.json", pairs)
    else:
        _write_json(REPORT_DIR / "pred_true_pairs.json", {
            "warning": "shape mismatch for pair dump",
            "Y_used_shape": list(Ys.shape),
            "Y_pred_shape": list(y_pred.shape),
        })

    # -------- 生成结论与建议 --------
    suggestions: List[str] = []
    flags = report.get("flags", {})
    x_const = stats["flags"].get("x_has_near_const_features") is True
    y_const = stats["flags"].get("y_has_near_const_targets") is True
    pred_const = flags.get("pred_is_near_constant") is True
    x_naninf = stats["flags"].get("x_has_nan_or_inf") is True
    y_naninf = stats["flags"].get("y_has_nan_or_inf") is True

    if x_naninf or y_naninf:
        suggestions.append("发现 NaN/Inf：请在数据管道中加入 NaN/Inf 清理与裁剪。")

    if x_const:
        suggestions.append("输入存在近似常数特征：考虑在前处理阶段剔除恒值/几乎恒值特征，或检查缩放是否把方差压成0。")

    if y_const:
        suggestions.append("目标近似常数：请确认构造窗口/目标选择是否正确，是否把同一时间的特征复制到了未来窗口。")

    if pred_const:
        suggestions.append("预测几乎恒定：优先检查：学习率过小/过大；初始化；Dropout过大；LSTM flatten_parameters；是否训练早停过早；是否梯度爆炸/裁剪不当。")
        suggestions.append("若仅 TorchScript 无法定位层：请用原生模型加载 best_*.pt 进行 hook（本脚本已自动尝试）。")

    if not suggestions:
        suggestions.append("未发现明显异常。若效果仍不理想，建议可视化部分输入特征与目标的时序，或检查特征工程与标签构造。")

    report["conclusions"]  = {
        "x_near_const_features": x_const,
        "y_near_const_targets":  y_const,
        "pred_near_const":       pred_const,
        "has_nan_or_inf_in_x":   x_naninf,
        "has_nan_or_inf_in_y":   y_naninf,
    }
    report["suggestions"] = suggestions

    _write_json(REPORT_DIR / "debug_report.json", report)
    print("[debug] report written to", REPORT_DIR / "debug_report.json")

if __name__ == "__main__":
    main()