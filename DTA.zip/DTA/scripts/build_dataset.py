# coding: utf-8
"""
scripts/build_dataset.py

完整数据集构建流水线:
- step5: 滑窗构建 (X_all / Y_all / index_all / feature_spec.json)
- step6: 采样均衡 (X_balanced / Y_balanced / index_balanced / balance_report.json)
- step7: 数据集划分 (X_train/X_val/X_test ... split_indices.json)

后续:
- step8: 归一化/标准化 (还未挂上)

用法:
    python scripts/build_dataset.py --cfg configs/dataset.yaml
"""

import argparse
from pathlib import Path
import sys

# 保证可以 import src.*
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.utils.io import read_yaml
from src.dataset.step5_windows import run_step5_build_windows
from src.dataset.step6_split import run_step6_split
from src.dataset.step7_balance import run_step7_balance
from src.dataset.step8_scale import run_step8_scale



def build_dataset(dataset_cfg_path: Path):
    cfg_all = read_yaml(dataset_cfg_path)
    if "dataset" not in cfg_all:
        raise ValueError("[build_dataset] dataset.yaml 缺少 'dataset' 顶层字段")
    ds_cfg = cfg_all["dataset"]

    pipeline_report = {}

    # ---------- step5 ----------
    if ds_cfg.get("build_windows", {}).get("enabled", True):
        info5 = run_step5_build_windows(ds_cfg)
        pipeline_report["step5"] = info5
    else:
        print("[build_dataset] step5 disabled")
        pipeline_report["step5"] = {}

    # ---------- step6 ----------
    if ds_cfg.get("split", {}).get("enabled", True):
        info7 = run_step6_split(ds_cfg)
        pipeline_report["step6"] = info7
    else:
        print("[build_dataset] step6 disabled")
        pipeline_report["step6"] = {}
        
    # ---------- step7 ----------
    if ds_cfg.get("balance_sampling", {}).get("enabled", True):
        pipeline_report["step7"] = {}
        if ds_cfg.get("balance_sampling").get("balance_tarin"):
            info6 = run_step7_balance(ds_cfg, "train")
            pipeline_report["step7"]["train"] = info6
            
        if ds_cfg.get("balance_sampling").get("balance_val"):
            info6 = run_step7_balance(ds_cfg, "val")
            pipeline_report["step7"]["val"] = info6
            
        if ds_cfg.get("balance_sampling").get("balance_test"):
            info6 = run_step7_balance(ds_cfg, "test")
            pipeline_report["step7"]["test"] = info6
    else:
        print("[build_dataset] step7 disabled")
        pipeline_report["step7"] = {}

    # ---------- step8 ----------
    if ds_cfg.get("scaling", {}).get("enabled", True):
        info8 = run_step8_scale(ds_cfg)
        pipeline_report["step8"] = info8
    else:
        print("[build_dataset] step8 disabled")
        pipeline_report["step8"] = {}


    print("[build_dataset] pipeline finished.")
    for step_name in ["step5", "step6", "step7", "step8"]:
        if pipeline_report[step_name]:
            print(f"[build_dataset] {step_name} summary: {pipeline_report[step_name]}")

    return pipeline_report


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--cfg",
        type=str,
        default="configs/dataset.yaml",
        help="path to dataset.yaml"
    )
    args = ap.parse_args()

    build_dataset(Path(args.cfg))