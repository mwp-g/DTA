# -- coding: utf-8 --
"""
scripts/train.py

使用深度模型(LSTM / Transformer)训练时序预测模型.

流程:
1.  读取 train.yaml
2.  加载 step8 产物 (X_train_scaled.npy, X_val_scaled.npy, etc.)
3.  构建模型和 ForecastWrapper
4.  Trainer.fit() -> early stopping & best_xxx.pt
5.  载入 best 权重到 wrapper.model
6.  导出对外交付产物:
    • TorchScript 黑盒 (同时可在 CPU/GPU 跑, 用 script 而不是 trace)
    • deploy_meta.json (I/O 协议)
7.  (可选) 将交付产物 + scaler.json 复制到 deliver 目录便于打包

运行:
    python scripts/train.py --train configs/train.yaml
"""

from __future__ import annotations
import sys
import torch
from pathlib import Path
import argparse
import json
import shutil
import numpy as np

# 保持和你的项目一致的 sys.path 处理方式
sys.path.append(str(Path(__file__).resolve().parents[1]))

from src.utils.io import read_yaml, ensure_dir
from src.models.lstm_model import LSTMModel
from src.models.transformer_model import TransformerModel
from src.models.model_wrapper import ForecastWrapper
from src.models.trainer import Trainer


# -------------------------
# 读取 step8 产物
# -------------------------
def _load_data_arrays(processed_dir: Path, use_scaled: bool):
    """
    根据 use_scaled 选择加载 *_scaled.npy 或未缩放版本。
    正常训练下 use_scaled=True。
    """
    if use_scaled:
        X_tr = np.load(processed_dir / "X_train_scaled.npy")
        Y_tr = np.load(processed_dir / "Y_train_scaled.npy")
        X_va = np.load(processed_dir / "X_val_scaled.npy")
        Y_va = np.load(processed_dir / "Y_val_scaled.npy")
    else:
        X_tr = np.load(processed_dir / "X_train.npy")
        Y_tr = np.load(processed_dir / "Y_train.npy")
        X_va = np.load(processed_dir / "X_val.npy")
        Y_va = np.load(processed_dir / "Y_val.npy")

    return X_tr, Y_tr, X_va, Y_va


def _load_specs(processed_dir: Path):
    """
    读取 feature_spec.json
    返回 dims dict:
    {
        "feature_names": [...],
        "target_names":  [...],
        "input_steps":   T,
        "horizon_steps": H,
        "input_size":    F,
        "output_size":   O,
    }
    """
    spec_path = processed_dir / "feature_spec.json"
    with open(spec_path, "r", encoding="utf-8") as f:
        spec = json.load(f)

    feature_names = spec.get("feature_cols", [])
    target_names  = spec.get("target_cols", [])

    T = int(spec["input_steps"])
    H = int(spec["horizon_steps"])
    F = len(feature_names)
    O = len(target_names)

    if O <= 0:
        raise ValueError(
            "[train] feature_spec.json 里的 target_cols 为空，导致 output_size=0。\n"
            "至少需要1个预测目标（例如 'cpu.used'），否则无法构建可训练模型。"
        )

    dims = {
        "feature_names": feature_names,
        "target_names":  target_names,
        "input_steps":   T,
        "horizon_steps": H,
        "input_size":    F,
        "output_size":   O,
    }
    return dims


def _build_core_model(model_name: str, model_cfg: dict, dims: dict):
    """
    根据 model.name 构建具体 PyTorch 模型 (LSTMModel / TransformerModel)
    dims 里带有 input_size(F), horizon_steps(H), output_size(O), input_steps(T)
    """
    if model_name.lower() == "lstm":
        return LSTMModel(
            input_size=dims["input_size"],
            hidden_size=model_cfg.get("hidden_size", 128),
            num_layers=model_cfg.get("num_layers", 2),
            dropout=model_cfg.get("dropout", 0.1),
            horizon_steps=dims["horizon_steps"],
            output_size=dims["output_size"],
        )

    elif model_name.lower() == "transformer":
        return TransformerModel(
            input_size=dims["input_size"],
            d_model=model_cfg.get("d_model", 128),
            nhead=model_cfg.get("nhead", 4),
            num_layers=model_cfg.get("num_layers", 2),
            dim_feedforward=model_cfg.get("dim_feedforward", 256),
            dropout=model_cfg.get("dropout", 0.1),
            horizon_steps=dims["horizon_steps"],
            output_size=dims["output_size"],
            max_len=dims["input_steps"],  # 用输入窗口长度作为pos embedding范围
        )

    else:
        raise ValueError(f"unsupported model name: {model_name}")


def _copy_for_delivery(copy_list, src_root: Path, dst_root: Path):
    """
    把 copy_list 中列出的路径复制到 dst_root 下 (扁平化只保留文件名)。
    例:
      copy_things:
        - "model/deploy_model.ts"
        - "model/deploy_meta.json"
        - "data/processed/scaler.json"
      product_copy_dir = deliver/
    结果:
      deliver/deploy_model.ts
      deliver/deploy_meta.json
      deliver/scaler.json
    """
    ensure_dir(dst_root)
    for rel_path in copy_list:
        src_path = Path(rel_path)
        if not src_path.exists():
            print(f"[train][warn] skip copy, not found: {src_path}")
            continue
        dst_path = dst_root / src_path.name
        shutil.copy2(src_path, dst_path)
        print(f"[train] copied {src_path} -> {dst_path}")


def train(train_cfg_path: Path):
    # ===========================================
    # 1. 读取整体配置
    # ===========================================
    cfg = read_yaml(train_cfg_path)
    data_cfg   = cfg["data"]
    model_top  = cfg["model"]
    loop_cfg   = cfg["train_loop"]
    export_cfg = cfg.get("export", {})

    processed_dir = Path(data_cfg["processed_dir"])
    use_scaled    = bool(data_cfg.get("use_scaled", True))
    ensure_dir(processed_dir)

    model_name = model_top["name"]
    model_cfg  = model_top[model_name]

    device_str = model_cfg.get("device", "cpu")
    save_best_path = model_cfg.get(
        "save_best_path",
        f"models/best_{model_name}.pt"
    )
    ensure_dir(Path(save_best_path).parent)

    # 交付产物的路径 (来自新的 export 配置)
    model_weight_path = Path(export_cfg.get("model_weight_path", "model/deploy_model.ts"))
    model_meta_path   = Path(export_cfg.get("model_meta_path",   "model/deploy_meta.json"))
    ensure_dir(model_weight_path.parent)
    ensure_dir(model_meta_path.parent)

    want_copy         = bool(export_cfg.get("copy", False))
    product_copy_dir  = Path(export_cfg.get("product_copy_path", "deliver"))
    copy_things       = export_cfg.get("copy_things", [])

    # ===========================================
    # 2. 加载数据, 规格, scaler路径
    # ===========================================
    X_tr, Y_tr, X_va, Y_va = _load_data_arrays(processed_dir, use_scaled=use_scaled)

    dims = _load_specs(processed_dir)
    feature_names = dims["feature_names"]
    target_names  = dims["target_names"]

    scaler_path = processed_dir / "scaler.json"

    # ===========================================
    # 3. 构建核心模型
    # ===========================================
    core_model = _build_core_model(
        model_name=model_name,
        model_cfg=model_cfg,
        dims=dims,
    )

    # ===========================================
    # 4. 构建 ForecastWrapper
    #    Trainer 依赖它做保存/加载best权重, 也会用到 wrapper.device
    # ===========================================
    wrapper = ForecastWrapper(
        model_type=model_name,
        model=core_model,
        input_steps=dims["input_steps"],
        horizon_steps=dims["horizon_steps"],
        device=device_str,
        # Trainer 用 target_names 打日志，所以要传
        feature_names=feature_names,
        target_names=target_names,
        scaler_path=str(scaler_path),
        extra_config={
            "model_cfg": model_cfg,
            "data_dims": {
                "input_size":     dims["input_size"],
                "output_size":    dims["output_size"],
                "input_steps":    dims["input_steps"],
                "horizon_steps":  dims["horizon_steps"],
            },
        },
    )

    # ===========================================
    # 5. Trainer & 训练
    #    Trainer 会:
    #      - 每epoch打印标准化loss和真实空间指标(mse/mae/mape)
    #      - early stopping
    #      - 保存 best 权重到 save_best_path
    #      - 训练结束后打印 BEST MODEL 的真实指标
    # ===========================================
    trainer = Trainer(
        wrapper=wrapper,
        train_cfg={
            "scaler": use_scaled,
            "batch_size":      loop_cfg.get("batch_size", 64),
            "epochs":          loop_cfg.get("epochs", 50),
            "lr":              loop_cfg.get("lr", 1e-3),
            "patience":        loop_cfg.get("patience", 5),
            "log_interval":    loop_cfg.get("log_interval", 1),
            "loss":            loop_cfg.get("loss", "mse"),
            "save_best_path":  save_best_path,
            "processed_dir":   str(processed_dir),
            "target_names":    target_names,
            "horizon_steps":   dims["horizon_steps"],
        },
    )

    summary = trainer.fit(
        X_train=X_tr,
        Y_train=Y_tr,
        X_val=X_va,
        Y_val=Y_va,
    )

    print(f"[train] Training finished. best_val={summary['best_val']:.6f} @ epoch={summary['best_epoch']}")
    print(f"[train] Best weights saved -> {summary['save_best_path']}")

    # ===========================================
    # 6. 训练结束后，把最佳权重重新load进 wrapper.model
    #    这样 wrapper.model = best 状态
    # ===========================================
    wrapper.load_best_weights(summary["save_best_path"], device=device_str)

    # ===========================================
    # 7. 导出 TorchScript 黑盒 (CPU/GPU 通用)
    #    <<< 这里是关键修改 >>>
    #
    #    我们不再用 trace，而是用 script。
    #    script 会编译你的 forward 逻辑，而不是“录像”一次CPU推理过程，
    #    从而避免把 hidden state 固定在 CPU，从而允许后续在 GPU 上运行。
    #
    #    导出步骤:
    #      - 把 wrapper.model 先挪到 CPU (权重落地为CPU版，方便最低要求环境)
    #      - torch.jit.script(wrapper.model)
    #      - script_model.save(...)
    #
    #    之后在推理端：
    #      model = torch.jit.load(..., map_location="cuda:3")
    #      x = x.to("cuda:3")
    #      y = model(x)
    #
    #    或者纯CPU：
    #      model = torch.jit.load(..., map_location="cpu")
    #      x = x.to("cpu")
    #      y = model(x)
    # ===========================================
    wrapper.to("cpu")
    wrapper.model.eval()

    scripted_model = torch.jit.script(wrapper.model)  # <<< 修改：用script而不是trace
    scripted_model.eval()

    scripted_model.save(str(model_weight_path))
    print(f"[train] TorchScript universal model saved -> {model_weight_path}")

    # ===========================================
    # 8. 写 deploy_meta.json
    #    交付给对方的 I/O 协议
    #    - 暴露 target_names / feature_cols / scaler.json
    #    - 不暴露 hidden_size / num_layers / transformer结构细节
    # ===========================================
    deploy_meta = {
        "input_steps":   int(dims["input_steps"]),    # T
        "input_size":    int(dims["input_size"]),     # F
        "horizon_steps": int(dims["horizon_steps"]),  # H
        "output_size":   int(dims["output_size"]),    # O
        "target_names":  target_names,
        "feature_cols":  feature_names,
        # 对方需要用 scaler.json 做归一化/反归一化
        "scaler_file":   "scaler.json",
    }

    with open(model_meta_path, "w", encoding="utf-8") as f:
        json.dump(deploy_meta, f, ensure_ascii=False, indent=2)
    print(f"[train] deploy meta saved -> {model_meta_path}")

    # ===========================================
    # 9. 如果 export.copy == True:
    #    把 copy_things 里的文件复制到 product_copy_dir 下
    # ===========================================
    if want_copy:
        ensure_dir(product_copy_dir)
        _copy_for_delivery(
            copy_list=copy_things,
            src_root=Path("."),
            dst_root=product_copy_dir,
        )
        print(f"[train] delivery artifacts copied under {product_copy_dir}")

    # ===========================================
    # 10. 返回信息 (给上层/调试用)
    # ===========================================
    return {
        "best_val":          summary["best_val"],
        "best_epoch":        summary["best_epoch"],
        "best_ckpt":         summary["save_best_path"],
        "deploy_model_path": str(model_weight_path),
        "deploy_meta_path":  str(model_meta_path),
        "copied_to":         str(product_copy_dir) if want_copy else "",
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", type=str, required=True, help="path to new-style train.yaml")
    args = ap.parse_args()
    train(Path(args.train))