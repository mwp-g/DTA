# coding: utf-8
"""
评估脚本（层级：snapshot_id/target/horizon_step/segment_id/fragment_id → pairs）：
• 根据 train.yaml 加载 TorchScript 模型 (lstm/transformer)
• 加载 data/processed 下的 X_test.npy / Y_test.npy / index_test.json / scaler.json
• 输出：
  - metrics.overall：
      - total：全量 MSE / sMAPE（无 pairs）
      - by_snapshot：每台机器 → total / by_target / by_horizon
      - by_target：跨机器全局 → 每个 target 的 total / by_horizon
  - pairs_hierarchy：snapshot_id -> target -> horizon_step -> segment_id -> fragment_id -> [{true, pred}, ...]
落盘：model/test_report.json
"""

import argparse
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

import numpy as np
import torch
import yaml


# -----------------------------
# 基础工具
# -----------------------------
def load_json(p: Path):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def zscore_x(X: np.ndarray, scaler: dict) -> np.ndarray:
    xp = scaler["x_params"]
    mean = np.array(xp["mean"], dtype=np.float32).reshape(1, 1, -1)
    std = np.array(xp["std"], dtype=np.float32).reshape(1, 1, -1)
    return (X - mean) / (std + 1e-8)


def inv_y(Y_scaled: np.ndarray, scaler: dict) -> np.ndarray:
    yp = scaler["y_params"]
    mean = np.array(yp["mean"], dtype=np.float32).reshape(1, 1, -1)
    std = np.array(yp["std"], dtype=np.float32).reshape(1, 1, -1)
    return Y_scaled * std + mean


def mse(y_true, y_pred) -> float:
    y_true = np.asarray(y_true, dtype=np.float32)
    y_pred = np.asarray(y_pred, dtype=np.float32)
    return float(np.mean((y_pred - y_true) ** 2))


def smape(y_true, y_pred, eps: float = 1e-6) -> float:
    y_true = np.asarray(y_true, dtype=np.float32)
    y_pred = np.asarray(y_pred, dtype=np.float32)
    num = 2.0 * np.abs(y_pred - y_true)
    den = np.abs(y_pred) + np.abs(y_true) + eps
    return float(np.mean(num / den) * 100.0)


def compute_metrics(y_true, y_pred) -> Dict[str, Any]:
    """统一的指标打包：MSE / sMAPE"""
    return {
        "mse": mse(y_true, y_pred),
        "smape": smape(y_true, y_pred),
    }


# -----------------------------
# 主逻辑
# -----------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--train_yaml", type=str, default="configs/train.yaml",
                    help="路径到 train.yaml")
    ap.add_argument("--device", type=str, default=None,
                    help="cpu 或 cuda:3（未指定则从 yaml 读取）")
    args = ap.parse_args()

    # === 1) 加载 train.yaml ===
    with open(args.train_yaml, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    model_name = cfg["model"]["name"].lower()
    model_cfg = cfg["model"][model_name]
    device_str = args.device or model_cfg.get("device", "cpu")
    device = torch.device(device_str)

    base_model_dir = Path("model")
    base_data_dir = Path(cfg["data"]["processed_dir"])

    # === 2) 加载模型与元信息 ===
    export_cfg = cfg.get("export", cfg.get("train_loop", {}).get("export", {}))
    model_weight_path = Path(export_cfg.get("model_weight_path", "model/deploy_model.ts"))
    model_meta_path = Path(export_cfg.get("model_meta_path", "model/deploy_meta.json"))

    print(f"[load] model from {model_weight_path}")
    model = torch.jit.load(model_weight_path, map_location=device)
    model.eval()

    meta = load_json(model_meta_path)
    scaler = load_json(base_data_dir / "scaler.json")

    # === 3) 加载测试集与 index ===
    X = np.load(base_data_dir / "X_test.npy")
    Y = np.load(base_data_dir / "Y_test.npy")
    index_items = load_json(base_data_dir / "index_test.json")

    # 形状与元信息
    T = int(meta["input_steps"])
    F = int(meta["input_size"])
    H = int(meta["horizon_steps"])
    O = int(meta["output_size"])
    target_names = meta.get("target_names", [f"target[{i}]" for i in range(O)])

    assert X.ndim == 3 and X.shape[1] == T and X.shape[2] == F, f"X shape mismatch: {X.shape}"
    assert Y.ndim == 3 and Y.shape[1] == H and Y.shape[2] == O, f"Y shape mismatch: {Y.shape}"
    assert len(index_items) == X.shape[0] == Y.shape[0], \
        f"index_test.json 行数与 X/Y 样本数不一致: index={len(index_items)} X={X.shape[0]} Y={Y.shape[0]}"

    # === 4) 推理 ===
    Xs = zscore_x(X, scaler)
    with torch.no_grad():
        y_scaled = model(torch.tensor(Xs, dtype=torch.float32, device=device)).cpu().numpy()
    y_pred = inv_y(y_scaled, scaler)
    y_true = Y.astype(np.float32)

    # === 5) overall 指标（不含 pairs）===
    overall_total = compute_metrics(y_true, y_pred)

    # === 6) 构建 by_snapshot 的行索引（供 metrics 使用；pairs_hierarchy 保持原逻辑独立）===
    N = y_true.shape[0]
    rows_by_snapshot: Dict[str, list] = {}
    for i in range(N):
        sid = str(index_items[i].get("snapshot_id", "UNKNOWN"))
        rows_by_snapshot.setdefault(sid, []).append(i)

    # --- 6.1 每台机器（by_snapshot）指标 ---
    # 结构：{ snapshot_id: { "total": {...}, "by_target": { tname: { "total": {...}, "by_horizon": {"0": {...}, ...} } } } }
    by_snapshot = {}
    for sid, idxs in sorted(rows_by_snapshot.items(), key=lambda kv: kv[0]):  # 字典key升序
        yt_sid = y_true[idxs]  # [Ns,H,O]
        yp_sid = y_pred[idxs]  # [Ns,H,O]

        info_sid = {"total": compute_metrics(yt_sid, yp_sid), "by_target": {}}

        for o in range(O):
            tname = target_names[o] if o < len(target_names) else f"target[{o}]"
            yt_sid_t = yt_sid[:, :, o]     # [Ns,H]
            yp_sid_t = yp_sid[:, :, o]
            per_t = {"total": compute_metrics(yt_sid_t, yp_sid_t), "by_horizon": {}}
            for h in range(H):
                h_key = str(h)
                per_t["by_horizon"][h_key] = compute_metrics(yt_sid[:, h, o], yp_sid[:, h, o])
            info_sid["by_target"][tname] = per_t

        by_snapshot[sid] = info_sid

    # --- 6.2 跨机器的全局 by_target 指标 ---
    # 结构：{ tname: { "total": {...}, "by_horizon": {"0": {...}, ...} } }
    by_target_global = {}
    for o in range(O):
        tname = target_names[o] if o < len(target_names) else f"target[{o}]"
        yt_t = y_true[:, :, o]  # [N,H]
        yp_t = y_pred[:, :, o]
        per_t = {"total": compute_metrics(yt_t, yp_t), "by_horizon": {}}
        for h in range(H):
            h_key = str(h)
            per_t["by_horizon"][h_key] = compute_metrics(y_true[:, h, o], y_pred[:, h, o])
        by_target_global[tname] = per_t

    # === 7) 组装 pairs 层级（保持你原逻辑, 不改动结构）===
    # snapshot_id -> target_name -> horizon_step -> segment_id -> fragment_id -> [{true, pred}, ...]
    pairs_hierarchy = {}

    for i in range(N):
        meta_i = index_items[i]
        sid = str(meta_i.get("snapshot_id", "UNKNOWN"))
        seg = str(meta_i.get("segment_id", "0"))
        fid = str(meta_i.get("fragment_id", "0"))

        if sid not in pairs_hierarchy:
            pairs_hierarchy[sid] = {}

        for o in range(O):
            tname = target_names[o] if o < len(target_names) else f"target[{o}]"
            if tname not in pairs_hierarchy[sid]:
                pairs_hierarchy[sid][tname] = {}

            for h in range(H):
                if h not in pairs_hierarchy[sid][tname]:
                    pairs_hierarchy[sid][tname][h] = {}
                if seg not in pairs_hierarchy[sid][tname][h]:
                    pairs_hierarchy[sid][tname][h][seg] = {}
                if fid not in pairs_hierarchy[sid][tname][h][seg]:
                    pairs_hierarchy[sid][tname][h][seg][fid] = []

                pairs_hierarchy[sid][tname][h][seg][fid].append({
                    "true": float(y_true[i, h, o]),
                    "pred": float(y_pred[i, h, o]),
                })

    # === 8) 汇总报告并落盘 ===
    report = {
        "meta": {
            "generated_at": datetime.now().isoformat(),
            "device": device_str,
            "model_name": model_name,
            "model_weight_path": str(model_weight_path.resolve()),
            "model_meta_path": str(model_meta_path.resolve()),
            "scaler_path": str((base_data_dir / "scaler.json").resolve()),
            "X_path": str((base_data_dir / "X_test.npy").resolve()),
            "Y_path": str((base_data_dir / "Y_test.npy").resolve()),
            "index_path": str((base_data_dir / "index_test.json").resolve()),
            "shape_X": list(X.shape),
            "shape_Y": list(Y.shape),
        },
        "metrics": {
            "overall": {
                "total": overall_total,
                "by_snapshot": by_snapshot,        # 机器 → total / by_target / by_horizon
                "by_target": by_target_global,     # 全局 → target → total / by_horizon
            }
        },
        "pairs_hierarchy": pairs_hierarchy
    }

    out_path = base_model_dir / "test_report.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2, sort_keys=True)

    print(f"[test] done. overall MSE={overall_total['mse']:.6f}  sMAPE%={overall_total['smape']:.3f}")
    print(f"[test] report saved -> {out_path}")


if __name__ == "__main__":
    main()